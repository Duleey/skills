# 黄金分析 Agent 文档

> 基于 Claude Code 的专业黄金市场分析系统
> 版本: v3.2.0 - 100% 公开数据，无需 API Key

---

## 📖 文档导航

### 快速开始

- **[使用示例](../USER_PROMPT_EXAMPLE.md)** - 完整任务示例，5分钟上手
- **[启动脚本](../start-gold-agent.sh)** - 一键启动 Agent

### 核心文档

- **[数据源说明](04-DATA_SOURCES.md)** - 所有公开数据源（无需API Key）
- **[能力对比](05-CAPABILITY.md)** - 更新前后功能对比
- **[目录结构](06-DIRECTORY_STRUCTURE.md)** - 项目目录说明

### 更新记录

- **[更新日志](UPDATE_LOG.md)** - 详细更新记录（推荐阅读）

---

## 🎯 系统特性

### ✅ 无需 API Key
- 所有数据来源于公开网站
- WebSearch + WebFetch 组合获取
- Coinbase API（无需密钥）
- 金融新闻网站爬取

### ✅ 3个专业 Skills
1. **financial-data-fetcher** - 数据获取与验证专家
2. **geopolitical-analyst** - 地缘政治分析专家
3. **financial-report-generator** - 专业报告生成器

### ✅ 现代化设计
- shadcn/ui Zinc 暗色主题
- 响应式卡片布局
- Chart.js 数据可视化
- 双语支持（中文/English）

---

## 📂 项目结构

```
Announcement/
├── .claude/                  # Claude Code 配置（核心）
│   ├── prompts/              # 系统提示词
│   │   ├── system_prompt_cn.md
│   │   └── system_prompt_en.md
│   ├── skills/               # 3个专业 Skills
│   │   ├── skill_financial_data_fetcher.md
│   │   ├── skill_geopolitical_analyst.md
│   │   └── skill_financial_report_generator.md
│   ├── agents/               # Sub-agents 配置
│   ├── config/               # 其他配置
│   ├── settings.json         # 主配置
│   └── mcp.json              # MCP 配置
│
├── docs/                     # 所有文档（当前目录）
│   ├── README.md             # 本文件
│   ├── 04-DATA_SOURCES.md
│   ├── 05-CAPABILITY.md
│   ├── 06-DIRECTORY_STRUCTURE.md
│   ├── UPDATE_LOG.md
│   └── archives/             # 旧文档归档
│
├── scripts/                  # 数据获取脚本
│   ├── fetch_real_gold_data.py
│   └── setup.sh
│
├── README.md                 # 项目主文档
├── USER_PROMPT_EXAMPLE.md   # 使用示例
└── start-gold-agent.sh      # 启动脚本
```

---

## 🚀 快速开始

### 1. 启动 Agent
```bash
./start-gold-agent.sh
```

### 2. 执行任务（复制粘贴即可）
```
请帮我完成黄金市场深度分析任务：

**任务要求**：
1. 获取 2026年1月29日 的真实金价数据（使用公开数据）
2. 分析价格波动原因（地缘政治、经济数据）
3. 技术指标分析（RSI、MACD、布林带）
4. 生成专业HTML报告（shadcn/ui设计）

**数据获取**（无需API Key）：
- 使用 WebSearch + WebFetch 从 Kitco、GoldPrice.org 获取历史数据
- 使用 python3 scripts/fetch_real_gold_data.py 获取当前价格
- 从金融新闻网站获取事件信息

**报告要求**：
- Zinc dark 主题，专业卡片布局
- 双语（中文+English）
- 包含价格走势图、技术指标图表
- 标注所有数据来源和时间戳
```

### 3. Agent 自动执行
- ✅ 使用 financial-data-fetcher skill 获取数据
- ✅ 使用 geopolitical-analyst skill 分析事件
- ✅ 使用 financial-report-generator skill 生成报告

---

## 📊 数据源列表

所有数据源均为**公开可访问**，无需 API Key：

### 价格数据
- Kitco.com - 历史金价
- GoldPrice.org - 实时金价
- Investing.com - 市场数据
- Coinbase API - 加密货币金价（无需密钥）

### 新闻事件
- WebSearch - 金融新闻搜索
- Reuters, Bloomberg, CNBC - 新闻网站
- 各大财经媒体 - 事件分析

### 经济指标
- Trading Economics - 公开经济数据
- World Gold Council - 黄金需求报告
- LBMA - 伦敦金银市场数据

详细说明见：[04-DATA_SOURCES.md](04-DATA_SOURCES.md)

---

## 🛠️ Skills 说明

### 1. financial-data-fetcher（数据获取专家）
**位置**：`.claude/skills/skill_financial_data_fetcher.md`

**功能**：
- 从权威公开源获取金融数据
- 数据验证与清洗
- 结构化数据输出（JSON/CSV）

**使用场景**：
- 获取历史金价数据
- 收集技术指标数据
- 验证数据准确性

### 2. geopolitical-analyst（地缘分析专家）
**位置**：`.claude/skills/skill_geopolitical_analyst.md`

**功能**：
- 地缘政治事件研究
- 市场影响评估
- 事件时间线构建
- 情景预测分析

**使用场景**：
- 分析重大事件对金价影响
- 评估地缘风险
- 预测市场反应

### 3. financial-report-generator（报告生成器）
**位置**：`.claude/skills/skill_financial_report_generator.md`

**功能**：
- 专业 HTML 报告生成
- shadcn/ui Zinc 主题
- Chart.js 数据可视化
- 双语报告支持

**使用场景**：
- 生成分析报告
- 创建市场简报
- 输出可视化图表

---

## 📚 归档文档

以下是旧版本文档，仅供参考：

- [ARCHITECTURE_OVERVIEW.md](archives/ARCHITECTURE_OVERVIEW.md) - 旧架构说明
- [CLAUDE_CODE_FEATURES.md](archives/CLAUDE_CODE_FEATURES.md) - 旧功能说明
- [FILE_MANIFEST.md](archives/FILE_MANIFEST.md) - 旧文件清单
- [QUICK_REFERENCE.md](archives/QUICK_REFERENCE.md) - 旧快速参考
- [QUICK_REFERENCE_CLAUDE.md](archives/QUICK_REFERENCE_CLAUDE.md) - 旧Claude参考
- [USAGE_GUIDE.md](archives/USAGE_GUIDE.md) - 旧使用指南
- [gold_market_analysis_2026.md](archives/gold_market_analysis_2026.md) - 旧分析示例
- [CHANGELOG_old.md](archives/CHANGELOG_old.md) - 旧更新日志

---

## ❓ 常见问题

### Q: 我需要 API Key 吗？
**A:** 不需要！所有数据来源于公开网站，通过 WebSearch + WebFetch 获取。

### Q: 如何获取历史数据？
**A:** 使用 WebFetch 从 Kitco.com 或 GoldPrice.org 抓取历史金价数据。

### Q: 报告如何生成？
**A:** 自动使用 financial-report-generator skill 生成 shadcn/ui 风格的 HTML 报告。

### Q: 支持哪些分析？
**A:** 技术分析（RSI、MACD、布林带）、地缘分析、事件影响分析、预测建模。

### Q: 如何使用英文版？
**A:** 运行 `./start-gold-agent.sh --en` 或在 `.claude/settings.json` 中切换系统提示词。

---

## 📞 技术支持

- **系统提示词**：`.claude/prompts/system_prompt_cn.md`
- **配置文件**：`.claude/settings.json`
- **启动脚本**：`start-gold-agent.sh`

---

<div align="center">

**数据真实 · 分析客观 · 无需密钥**

版本: v3.2.0-public-data-only

最后更新: 2026-01-30

</div>
