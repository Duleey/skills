# 📦 黄金分析 Agent - 完整文件清单

> **版本: v3.1.0-real-data-with-subagents**
> **更新日期: 2026-01-30**

---

## 📊 项目概览

本项目包含**基于真实数据**的专业黄金市场分析 Agent 系统，共 **20+ 个文件**。

### 核心原则
- ✅ **100% 真实数据** - 绝不编造任何价格或指标
- ✅ **双语支持** - 完整的中英文系统提示词
- ✅ **Sub-Agents 集成** - 内置 + 自定义子代理
- ✅ **一键启动** - 自动化启动脚本

---

## 📁 文件组织结构

```
Announcement/
│
├── 📄 核心文档 (4个)
│   ├── README.md                          ⭐ 项目主文档
│   ├── CHANGELOG.md                       📝 版本更新日志
│   ├── REAL_DATA_2026.md                 💰 真实数据示例
│   └── .env.example                       🔑 环境变量模板
│
├── ⚙️ 核心配置 (2个)
│   ├── core_config/
│   │   ├── SYSTEM_PROMPT.md              ⭐ Agent 系统提示词（中文）
│   │   └── SYSTEM_PROMPT_EN.md           ⭐ Agent 系统提示词（英文）
│
├── 🛠️ 工具脚本 (2个)
│   ├── scripts/
│   │   ├── fetch_real_gold_data.py       ⭐ 数据获取脚本（已验证）
│   │   └── setup.sh                       🔧 环境安装脚本
│   └── start-gold-agent.sh                🚀 一键启动脚本
│
├── 🤖 Sub-Agents (2个)
│   └── subagents/
│       ├── subagent_financial_intelligence.md       金融情报代理
│       └── subagents_usage_strategy.md              协作策略文档
│
├── 🎯 Skills (3个)
│   └── skills/
│       ├── skill_financial_data_fetcher.md          数据获取
│       ├── skill_geopolitical_analyst.md            地缘分析
│       └── skill_financial_report_generator.md      报告生成
│
├── 📚 文档目录 (6个)
│   └── docs/
│       ├── USAGE_GUIDE.md                 详细使用教程
│       ├── ARCHITECTURE_OVERVIEW.md       系统架构说明
│       ├── QUICK_REFERENCE.md             快速参考卡
│       ├── QUICK_REFERENCE_CLAUDE.md      ⭐ Claude Code 功能速查
│       ├── CLAUDE_CODE_FEATURES.md        ⭐ 完整功能文档
│       ├── FILE_MANIFEST.md               📦 本文件
│       └── gold_market_analysis_2026.md   市场分析示例
│
└── ⚙️ 配置文件 (3个)
    └── .claude/
        ├── settings.json                  Claude Code 配置
        ├── mcp.json                       MCP 服务器配置
        └── skills/                        (待创建自定义 skills)
```

---

## 🌟 核心文件详解

### 1. 系统提示词（最重要）

#### `core_config/SYSTEM_PROMPT.md` (中文版)
- **大小**: 552 行
- **用途**: Agent 核心行为定义
- **包含**:
  - ⚠️ 数据真实性原则（最高优先级）
  - 📊 数据获取流程（必须执行）
  - 🤖 Sub-Agents 使用说明（3+3 个）
  - 🎯 Skills 模块说明（3 个）
  - 📋 标准工作流程
  - 📄 输出格式规范
  - 💡 使用示例
  - 🎯 质量检查清单

#### `core_config/SYSTEM_PROMPT_EN.md` (英文版)
- **大小**: 552 行
- **用途**: 英文用户使用
- **内容**: 与中文版完全对应

### 2. 数据获取脚本

#### `scripts/fetch_real_gold_data.py`
- **大小**: ~200 行
- **状态**: ✅ 已验证可用
- **功能**:
  - 从 Coinbase API 获取实时金价
  - 支持多数据源（可扩展）
  - 返回 JSON 格式
  - 包含时间戳和数据源
- **已验证数据**:
  ```json
  {
    "price": 5296.83,
    "source": "Coinbase API",
    "time": "2026-01-30T15:23:17Z"
  }
  ```

### 3. 启动脚本

#### `start-gold-agent.sh`
- **大小**: ~300 行
- **状态**: ✅ 可执行
- **功能**:
  - 一键启动 Claude Code Agent
  - 自动加载系统提示词
  - 环境检查和验证
  - 支持中英文切换
  - 支持交互/非交互模式
- **使用方法**:
  ```bash
  ./start-gold-agent.sh                    # 交互模式
  ./start-gold-agent.sh "分析当前金价"      # 直接执行
  ./start-gold-agent.sh --en              # 英文版
  ./start-gold-agent.sh --help            # 查看帮助
  ```

---

## 📚 文档文件详解

### 核心文档

| 文件 | 大小 | 用途 | 必读性 |
|------|------|------|--------|
| **README.md** | ~230 行 | 项目主入口，快速开始 | ⭐⭐⭐ |
| **CHANGELOG.md** | ~130 行 | 版本历史和更新记录 | ⭐⭐ |
| **REAL_DATA_2026.md** | ~180 行 | 真实数据示例和说明 | ⭐⭐⭐ |

### 详细文档

| 文件 | 大小 | 用途 | 必读性 |
|------|------|------|--------|
| **USAGE_GUIDE.md** | ~1000 行 | 完整使用教程 | ⭐⭐⭐ |
| **ARCHITECTURE_OVERVIEW.md** | ~600 行 | 系统架构说明 | ⭐⭐ |
| **CLAUDE_CODE_FEATURES.md** | ~600 行 | Claude Code 完整功能 | ⭐⭐⭐ |
| **QUICK_REFERENCE_CLAUDE.md** | ~400 行 | 功能快速参考表 | ⭐⭐⭐ |
| **QUICK_REFERENCE.md** | ~300 行 | 常用命令速查 | ⭐⭐ |

### 特别推荐 ⭐

#### **`docs/CLAUDE_CODE_FEATURES.md`** (新增)
- **章节**: 10 章
- **内容**:
  1. 内置工具详解（11+ 个）
  2. Sub-Agents 详解（6 个）
  3. Skills 系统说明
  4. MCP 服务器配置
  5. Plugins 扩展机制
  6. CLI 完整选项
  7. 推荐配置
  8. 完整功能总结
  9. 下一步建议
  10. 参考资源

#### **`docs/QUICK_REFERENCE_CLAUDE.md`** (新增)
- **格式**: 一页纸速查表
- **内容**:
  - 工具对照表
  - Sub-Agents 选择指南
  - CLI 命令速查
  - 功能对比表
  - 推荐工作流
  - 常见问题

---

## 🤖 Sub-Agents 详解

### 自定义 Sub-Agents (1个)

| Sub-Agent | 专长 | 配置文件 | 大小 |
|-----------|------|---------|------|
| **financial-intelligence-agent** | 量化金融 | `subagents/subagent_financial_intelligence.md` | ~570 行 |

**协作策略**: `subagents/subagents_usage_strategy.md` (~350 行)

---

## 🎯 Skills 详解

| Skill | 功能 | 配置文件 | 大小 |
|-------|------|---------|------|
| **skill_financial_data_fetcher** | API 数据获取 | `skills/skill_financial_data_fetcher.md` | ~150 行 |
| **skill_geopolitical_analyst** | 地缘政治分析 | `skills/skill_geopolitical_analyst.md` | ~280 行 |
| **skill_financial_report_generator** | HTML 报告生成 | `skills/skill_financial_report_generator.md` | ~900 行 |

---

## ⚙️ 配置文件详解

### `.claude/settings.json`
```json
{
  "model": "sonnet",
  "systemPrompt": "core_config/SYSTEM_PROMPT.md",
  "agents": {
    "gold-analyst": {...},
    "gold-analyst-en": {...}
  }
}
```

### `.claude/mcp.json`
```json
{
  "mcpServers": {
    "filesystem": {...}
  }
}
```

### `.env.example`
环境变量模板（API keys）

---

## 📊 文件统计

### 按类型统计

| 类型 | 数量 | 说明 |
|------|------|------|
| **核心配置** | 2 | 系统提示词（中英） |
| **工具脚本** | 3 | 数据获取 + 启动脚本 |
| **Sub-Agents** | 2 | 配置文件 |
| **Skills** | 3 | 技能模块 |
| **文档** | 10+ | 完整文档体系 |
| **配置** | 3 | Claude Code 配置 |
| **总计** | **23+** | 完整的生产级系统 |

### 按重要性统计

| 级别 | 文件 | 说明 |
|------|------|------|
| ⭐⭐⭐ 必需 | 5 | 系统提示词、数据脚本、启动脚本、README |
| ⭐⭐ 推荐 | 8 | 详细文档、Sub-Agents、Skills |
| ⭐ 可选 | 10+ | 参考文档、示例 |

---

## 🚀 快速部署指南

### 方式 1: 一键启动（推荐）

```bash
# 1. 克隆或下载项目
cd /Users/siin/Desktop/Announcement

# 2. 赋予执行权限
chmod +x start-gold-agent.sh

# 3. 启动 Agent
./start-gold-agent.sh

# 4. 或直接执行任务
./start-gold-agent.sh "获取当前金价"
```

### 方式 2: 手动启动

```bash
# 1. 加载系统提示词
claude --system-prompt "$(cat core_config/SYSTEM_PROMPT.md)"

# 2. 开始使用
# 在 Claude Code 中输入任务
```

### 方式 3: 使用配置文件

```bash
# 1. 确保配置文件存在
ls .claude/settings.json

# 2. 启动（自动加载配置）
claude --settings .claude/settings.json
```

---

## 📋 配置检查清单

### 必需文件检查

- [ ] ✅ **系统提示词** (2个)
  - [ ] `core_config/SYSTEM_PROMPT.md`
  - [ ] `core_config/SYSTEM_PROMPT_EN.md`

- [ ] ✅ **数据脚本** (1个)
  - [ ] `scripts/fetch_real_gold_data.py`

- [ ] ✅ **启动脚本** (1个)
  - [ ] `start-gold-agent.sh` (可执行)

- [ ] ✅ **Sub-Agents** (2个)
  - [ ] `subagents/subagent_financial_intelligence.md`
  - [ ] `subagents/subagents_usage_strategy.md`

- [ ] ✅ **Skills** (3个)
  - [ ] `skills/skill_financial_data_fetcher.md`
  - [ ] `skills/skill_geopolitical_analyst.md`
  - [ ] `skills/skill_financial_report_generator.md`

### 可选配置检查

- [ ] 🔧 **环境变量**
  - [ ] `.env` 文件（从 `.env.example` 复制）
  - [ ] FRED_API_KEY
  - [ ] ALPHA_VANTAGE_KEY

- [ ] 🔧 **Claude 配置**
  - [ ] `.claude/settings.json`
  - [ ] `.claude/mcp.json`

- [ ] 🔧 **Python 环境**
  - [ ] Python 3.8+
  - [ ] 必需包: requests, json

---

## 🧪 测试验证

### 1. 测试数据脚本
```bash
python3 scripts/fetch_real_gold_data.py
```

**预期输出**:
```json
{
  "success": true,
  "query_time": "2026-01-30T...",
  "data_sources": [{
    "price": 5296.83,
    "source": "Coinbase API"
  }]
}
```

### 2. 测试启动脚本
```bash
./start-gold-agent.sh --help
```

**预期输出**: 显示完整的帮助信息

### 3. 测试 Agent
```bash
./start-gold-agent.sh "测试：输出'Hello Gold Agent'"
```

---

## 📖 推荐阅读顺序

### 🆕 首次使用者

1. **README.md** (5 分钟) - 项目概览
2. **start-gold-agent.sh --help** (2 分钟) - 了解启动方式
3. **运行启动脚本** (1 分钟) - 开始使用
4. **QUICK_REFERENCE_CLAUDE.md** (10 分钟) - 了解所有功能

### 👨‍💻 开发者

1. **ARCHITECTURE_OVERVIEW.md** (30 分钟) - 系统架构
2. **SYSTEM_PROMPT.md** (40 分钟) - Agent 行为定义
3. **CLAUDE_CODE_FEATURES.md** (60 分钟) - 完整功能
4. **subagents/*.md** (30 分钟) - Sub-Agents 详解

### 🔧 运维人员

1. **README.md** - 部署概览
2. **start-gold-agent.sh** - 启动脚本
3. **.claude/settings.json** - 配置文件
4. **.env.example** - 环境变量

---

## 🔄 版本历史

### v3.1.0 (2026-01-30) - Sub-Agents 集成

**新增**:
- ✨ 系统提示词中集成 Sub-Agents 使用说明
- ✨ CLAUDE_CODE_FEATURES.md 完整功能文档
- ✨ QUICK_REFERENCE_CLAUDE.md 快速参考表
- ✨ start-gold-agent.sh 一键启动脚本
- ✨ .claude/ 配置文件目录

### v3.0.0 (2026-01-30) - 真实数据架构

**重大更新**:
- 🎉 基于真实数据的系统提示词
- 🎉 fetch_real_gold_data.py 数据脚本（已验证）
- 🎉 删除所有虚构数据文档
- 🎉 中英文双语系统提示词

---

## 📞 获取帮助

### 文档查询

1. **快速查找功能**: `docs/QUICK_REFERENCE_CLAUDE.md`
2. **详细使用教程**: `docs/USAGE_GUIDE.md`
3. **功能完整说明**: `docs/CLAUDE_CODE_FEATURES.md`
4. **常见问题**: 每个文档末尾都有 FAQ

### 验证文件完整性

```bash
# 检查所有核心文件
find . -type f -name "*.md" -o -name "*.sh" -o -name "*.py" -o -name "*.json" | sort
```

---

## 🎯 下一步行动

1. ✅ **验证文件完整** - 运行上面的检查清单
2. 🔧 **配置环境变量** - 复制 `.env.example` 为 `.env`
3. 🚀 **启动 Agent** - 运行 `./start-gold-agent.sh`
4. 📖 **阅读文档** - 从 `QUICK_REFERENCE_CLAUDE.md` 开始
5. 💻 **开始分析** - 输入 "获取当前金价并分析"

---

<div align="center">

**完整 · 真实 · 专业**

版本: v3.1.0-real-data-with-subagents
更新: 2026-01-30
维护: Claude Code Gold Analysis Team

📦 **所有文件已就绪，可以开始使用了！**

</div>
