# Claude Code 快速参考表

> 一页纸了解所有可用功能

---

## 🛠️ 内置工具（无需配置，直接可用）

| 工具 | 功能 | 金融分析用途 |
|------|------|------------|
| **Read** | 读取文件 | 读取数据文件、配置、历史报告 |
| **Write** | 写入文件 | 保存分析结果、生成报告 |
| **Edit** | 编辑文件 | 更新配置、修改脚本 |
| **Glob** | 文件搜索 | `**/*.csv` 查找所有数据文件 |
| **Grep** | 代码搜索 | 搜索特定价格、指标、函数 |
| **Bash** | 执行命令 | 运行 Python 脚本、调用 API |
| **WebSearch** | 搜索网页 | 查找金融新闻、央行声明 |
| **WebFetch** | 获取网页 | 抓取金价网站、分析师报告 |
| **Task** | 启动子代理 | 复杂任务分解和并行执行 |
| **LSP** | 代码智能 | 跳转定义、查找引用 |

---

## 🤖 Sub-Agents（子代理）

### 专业金融子代理

| 子代理 | 专长 | 核心能力 |
|--------|------|---------|
| **search-specialist** | 信息搜索 | 新闻、政策、报告、事件 |
| **business-analyst** | 商业分析 | KPI、相关性、趋势、ETF |
| **financial-intelligence-agent** | 量化金融 | API 调用、技术指标、预测模型 |

**调用方式**:
```
Task("financial-intelligence-agent", {
  "task": "acquire_and_analyze",
  "asset": "gold",
  "requirements": ["historical_prices", "technical_indicators"]
})
```

---

## 📜 Skills（技能/命令）

### 当前状态
❌ 无内置 skills（可自定义创建）

### 可创建的自定义 Skills

| Skill 名称 | 命令 | 功能 |
|-----------|------|------|
| **gold-price** | `/gold-price` | 快速查询实时金价 |
| **technical-analysis** | `/technical-analysis` | 一键运行技术分析 |
| **market-report** | `/market-report` | 生成 HTML 分析报告 |
| **correlation** | `/correlation` | 多资产相关性分析 |

**创建目录**: `.claude/skills/`

---

## 🔌 MCP 服务器（Model Context Protocol）

### 当前状态
❌ 无配置 MCP 服务器

### 推荐安装的 MCP 服务器

| MCP 服务器 | 功能 | 安装命令 |
|-----------|------|---------|
| **filesystem** | 安全文件访问 | `npx @modelcontextprotocol/server-filesystem` |
| **postgres** | 数据库查询 | `npx @modelcontextprotocol/server-postgres` |
| **fetch** | HTTP 请求 | `npx @modelcontextprotocol/server-fetch` |
| **自定义金融 API** | 封装所有金融数据源 | 自己开发 Node.js/Python |

**配置文件**: `.claude/mcp.json`

```json
{
  "mcpServers": {
    "gold-data": {
      "command": "python3",
      "args": ["./scripts/fetch_real_gold_data.py", "--mcp-mode"]
    }
  }
}
```

---

## 🧩 Plugins（插件）

### 当前状态
❌ 无安装插件

### 推荐插件方向

1. **技术指标计算插件** - 封装 TA-Lib、pandas_ta
2. **市场数据聚合插件** - 统一多个 API 接口
3. **报告生成插件** - 模板化 HTML/PDF 报告

**插件目录**: `~/.claude/plugins/` 或 `.claude/plugins/`

---

## ⚙️ CLI 重要选项

### 指定系统提示词
```bash
claude --system-prompt "$(cat core_config/SYSTEM_PROMPT.md)"
```

### 加载 MCP 配置
```bash
claude --mcp-config .claude/mcp.json
```

### 选择模型
```bash
claude --model sonnet    # 快速分析（推荐）
claude --model opus      # 复杂预测
claude --model haiku     # 简单查询
```

### 权限模式
```bash
claude --permission-mode acceptEdits    # 自动接受编辑
claude --permission-mode plan           # 先规划后执行
```

### 自定义 Agent
```bash
claude --agent gold-analyst
```

### 非交互式（自动化）
```bash
claude --print "获取金价" --output-format json
```

---

## 📦 已有配置

### ✅ 已创建文件

```
Announcement/
├── core_config/
│   ├── SYSTEM_PROMPT.md          ⭐ 中文系统提示词
│   └── SYSTEM_PROMPT_EN.md       ⭐ 英文系统提示词
├── scripts/
│   └── fetch_real_gold_data.py   ⭐ 数据获取脚本（已验证）
├── skills/
│   ├── skill_financial_data_fetcher.md
│   ├── skill_geopolitical_analyst.md
│   └── skill_financial_report_generator.md
├── subagents/
│   ├── subagent_financial_intelligence.md      ⭐ 金融子代理配置
│   └── subagents_usage_strategy.md             ⭐ 协作策略
└── docs/
    └── CLAUDE_CODE_FEATURES.md   📚 完整功能文档
```

---

## 🚀 快速开始

### 1. 基础使用（无需任何配置）
```bash
claude --system-prompt "$(cat core_config/SYSTEM_PROMPT.md)"
```

### 2. 获取实时金价
```bash
python3 scripts/fetch_real_gold_data.py
```

### 3. 调用金融子代理
```
Task("financial-intelligence-agent", {
  "task": "acquire_and_analyze",
  "asset": "gold"
})
```

---

## 📊 功能对比

| 功能类型 | 已配置 | 可用性 | 优先级 |
|---------|--------|--------|--------|
| 内置工具 | ✅ | 立即可用 | - |
| 系统提示词 | ✅ | 立即可用 | - |
| 数据脚本 | ✅ | 已验证 | - |
| Sub-Agents（内置） | ✅ | 立即可用 | - |
| Sub-Agents（自定义） | ✅ | 已配置 | - |
| Skills | ❌ | 需创建 | 中 |
| MCP 服务器 | ❌ | 需配置 | 高 |
| Plugins | ❌ | 需开发 | 低 |

---

## 🎯 推荐工作流

### 数据获取阶段
```
1. Bash → 运行 fetch_real_gold_data.py
2. Task(financial-intelligence-agent) → 调用金融 API
3. Task(search-specialist) → 搜索新闻事件
```

### 技术分析阶段
```
1. Task(financial-intelligence-agent) → 计算技术指标
2. Task(business-analyst) → 相关性分析
3. Read → 读取历史报告对比
```

### 报告生成阶段
```
1. skill_financial_report_generator → 生成 HTML
2. Write → 保存报告文件
3. Bash → 打开浏览器预览
```

---

## 📖 相关文档

| 文档 | 路径 | 内容 |
|------|------|------|
| **完整功能文档** | `docs/CLAUDE_CODE_FEATURES.md` | 所有功能详细说明 |
| **系统提示词** | `core_config/SYSTEM_PROMPT.md` | Agent 行为指南 |
| **Sub-Agent 配置** | `subagents/*.md` | 子代理定义和策略 |
| **使用指南** | `docs/USAGE_GUIDE.md` | 详细使用教程 |
| **更新日志** | `CHANGELOG.md` | 版本历史 |

---

## 💡 常见问题

### Q: 如何启用 WebSearch？
A: WebSearch 仅在美国可用。如在其他地区，使用 WebFetch + Task(search-specialist)。

### Q: 如何添加新的数据源？
A: 编辑 `scripts/fetch_real_gold_data.py`，添加新的 API 函数。

### Q: 如何创建自定义 Sub-Agent？
A: 在 `subagents/` 目录创建 Markdown 配置文件，参考 `subagent_financial_intelligence.md`。

### Q: MCP 和 Plugin 的区别？
A: MCP 用于连接外部服务（数据源、API），Plugin 用于扩展 Claude Code 本身的功能。

---

<div align="center">

**快速 · 高效 · 功能完整**

Claude Code Quick Reference v1.0

</div>
