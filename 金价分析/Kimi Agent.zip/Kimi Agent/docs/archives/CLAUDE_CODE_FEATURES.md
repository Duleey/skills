# Claude Code 原生功能与扩展指南

> **本文档列出所有可用于黄金分析 Agent 的 Claude Code 原生功能、工具、Sub-Agents、Skills 和扩展机制**

---

## 📋 目录

1. [内置工具 (Built-in Tools)](#1-内置工具-built-in-tools)
2. [Sub-Agents (子代理)](#2-sub-agents-子代理)
3. [Skills (技能/命令)](#3-skills-技能命令)
4. [MCP 服务器 (Model Context Protocol)](#4-mcp-服务器-model-context-protocol)
5. [Plugins (插件系统)](#5-plugins-插件系统)
6. [CLI 命令行选项](#6-cli-命令行选项)
7. [推荐配置](#7-推荐配置)

---

## 1. 内置工具 (Built-in Tools)

这些工具在系统提示词中已经可以直接使用：

### 文件操作
- **Read**: 读取文件内容（支持图片、PDF、Jupyter notebook）
- **Write**: 写入新文件或覆盖现有文件
- **Edit**: 精确编辑文件（字符串替换）
- **Glob**: 使用通配符搜索文件（如 `**/*.py`）

### 代码搜索
- **Grep**: 强大的代码搜索工具（基于 ripgrep）
  - 支持正则表达式
  - 支持多行匹配
  - 可过滤文件类型

### 命令执行
- **Bash**: 执行 shell 命令
  - 支持后台运行 (`run_in_background`)
  - 可设置超时（最长 10 分钟）
  - 支持命令链 (`&&`, `;`)

### 网络功能
- **WebSearch**: 搜索互联网（仅美国可用）
  - 支持域名过滤
  - 自动返回搜索结果
- **WebFetch**: 获取网页内容
  - 自动将 HTML 转换为 Markdown
  - 支持 AI 处理提取信息

### AI 协作
- **Task**: 启动专门的子代理执行复杂任务
- **AskUserQuestion**: 向用户提问（支持单选/多选）
- **TodoWrite**: 任务管理和进度跟踪

### 编程工具
- **LSP**: Language Server Protocol 支持
  - 跳转到定义
  - 查找引用
  - 悬停提示
  - 符号搜索

### Jupyter 支持
- **NotebookEdit**: 编辑 Jupyter notebook 单元格

---

## 2. Sub-Agents (子代理)

### 2.1 Claude Code 可用子代理

#### **search-specialist** (搜索专家)
- **职责**: 互联网信息搜索和研究
- **金融应用**:
  - 搜索央行政策声明
  - 查找地缘政治事件
  - 收集分析师报告
  - 获取经济数据发布

#### **business-analyst** (商业分析师)
- **职责**: 商业和财务数据分析
- **金融应用**:
  - 计算 KPI 指标
  - 相关性分析
  - 趋势识别
  - ETF 持仓分析

#### **financial-intelligence-agent** (金融情报代理)
- **职责**: 量化金融与技术分析
- **配置文件**: `subagents/subagent_financial_intelligence.md`
- **金融应用**:
  - 调用金融 API（FRED, Alpha Vantage, Yahoo Finance）
  - 计算技术指标（MA, RSI, MACD, Bollinger Bands）
  - 量化分析（相关性、回归、波动率）
  - 预测建模（ARIMA, 蒙特卡洛）

**详细配置**: 参见 `subagents/` 目录下的配置文件

---

## 3. Skills (技能/命令)

### 3.1 什么是 Skills？

Skills 是 Claude Code 的命令系统，类似于 "斜杠命令"。用户可以通过 `/command` 或 `Skill("command")` 调用。

### 3.2 检查可用 Skills

```bash
# 查看当前项目的 skills
ls ~/.claude/skills/

# 或者在项目目录下
ls .claude/skills/
```

### 3.3 常见内置 Skills（如果安装了）

虽然当前系统显示 "No skills available"，但这些是常见的可安装 skills：

#### 开发相关
- **/commit** - 智能 Git 提交（自动生成 commit message）
- **/review-pr** - 代码审查（分析 Pull Request）
- **/test** - 运行测试套件
- **/debug** - 调试代码问题

#### 文档相关
- **/pdf** - 处理 PDF 文档
- **/explain** - 解释代码或概念
- **/summarize** - 总结长文档

#### 数据相关
- **/analyze-data** - 数据分析和可视化
- **/sql** - SQL 查询和数据库操作

### 3.4 为金融分析创建自定义 Skills

**创建 skill 目录**:
```bash
mkdir -p .claude/skills
```

**示例: 创建 `/gold-price` skill**:
```bash
cat > .claude/skills/gold-price.md << 'EOF'
# Gold Price Query Skill

## Description
快速查询实时黄金价格

## Usage
/gold-price [options]

## Options
- --source: 指定数据源 (coinbase, kitco, lbma)
- --format: 输出格式 (json, text)

## Implementation
\`\`\`bash
python3 scripts/fetch_real_gold_data.py
\`\`\`
EOF
```

---

## 4. MCP 服务器 (Model Context Protocol)

### 4.1 什么是 MCP？

MCP (Model Context Protocol) 是 Claude Code 的扩展机制，允许连接外部服务和数据源。

### 4.2 当前状态

```bash
$ claude mcp list
No MCP servers configured. Use `claude mcp add` to add a server.
```

### 4.3 推荐的金融 MCP 服务器

#### A. **Filesystem MCP** (文件系统访问)
```bash
claude mcp add filesystem-server \
  --command "npx -y @modelcontextprotocol/server-filesystem /path/to/financial/data"
```
**用途**: 安全访问金融数据文件目录

#### B. **PostgreSQL MCP** (数据库访问)
```bash
claude mcp add postgres-server \
  --command "npx -y @modelcontextprotocol/server-postgres postgresql://user:pass@localhost/golddb"
```
**用途**: 查询历史金价数据库

#### C. **Fetch MCP** (HTTP 请求)
```bash
claude mcp add fetch-server \
  --command "npx -y @modelcontextprotocol/server-fetch"
```
**用途**: 调用金融 API

#### D. **自定义金融数据 MCP**

创建自定义 MCP 服务器来封装金融 API：

```json
{
  "mcpServers": {
    "gold-data-api": {
      "command": "node",
      "args": ["./mcp-servers/gold-data-server.js"],
      "env": {
        "FRED_API_KEY": "your_key",
        "ALPHA_VANTAGE_KEY": "your_key"
      }
    }
  }
}
```

**配置文件位置**:
- 全局: `~/.claude/mcp.json`
- 项目: `.claude/mcp.json`

### 4.4 使用 MCP 命令

```bash
# 添加 MCP 服务器
claude mcp add <server-name> --command "<command>"

# 列出 MCP 服务器
claude mcp list

# 移除 MCP 服务器
claude mcp remove <server-name>

# 测试 MCP 服务器
claude mcp test <server-name>
```

---

## 5. Plugins (插件系统)

### 5.1 当前状态

```bash
$ claude plugin list
No plugins found
```

### 5.2 插件目录结构

```
~/.claude/plugins/
└── my-plugin/
    ├── plugin.json       # 插件元数据
    ├── index.js          # 插件主逻辑
    └── README.md         # 说明文档
```

### 5.3 推荐的金融插件

虽然当前没有安装插件，但可以考虑这些方向：

#### A. **Technical Indicators Plugin**
- 封装常用技术指标计算
- 提供快速调用接口
- 缓存历史数据

#### B. **Market Data Plugin**
- 统一多个数据源 API
- 自动故障转移
- 数据质量验证

#### C. **Report Generator Plugin**
- 模板化 HTML/PDF 报告
- 图表自动生成
- 多语言支持

### 5.4 插件管理命令

```bash
# 列出插件
claude plugin list

# 安装插件（从 npm）
claude plugin install <plugin-name>

# 从本地目录加载插件
claude --plugin-dir ./plugins

# 卸载插件
claude plugin uninstall <plugin-name>
```

---

## 6. CLI 命令行选项

### 6.1 金融分析相关的重要选项

#### **指定系统提示词**
```bash
claude --system-prompt "$(cat core_config/SYSTEM_PROMPT.md)"
```

#### **允许特定工具**
```bash
claude --allowed-tools "Bash(python3:*) Read Write WebFetch"
```

#### **加载 MCP 配置**
```bash
claude --mcp-config .claude/mcp.json
```

#### **指定模型**
```bash
# 使用 Sonnet（适合快速分析）
claude --model sonnet

# 使用 Opus（适合复杂预测）
claude --model opus
```

#### **设置权限模式**
```bash
# 自动接受所有编辑（用于自动化）
claude --permission-mode acceptEdits

# 计划模式（先规划再执行）
claude --permission-mode plan
```

#### **自定义 Agent**
```bash
claude --agents '{
  "gold-analyst": {
    "description": "专业黄金市场分析师",
    "prompt": "你是一个专业的黄金市场分析 Agent..."
  }
}'
```

### 6.2 非交互式使用（适合自动化）

```bash
# 打印模式（用于脚本）
claude --print "获取当前金价" --output-format json

# 流式 JSON 输出
claude --print --output-format stream-json --include-partial-messages

# 指定 JSON Schema（结构化输出）
claude --print --json-schema '{
  "type": "object",
  "properties": {
    "price": {"type": "number"},
    "source": {"type": "string"},
    "timestamp": {"type": "string"}
  }
}'
```

### 6.3 会话管理

```bash
# 继续上次对话
claude --continue

# 恢复特定会话
claude --resume <session-id>

# 恢复并创建新分支
claude --resume <session-id> --fork-session

# 使用特定会话 ID
claude --session-id "123e4567-e89b-12d3-a456-426614174000"
```

---

## 7. 推荐配置

### 7.1 项目配置文件

创建 `.claude/settings.json`:

```json
{
  "model": "sonnet",
  "systemPrompt": "core_config/SYSTEM_PROMPT.md",
  "allowedTools": [
    "Bash(python3:*)",
    "Bash(curl:*)",
    "Read",
    "Write",
    "Edit",
    "Glob",
    "Grep",
    "WebSearch",
    "WebFetch",
    "Task"
  ],
  "addDirs": [
    "/Users/siin/Desktop/Announcement"
  ],
  "agents": {
    "gold-analyst": {
      "description": "专业黄金市场分析师",
      "systemPrompt": "core_config/SYSTEM_PROMPT.md"
    }
  }
}
```

### 7.2 MCP 配置文件

创建 `.claude/mcp.json`:

```json
{
  "mcpServers": {
    "gold-data": {
      "command": "python3",
      "args": ["./scripts/fetch_real_gold_data.py", "--mcp-mode"],
      "env": {
        "FRED_API_KEY": "${FRED_API_KEY}",
        "ALPHA_VANTAGE_KEY": "${ALPHA_VANTAGE_KEY}"
      }
    },
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "."]
    }
  }
}
```

### 7.3 启动脚本

创建 `start-gold-agent.sh`:

```bash
#!/bin/bash

# 设置环境变量
export FRED_API_KEY="your_fred_api_key"
export ALPHA_VANTAGE_KEY="your_alpha_vantage_key"

# 启动 Claude Code 金融分析 Agent
claude \
  --system-prompt "$(cat core_config/SYSTEM_PROMPT.md)" \
  --mcp-config .claude/mcp.json \
  --model sonnet \
  --agent gold-analyst \
  --add-dir . \
  --allowed-tools "Bash(python3:*) Bash(curl:*) Read Write Edit Glob Grep WebSearch WebFetch Task" \
  "$@"
```

使用:
```bash
chmod +x start-gold-agent.sh
./start-gold-agent.sh "分析当前黄金市场走势"
```

---

## 8. 完整功能总结

### 当前已配置功能 ✅

| 类别 | 功能 | 状态 |
|------|------|------|
| **内置工具** | Read, Write, Edit, Glob, Grep, Bash, WebSearch, WebFetch, Task, LSP | ✅ 可用 |
| **系统提示词** | 中文版、英文版 | ✅ 已创建 |
| **数据获取脚本** | `fetch_real_gold_data.py` | ✅ 已验证 |
| **Sub-Agents** | search-specialist, business-analyst | ✅ 可用 |
| **自定义 Sub-Agent** | financial-intelligence-agent | ✅ 已配置 |
| **Skills** | skill_financial_data_fetcher, skill_geopolitical_analyst, skill_financial_report_generator | ✅ 已创建 |

### 可扩展功能 🔧

| 类别 | 功能 | 优先级 | 实现难度 |
|------|------|--------|---------|
| **MCP 服务器** | 金融数据 API 封装 | 高 | 中 |
| **MCP 服务器** | 数据库访问（PostgreSQL） | 中 | 中 |
| **MCP 服务器** | 文件系统安全访问 | 低 | 低 |
| **Plugins** | 技术指标计算插件 | 中 | 中 |
| **Plugins** | 报告生成插件 | 低 | 中 |
| **Custom Skills** | /gold-price 命令 | 高 | 低 |
| **Custom Skills** | /technical-analysis 命令 | 中 | 中 |

---

## 9. 下一步行动建议

### 立即可做（无需安装）

1. ✅ **使用系统提示词**: 加载 `core_config/SYSTEM_PROMPT.md`
2. ✅ **运行数据脚本**: `python3 scripts/fetch_real_gold_data.py`
3. ✅ **调用 Sub-Agents**: 使用 `Task()` 工具

### 短期改进（简单配置）

1. 🔧 **创建启动脚本**: `start-gold-agent.sh`
2. 🔧 **配置项目设置**: `.claude/settings.json`
3. 🔧 **创建自定义 Skill**: `/gold-price` 命令

### 中期扩展（需要开发）

1. 🚀 **MCP 金融数据服务器**: 封装所有金融 API
2. 🚀 **技术指标插件**: 快速计算常用指标
3. 🚀 **数据库集成**: 历史数据存储和查询

### 长期优化（高级功能）

1. 🌟 **实时推送系统**: WebSocket 金价推送
2. 🌟 **机器学习预测**: 集成 scikit-learn/TensorFlow
3. 🌟 **多资产关联分析**: 扩展到股票、债券、外汇

---

## 10. 参考资源

### 官方文档
- **Claude Code 文档**: https://docs.anthropic.com/claude-code
- **MCP 协议**: https://modelcontextprotocol.io/
- **API 参考**: https://docs.anthropic.com/api

### 社区资源
- **MCP 服务器集合**: https://github.com/modelcontextprotocol/servers
- **Claude Code GitHub**: https://github.com/anthropics/claude-code

### 金融数据 API
- **FRED API**: https://fred.stlouisfed.org/docs/api/
- **Alpha Vantage**: https://www.alphavantage.co/documentation/
- **Yahoo Finance**: https://github.com/ranaroussi/yfinance
- **Quandl**: https://www.quandl.com/tools/api

---

<div align="center">

**功能完整 · 可扩展 · 生产就绪**

Claude Code Features Guide v1.0

</div>
