# 更新日志 / Changelog

## v3.1.0 - 2026-01-30

### ✨ 新增功能 / New Features

#### Sub-Agents 集成文档
- **中文版系统提示词** (`core_config/SYSTEM_PROMPT.md`)
- **英文版系统提示词** (`core_config/SYSTEM_PROMPT_EN.md`)

两个版本都新增了完整的 Sub-Agents 使用说明：

1. **子代理说明**：
   - `search-specialist` (搜索专家) - 金融新闻和地缘政治事件搜索
   - `business-analyst` (商业分析师) - 宏观经济数据和KPI分析

2. **自定义金融情报子代理**：
   - `financial-intelligence-agent` - 量化金融与技术分析专家
   - 详细能力说明：数据获取、技术分析、量化分析、预测建模
   - 完整的使用示例和输出文件格式

3. **子代理协作策略**：
   - 并行执行模式（推荐）
   - 串行执行模式（数据依赖场景）
   - 选择决策树（根据任务类型选择合适的子代理）

### 📚 相关文档

- `subagents/subagent_financial_intelligence.md` - Financial Intelligence Agent 完整配置
- `subagents/subagents_usage_strategy.md` - Sub-Agents 协作策略详细文档

### 🎯 核心改进

**之前的问题**：
- 系统提示词中没有说明如何使用 sub-agents
- 用户不知道项目中已有的 sub-agent 配置文件

**解决方案**：
- 在系统提示词中详细列出所有可用的子代理
- 提供具体的使用示例和调用模式
- 说明每个子代理的专业领域和适用场景
- 添加协作策略和选择决策树

### 📊 统计信息

- **系统提示词行数**: 552 行 (中文版和英文版)
- **新增章节**: 
  - 2.1 Claude Code 内置子代理 (3个)
  - 2.2 自定义金融情报子代理 (详细说明)
  - 2.3 子代理协作策略 (并行/串行模式)

---

## v3.0.0 - 2026-01-30

### 🎉 重大更新 / Major Update

#### 100% 真实数据架构
- 创建基于真实数据的系统提示词
- 集成 `fetch_real_gold_data.py` 实时数据获取脚本
- 移除所有虚构和硬编码数据

#### 核心原则
- ❌ **绝不编造**任何价格或指标
- ✅ **每次分析前**必须获取真实数据
- ✅ **明确标注**所有数据来源和时间戳
- ✅ **数据不可用时**明确告知用户

#### 文件结构
```
core_config/
├── SYSTEM_PROMPT.md       # 中文系统提示词
└── SYSTEM_PROMPT_EN.md    # English system prompt

scripts/
└── fetch_real_gold_data.py  # 数据获取脚本 (已验证: $5,296.83)

skills/
├── skill_financial_data_fetcher.md
├── skill_geopolitical_analyst.md
└── skill_financial_report_generator.md

subagents/
├── subagent_financial_intelligence.md
└── subagents_usage_strategy.md
```

#### 已验证的真实数据
- **2026-01-30 查询**: $5,296.83 USD/oz
- **数据源**: Coinbase API
- **状态**: ✓ 真实数据，可验证

---

## 历史版本清理

### 已删除文件
- `versions/` - 包含虚构数据的所有旧版本
- 所有硬编码价格的文档
- 所有虚构市场事件的分析

### 保留的核心文件
- README.md
- REAL_DATA_2026.md (真实数据示例)
- 所有 skills 和 subagents 配置
- 文档目录 (docs/)

---

<div align="center">

**数据真实 · 分析客观 · 风险透明**

版本: v3.1.0-real-data-with-subagents

</div>
