# 黄金分析Agent - 快速参考卡

## 🚀 5分钟快速启动

```bash
# 1. 创建目录
mkdir gold-analysis-agent && cd gold-analysis-agent

# 2. 复制配置文件
cp ~/Desktop/Announcement/*.md .

# 3. 启动Claude Code
claude-code

# 4. 加载Agent
"请扮演黄金市场分析Agent，系统提示词在 gold_analysis_agent_system_prompt.md"
```

---

## 📋 常用命令速查

### 基础分析
```plaintext
✅ "分析最近一年黄金走势并预测未来"
✅ "今天金价多少？"
✅ "黄金最近一周涨了多少？"
✅ "昨天黄金大跌，分析原因"
```

### 技术分析
```plaintext
✅ "黄金的技术指标是什么？"
✅ "金价的支撑位和阻力位在哪？"
✅ "黄金是否超买或超卖？"
✅ "给出黄金的交易信号"
```

### 基本面分析
```plaintext
✅ "分析美联储政策对金价的影响"
✅ "央行购金对金价有什么影响？"
✅ "美元走强为什么金价下跌？"
✅ "通胀预期如何影响金价？"
```

### 事件分析
```plaintext
✅ "分析俄乌冲突对金价的影响"
✅ "中东局势如何影响黄金？"
✅ "银行危机时黄金表现如何？"
```

### 报告生成
```plaintext
✅ "生成HTML格式的完整分析报告"
✅ "生成Markdown格式的执行摘要"
✅ "导出分析数据为CSV格式"
```

---

## 🎯 系统组件

### Sub-Agents (3个)
| Name | 用途 | 类型 |
|------|------|------|
| search-specialist | 搜索新闻事件 | 可用 |
| business-analyst | 财务分析 | 可用 |
| financial-intelligence | 技术分析 | **自定义** |

### Skills (3个)
| Name | 用途 | 文件 |
|------|------|------|
| financial-data-fetcher | 数据获取 | skill_financial_data_fetcher.md |
| geopolitical-analyst | 地缘分析 | skill_geopolitical_analyst.md |
| financial-report-generator | 报告生成 | skill_financial_report_generator.md |

---

## 📁 文件结构

```
gold-analysis-agent/
├── config/
│   └── agent_system_prompt.md         # 主Agent配置
├── skills/
│   ├── financial_data_fetcher.md
│   ├── geopolitical_analyst.md
│   └── financial_report_generator.md
├── subagents/
│   └── financial_intelligence.md      # 自定义Sub-Agent
├── data/                               # 数据存储
├── output/                             # 报告输出
└── .env                                # API配置（可选）
```

---

## 🔧 环境变量

```bash
# .env 文件内容
FRED_API_KEY=""              # 可选
ALPHA_VANTAGE_KEY=""         # 可选
DEFAULT_ANALYSIS_PERIOD="1y"
OUTPUT_FORMAT="html"
LANGUAGE="zh-en"
```

---

## ⚙️ Python依赖

```bash
pip install pandas numpy yfinance requests matplotlib statsmodels
```

---

## 🔍 故障排除速查

| 问题 | 快速解决 |
|------|---------|
| Skill未找到 | `/skills list` 检查注册 |
| API失败 | 检查 `$FRED_API_KEY` 或使用免费源 |
| Python报错 | `pip install -r requirements.txt` |
| 报告失败 | 检查 `output/` 目录权限 |
| 数据不一致 | "使用多源交叉验证" |

---

## 📊 性能参考

| 任务 | 预期耗时 |
|------|---------|
| 快速查询 | 5-10秒 |
| 3个月分析 | 2-3分钟 |
| 1年完整分析 | 5-8分钟 |
| 生成HTML报告 | 30-60秒 |

---

## 🎨 输出文件

```
output/
├── gold_analysis_report.html       # 主报告
├── gold_prices_validated.csv       # 验证后的价格数据
├── technical_indicators.csv        # 技术指标
├── correlation_analysis.json       # 相关性分析
└── forecast_12m.csv                # 12个月预测
```

---

## 💡 实用技巧

### 1. 并行执行
```plaintext
"同时获取金价数据、搜索新闻、分析技术指标"
```

### 2. 指定数据源
```plaintext
"使用LBMA官方数据作为金价来源"
```

### 3. 自定义周期
```plaintext
"分析2020-2023年的黄金长期趋势"
```

### 4. 导出格式
```plaintext
"生成适合打印的PDF格式报告"
```

### 5. 简化输出
```plaintext
"只给我关键发现，不需要完整报告"
```

---

## 🆘 获取帮助

```plaintext
# 在Claude Code中输入
"显示黄金分析Agent的使用帮助"
"列出所有可用功能"
"如何自定义报告？"
```

---

## 📖 详细文档

- 📘 [USAGE_GUIDE.md](USAGE_GUIDE.md) - 完整使用教程
- 📗 [ARCHITECTURE_OVERVIEW.md](ARCHITECTURE_OVERVIEW.md) - 系统架构
- 📙 [subagents_usage_strategy.md](subagents_usage_strategy.md) - Sub-Agents详解

---

## ✅ 配置检查清单

快速检查是否配置正确：

```bash
# 1. 检查文件
ls config/agent_system_prompt.md          # ✓
ls skills/*.md                             # ✓ 3个文件
ls subagents/financial_intelligence.md    # ✓

# 2. 检查Python
python3 --version                          # >= 3.8
pip list | grep pandas                     # ✓

# 3. 检查环境变量（可选）
echo $FRED_API_KEY                         # 有或无都可以

# 4. 测试Agent
# 在Claude Code中：
"测试：今天金价多少？"                    # ✓ 返回结果
```

---

## 🎯 典型工作流

```
1. 启动 → 2. 提问 → 3. Agent执行 → 4. 查看报告
   ↓         ↓          ↓              ↓
Claude    "分析      TodoWrite      output/
Code      金价"      + Sub-agents   report.html
                     + Skills
```

---

## 🔗 快速链接

- 🏠 [项目首页](README.md)
- 📚 [完整文档](USAGE_GUIDE.md)
- 🐛 [报告问题](https://github.com/your-org/issues)
- 💬 [讨论社区](https://discord.gg/your-server)

---

**保存此文件以便快速查阅！** 📌

**打印提示**: 此卡片设计为A4单页打印
