# 黄金分析Agent - 完整配置使用教程

## 📖 目录

1. [系统要求](#系统要求)
2. [快速开始（5分钟）](#快速开始)
3. [详细配置步骤](#详细配置步骤)
4. [使用指南](#使用指南)
5. [高级配置](#高级配置)
6. [故障排除](#故障排除)
7. [最佳实践](#最佳实践)

---

## 系统要求

### 必需组件
- Claude Code CLI (已安装)
- Python 3.8+ (用于技术分析)
- 网络连接 (访问金融数据源)

### 可选组件
- API Keys (提升数据质量，免费可选):
  - FRED API Key (Federal Reserve Economic Data)
  - Alpha Vantage API Key (金融市场数据)

### 存储空间
- 最少: 100MB (系统文件 + 临时数据)
- 推荐: 500MB (包含历史数据缓存)

---

## 快速开始

### ⚡ 5分钟快速部署

#### Step 1: 创建项目目录
```bash
# 创建黄金分析Agent工作目录
mkdir gold-analysis-agent
cd gold-analysis-agent

# 创建子目录
mkdir -p config skills subagents data output
```

#### Step 2: 下载配置文件
将以下文件放入对应目录：

```bash
# 项目结构
gold-analysis-agent/
├── config/
│   └── agent_system_prompt.md          # 主Agent配置
├── skills/
│   ├── financial_data_fetcher.md       # Skill 1
│   ├── geopolitical_analyst.md         # Skill 2
│   └── financial_report_generator.md   # Skill 3
├── subagents/
│   └── financial_intelligence.md       # 自定义Sub-Agent
├── data/                                # 数据存储目录
├── output/                              # 报告输出目录
└── README.md                            # 项目说明
```

复制文件：
```bash
# 从你的Desktop/Announcement目录复制配置文件
cp ~/Desktop/Announcement/gold_analysis_agent_system_prompt.md config/agent_system_prompt.md
cp ~/Desktop/Announcement/skill_*.md skills/
cp ~/Desktop/Announcement/subagent_financial_intelligence.md subagents/
```

#### Step 3: 安装Python依赖（可选，用于高级分析）
```bash
# 创建虚拟环境（推荐）
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖
pip install pandas numpy yfinance requests matplotlib
```

#### Step 4: 配置环境变量（可选）
```bash
# 创建 .env 文件
cat > .env << 'EOF'
# API Keys (可选，用于更好的数据获取)
FRED_API_KEY=""           # 留空使用免费数据源
ALPHA_VANTAGE_KEY=""      # 留空使用Yahoo Finance作为替代

# 配置选项
DEFAULT_ANALYSIS_PERIOD="1y"     # 默认分析周期
OUTPUT_FORMAT="html"              # 报告格式: html, pdf
LANGUAGE="zh-en"                  # 语言: zh, en, zh-en
EOF
```

#### Step 5: 启动Claude Code并加载Agent
```bash
# 启动Claude Code CLI
claude-code

# 在Claude Code中执行：
# 方法1: 直接加载系统提示词（推荐）
# 将 config/agent_system_prompt.md 的内容作为系统提示词

# 方法2: 使用对话方式
"你好，我需要你扮演黄金市场分析Agent，请阅读 config/agent_system_prompt.md 文件作为你的系统提示词"
```

✅ **快速开始完成！** 现在可以开始使用了。

---

## 详细配置步骤

### 📋 配置清单

#### 1. 配置主Agent

**文件位置**: `config/agent_system_prompt.md`

这是主Agent的"大脑"，定义了：
- 工作流程和任务分解逻辑
- Sub-agents调用策略
- Skills使用规则
- 数据完整性要求
- 报告生成标准

**无需修改**，开箱即用。

---

#### 2. 注册Skills

Skills需要在Claude Code中注册才能使用。

##### A. 注册 financial-data-fetcher Skill

```bash
# 在Claude Code中执行
/skill create financial-data-fetcher

# 然后粘贴 skills/financial_data_fetcher.md 的内容
```

或者使用配置文件方式：
```bash
# 创建skill配置
mkdir -p ~/.claude-code/skills

# 链接skill文件
ln -s $(pwd)/skills/financial_data_fetcher.md \
      ~/.claude-code/skills/financial-data-fetcher.md
```

##### B. 注册 geopolitical-analyst Skill

```bash
# 方法同上
/skill create geopolitical-analyst
# 粘贴 skills/geopolitical_analyst.md 内容
```

##### C. 注册 financial-report-generator Skill

```bash
/skill create financial-report-generator
# 粘贴 skills/financial_report_generator.md 内容
```

**验证Skills已注册**：
```bash
# 在Claude Code中执行
/skills list

# 应该看到：
# - financial-data-fetcher
# - geopolitical-analyst
# - financial-report-generator
```

---

#### 3. 配置Sub-Agent

##### 创建 financial-intelligence-agent

**方式1: 通过Claude Code配置文件**
```bash
# 创建sub-agent配置目录
mkdir -p ~/.claude-code/subagents

# 复制配置文件
cp subagents/financial_intelligence.md \
   ~/.claude-code/subagents/financial-intelligence-agent.md
```

**方式2: 在系统提示词中内联定义**
```markdown
# 在 agent_system_prompt.md 中添加：

## Available Sub-Agents

### financial-intelligence-agent
Description: Specialized sub-agent for financial data acquisition via APIs...
[粘贴 financial_intelligence.md 的完整内容]
```

**验证Sub-Agent可用**：
```bash
# 在对话中测试
"请列出可用的sub-agents"

# 应该看到：
# - search-specialist (可用)
# - business-analyst (可用)
# - financial-intelligence-agent (自定义)
```

---

#### 4. 配置数据源访问

##### 获取免费API Keys（可选但推荐）

**A. FRED API Key (推荐)**
1. 访问: https://fred.stlouisfed.org/
2. 注册免费账户
3. 导航到: My Account → API Keys
4. 创建新的API Key
5. 复制Key到 `.env` 文件

**B. Alpha Vantage API Key (可选)**
1. 访问: https://www.alphavantage.co/support/#api-key
2. 填写表单获取免费Key
3. 每天500次请求限制
4. 复制Key到 `.env` 文件

**加载环境变量**：
```bash
# 在启动Claude Code前执行
export $(cat .env | grep -v '^#' | xargs)

# 或者在每次会话开始时：
source .env
```

---

#### 5. 测试配置

##### 快速测试
```bash
# 在Claude Code中执行简单测试
"请使用 financial-data-fetcher skill 获取今天的金价"

# 预期输出：
# - Skill被调用
# - 返回当前金价数据
# - 包含数据源引用
```

##### 完整测试
```bash
# 执行一次小规模分析
"请分析最近3个月的黄金价格走势，生成简要报告"

# 预期流程：
# 1. 创建任务列表 (TodoWrite)
# 2. 调用 financial-intelligence-agent 获取数据
# 3. 调用 geopolitical-analyst 查找相关事件
# 4. 调用 business-analyst 进行分析
# 5. 生成报告
```

---

## 使用指南

### 🎯 基础使用

#### 场景1: 分析最近一年黄金走势

```plaintext
用户输入:
"分析2023年1月至2024年1月的黄金价格走势，包括影响因素和未来预测"

Agent执行流程:
1. ✅ 创建任务列表
   - 获取历史金价数据
   - 研究地缘政治事件
   - 计算技术指标
   - 分析相关性
   - 生成预测
   - 输出HTML报告

2. ✅ 并行数据收集
   - financial-intelligence-agent: 从FRED/Yahoo获取金价
   - search-specialist: 搜索2023-2024重大事件
   - financial-data-fetcher: 验证数据质量

3. ✅ 分析阶段
   - 计算MA、RSI、MACD等指标
   - 分析金价与DXY、利率的相关性
   - 识别关键事件的市场影响

4. ✅ 报告生成
   - financial-report-generator: 生成HTML报告
   - 包含图表、时间线、预测

输出文件:
- output/gold_analysis_report_2024-01-30.html
- data/gold_prices_validated.csv
- data/technical_indicators.csv
```

#### 场景2: 昨日大跌原因分析

```plaintext
用户输入:
"昨天黄金大跌，帮我分析原因"

Agent执行流程:
1. ✅ 识别具体日期 (2024-01-29)
2. ✅ 搜索当日重大新闻
   - 美联储声明？
   - 地缘政治变化？
   - 美元走势？
   - 技术面破位？

3. ✅ 量化影响
   - 跌幅: -X%
   - 成交量变化: +Y%
   - 技术指标变化

4. ✅ 生成专项报告
   - 触发事件分析
   - 市场反应评估
   - 后续走势预判

输出:
简明扼要的分析报告（Markdown或HTML）
```

#### 场景3: 未来12个月预测

```plaintext
用户输入:
"预测未来一年黄金价格走势"

Agent执行流程:
1. ✅ 收集当前数据
   - 最新金价
   - 技术指标状态
   - 地缘政治形势
   - 央行政策取向

2. ✅ 构建预测模型
   - 时间序列分析 (ARIMA)
   - 技术面信号
   - 基本面因素

3. ✅ 生成三种情景
   - 牛市情景 (25%概率): 金价上涨至 $X
   - 基准情景 (50%概率): 金价维持在 $Y
   - 熊市情景 (25%概率): 金价回落至 $Z

4. ✅ 输出预测报告
   - 包含置信区间
   - 关键假设说明
   - 风险因素提示

输出:
带有预测图表的HTML报告
```

---

### 🎨 高级使用技巧

#### 技巧1: 自定义分析周期

```plaintext
# 短期分析（1-3个月）
"分析最近3个月黄金短期走势，关注技术面信号"

# 中期分析（6-12个月）
"分析半年来的黄金走势，重点是基本面因素"

# 长期分析（2-5年）
"分析过去5年黄金的长期趋势，包括周期性模式"
```

#### 技巧2: 指定关注重点

```plaintext
# 技术分析为主
"纯技术面分析黄金，给出支撑位、阻力位和交易信号"

# 基本面分析为主
"从基本面角度分析黄金，关注央行购金、通胀预期、美元走势"

# 事件驱动分析
"分析俄乌冲突对黄金价格的影响"
```

#### 技巧3: 对比分析

```plaintext
# 与其他资产对比
"对比分析黄金、比特币、美债作为避险资产的表现"

# 不同时期对比
"对比2008金融危机和2020疫情期间黄金的表现"
```

#### 技巧4: 导出不同格式

```plaintext
# HTML报告（默认）
"生成HTML格式的黄金分析报告"

# PDF报告
"生成PDF格式的报告，适合打印"

# 数据导出
"导出分析用的原始数据为CSV格式"

# Markdown摘要
"生成Markdown格式的执行摘要"
```

---

### 📊 命令参考

#### 常用对话命令

```plaintext
# 1. 完整分析
"分析[时期]黄金走势并预测未来"

# 2. 快速查询
"今天金价多少？"
"黄金最近一周涨了还是跌了？"

# 3. 事件分析
"分析[事件]对黄金价格的影响"

# 4. 技术分析
"黄金当前的技术指标是什么？"
"黄金的支撑位和阻力位在哪？"

# 5. 数据查询
"列出2023年黄金价格的月度数据"

# 6. 报告定制
"生成一份针对投资者的黄金分析报告"
"生成一份学术研究用的黄金数据分析"
```

#### Skills直接调用（高级）

```plaintext
# 调用数据获取skill
"使用 financial-data-fetcher skill 获取LBMA黄金数据"

# 调用地缘分析skill
"使用 geopolitical-analyst skill 分析中东冲突影响"

# 调用报告生成skill
"使用 financial-report-generator skill 生成HTML报告"
```

#### Sub-Agents任务分配（高级）

```plaintext
# 指定使用特定sub-agent
"让 financial-intelligence-agent 计算黄金的技术指标"

# 并行执行多个任务
"同时让 search-specialist 搜索新闻，business-analyst 分析ETF持仓"
```

---

## 高级配置

### 🔧 性能优化

#### 1. 启用数据缓存

```bash
# 创建缓存配置
cat > config/cache_config.json << 'EOF'
{
  "cache_enabled": true,
  "cache_ttl": {
    "price_data": 3600,        // 1小时
    "news_events": 7200,        // 2小时
    "technical_indicators": 1800 // 30分钟
  },
  "cache_path": "data/cache/"
}
EOF
```

#### 2. 并行执行优化

在系统提示词中配置：
```markdown
## Parallel Execution Settings
- Max concurrent sub-agents: 4
- Max concurrent skills: 3
- Timeout per task: 120 seconds
```

#### 3. 输出压缩

```bash
# 启用报告压缩
echo "COMPRESS_OUTPUT=true" >> .env
echo "COMPRESS_IMAGES=true" >> .env
```

---

### 🎨 自定义报告样式

#### 修改HTML模板

编辑 `skills/financial_report_generator.md` 中的CSS：

```css
/* 修改配色方案 */
:root {
    --primary-blue: #1e3c72;      /* 改为你喜欢的颜色 */
    --accent-gold: #d4af37;       /* 金色主题 */
    --text-dark: #2c3e50;
}

/* 修改字体 */
body {
    font-family: 'Your-Preferred-Font', sans-serif;
}
```

#### 添加公司Logo

在报告头部添加：
```html
<header class="report-header">
    <img src="your-logo.png" alt="Company Logo" class="logo">
    <h1>黄金市场分析报告</h1>
</header>
```

---

### 📡 集成外部系统

#### 1. Webhook通知

```python
# 在报告生成后发送通知
import requests

def send_webhook(report_path):
    webhook_url = "https://your-webhook.com/notify"
    payload = {
        "report_generated": report_path,
        "timestamp": datetime.now().isoformat()
    }
    requests.post(webhook_url, json=payload)
```

#### 2. 邮件发送

```python
# 自动发送报告到邮箱
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def email_report(report_html):
    msg = MIMEMultipart()
    msg['Subject'] = '黄金市场分析报告'
    msg['From'] = 'agent@example.com'
    msg['To'] = 'recipient@example.com'

    msg.attach(MIMEText(report_html, 'html'))

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login('your_email', 'your_password')
        server.send_message(msg)
```

#### 3. API接口

```python
# 创建REST API端点
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/api/gold-analysis', methods=['POST'])
def analyze_gold():
    params = request.json
    period = params.get('period', '1y')

    # 调用Claude Agent
    result = claude_agent.analyze(period)

    return jsonify({
        'status': 'success',
        'report_url': result['report_path'],
        'summary': result['summary']
    })
```

---

### 🔐 安全配置

#### 1. API Key管理

```bash
# 使用密钥管理工具
brew install pass  # macOS
apt install pass   # Linux

# 存储API keys
pass insert claude-code/fred-api-key
pass insert claude-code/alphavantage-key

# 在脚本中读取
export FRED_API_KEY=$(pass show claude-code/fred-api-key)
```

#### 2. 访问控制

```yaml
# config/access_control.yaml
allowed_users:
  - user1@company.com
  - user2@company.com

permissions:
  user1@company.com:
    - read_reports
    - generate_reports
  user2@company.com:
    - read_reports
```

---

## 故障排除

### ❌ 常见问题

#### 问题1: Skills无法找到

**症状**:
```
Error: Skill 'financial-data-fetcher' not found
```

**解决方案**:
```bash
# 1. 检查skill是否注册
/skills list

# 2. 重新注册skill
/skill create financial-data-fetcher
# 粘贴配置内容

# 3. 重启Claude Code
```

#### 问题2: API请求失败

**症状**:
```
Error: Failed to fetch data from FRED API
Rate limit exceeded
```

**解决方案**:
```bash
# 1. 检查API key是否正确
echo $FRED_API_KEY

# 2. 检查API配额
curl "https://api.stlouisfed.org/fred/series?series_id=GOLDAMGBD228NLBM&api_key=$FRED_API_KEY"

# 3. 使用备用数据源（Yahoo Finance）
# Agent会自动切换到免费数据源
```

#### 问题3: Python依赖缺失

**症状**:
```
ModuleNotFoundError: No module named 'pandas'
```

**解决方案**:
```bash
# 安装缺失的包
pip install pandas numpy yfinance

# 或安装所有依赖
pip install -r requirements.txt

# 创建requirements.txt
cat > requirements.txt << 'EOF'
pandas>=1.5.0
numpy>=1.23.0
yfinance>=0.2.0
requests>=2.28.0
matplotlib>=3.6.0
statsmodels>=0.14.0
EOF
```

#### 问题4: 报告生成失败

**症状**:
```
Error: Failed to generate HTML report
Template rendering error
```

**解决方案**:
```bash
# 1. 检查输出目录权限
chmod 755 output/

# 2. 检查磁盘空间
df -h

# 3. 查看详细错误日志
# 在Agent中请求详细日志：
"显示报告生成的详细错误信息"

# 4. 使用简化模板
"生成Markdown格式的简化报告"
```

#### 问题5: 数据质量问题

**症状**:
```
Warning: Data discrepancy detected
LBMA: $2045.30
Yahoo: $2048.50
```

**解决方案**:
```bash
# 1. 使用多源验证
"请交叉验证多个数据源的金价数据"

# 2. 指定优先数据源
"使用LBMA作为主要数据源，Yahoo Finance作为备用"

# 3. 检查数据时间戳
"显示每个数据点的时间戳和数据源"
```

---

### 🐛 调试模式

#### 启用详细日志

```bash
# 在 .env 中添加
DEBUG_MODE=true
LOG_LEVEL=DEBUG
LOG_FILE=logs/agent_debug.log

# 创建日志目录
mkdir -p logs
```

#### 查看执行流程

```plaintext
# 在对话中请求
"显示刚才任务的详细执行流程"

# 预期输出：
Step 1: Task planning [✓] - 2.3s
Step 2: Data collection [✓] - 45.2s
  ├─ financial-intelligence-agent [✓] - 30.1s
  ├─ search-specialist [✓] - 15.1s
  └─ financial-data-fetcher [✓] - 12.3s
Step 3: Analysis [✓] - 25.8s
Step 4: Report generation [✓] - 8.5s
Total: 81.8s
```

#### 单步执行测试

```plaintext
# 测试单个组件
"只执行数据获取步骤，不要分析"
"只计算技术指标，使用已有数据"
"只生成报告，使用之前的分析结果"
```

---

### 📞 获取帮助

#### 查看文档

```bash
# 查看配置文档
cat config/agent_system_prompt.md | grep -A 10 "## Core Capabilities"

# 查看skill文档
cat skills/financial_data_fetcher.md | grep -A 5 "## When to Use"
```

#### 内置帮助命令

```plaintext
# 在Claude Code中
"显示黄金分析Agent的使用帮助"
"列出所有可用的分析功能"
"如何自定义报告样式？"
```

#### 社区支持

- GitHub Issues: [报告问题]
- Discord: [加入社区]
- Email: support@example.com

---

## 最佳实践

### ✅ 推荐做法

1. **定期更新数据**
   ```bash
   # 每日早上获取最新数据
   "更新最新的黄金价格和市场新闻"
   ```

2. **保存历史报告**
   ```bash
   # 自动备份报告
   cp output/gold_analysis_report.html \
      output/archive/report_$(date +%Y%m%d).html
   ```

3. **使用版本控制**
   ```bash
   # 跟踪配置变更
   git init
   git add config/ skills/ subagents/
   git commit -m "Initial agent configuration"
   ```

4. **监控数据质量**
   ```plaintext
   # 定期检查
   "显示最近一周的数据质量报告"
   ```

5. **备份API Keys**
   ```bash
   # 安全备份
   gpg -c .env
   # 生成加密的 .env.gpg 文件
   ```

---

### ❌ 避免的做法

1. ❌ 不要在公共仓库提交 `.env` 文件
2. ❌ 不要频繁请求API（避免触发限流）
3. ❌ 不要忽略数据质量警告
4. ❌ 不要修改核心系统提示词（除非你知道在做什么）
5. ❌ 不要在生产环境使用DEBUG模式

---

## 📈 性能基准

### 典型执行时间

| 任务类型 | 预期时间 | 优化后 |
|---------|---------|--------|
| 快速金价查询 | 5-10秒 | 3-5秒 (缓存) |
| 3个月走势分析 | 2-3分钟 | 1-2分钟 |
| 1年完整分析 | 5-8分钟 | 3-5分钟 |
| 5年长期分析 | 10-15分钟 | 8-12分钟 |

### 资源使用

| 指标 | 典型值 | 峰值 |
|-----|-------|------|
| 内存 | 200-500MB | 1GB |
| CPU | 30-50% | 80% |
| 网络 | 5-20MB | 50MB |
| 磁盘 | 100MB | 500MB |

---

## 🎓 学习资源

### 教程视频（建议制作）
1. 5分钟快速入门
2. 完整配置演示
3. 高级功能使用
4. 自定义开发指南

### 示例项目
```bash
# 克隆示例项目
git clone https://github.com/your-org/gold-agent-examples
cd gold-agent-examples

# 查看不同场景的配置
ls examples/
# - basic_analysis/
# - advanced_forecasting/
# - custom_reporting/
# - api_integration/
```

### 相关文档
- [ARCHITECTURE_OVERVIEW.md](ARCHITECTURE_OVERVIEW.md) - 系统架构
- [subagents_usage_strategy.md](subagents_usage_strategy.md) - Sub-Agents详解
- [skill_*.md](skills/) - Skills详细文档

---

## 📝 总结

### 配置检查清单

- [ ] 项目目录已创建
- [ ] 配置文件已复制到正确位置
- [ ] Python依赖已安装（可选）
- [ ] API Keys已配置（可选）
- [ ] Skills已注册
- [ ] Sub-Agent已配置
- [ ] 测试执行成功
- [ ] 文档已阅读

### 下一步

1. **初次使用**: 尝试基础分析任务
   ```plaintext
   "分析最近3个月黄金价格走势"
   ```

2. **探索功能**: 尝试不同类型的分析
   ```plaintext
   "预测未来6个月金价"
   "分析美联储政策对金价的影响"
   ```

3. **自定义配置**: 根据需求调整参数
   - 修改报告样式
   - 添加自定义数据源
   - 集成到现有系统

4. **高级应用**: 开发自动化流程
   - 定时生成报告
   - API集成
   - 告警系统

---

## 💬 反馈与贡献

遇到问题或有改进建议？

- 📧 Email: feedback@example.com
- 💬 Discord: [加入讨论]
- 🐛 GitHub Issues: [报告Bug]
- 📖 Wiki: [贡献文档]

---

**版本**: 1.0.0
**最后更新**: 2024-01-30
**维护者**: Gold Analysis Team

**祝你使用愉快！** 🚀📈💰
