# 项目整理计划

## 📋 当前问题

### 1. 重复的配置文件
- ❌ `core_config/` - 旧的配置目录（与 `.claude/prompts/` 重复）
- ❌ `skills/` - 旧的 Skills 目录（与 `.claude/skills/` 重复）
- ❌ `subagents/` - 旧的 Sub-agents 目录（与 `.claude/agents/` 重复）

### 2. 根目录文档过多
根目录有 8 个 Markdown 文档，需要分类整理：
- `README.md` - 主文档（保留在根目录）
- `USER_PROMPT_EXAMPLE.md` - 使用示例（保留在根目录）
- `CAPABILITY_COMPARISON.md` - 能力对比
- `DIRECTORY_STRUCTURE_VERIFICATION.md` - 目录验证
- `UPDATE_LOG.md` - 更新日志
- `CHANGELOG.md` - 变更日志
- `REAL_DATA_2026.md` - 真实数据说明

### 3. docs/ 目录文档需要更新
- `ARCHITECTURE_OVERVIEW.md` - 可能过时
- `CLAUDE_CODE_FEATURES.md` - 可能过时
- `FILE_MANIFEST.md` - 需要更新
- `QUICK_REFERENCE.md` - 需要更新
- `USAGE_GUIDE.md` - 需要更新

---

## 🎯 整理方案

### 方案A：精简结构（推荐）

```
Announcement/
├── .claude/                    # Claude Code 配置（核心）
│   ├── prompts/               # 系统提示词
│   ├── skills/                # Skills 定义
│   ├── agents/                # Sub-agents 配置
│   ├── config/                # 其他配置
│   ├── settings.json          # 主配置
│   └── mcp.json               # MCP 配置
│
├── docs/                       # 所有文档集中在这里
│   ├── README.md              # 文档索引
│   ├── QUICK_START.md         # 快速开始
│   ├── ARCHITECTURE.md        # 架构说明
│   ├── CAPABILITY.md          # 能力说明
│   ├── CHANGELOG.md           # 变更日志
│   └── archives/              # 归档文档
│       └── old_docs...
│
├── scripts/                    # 脚本（保留）
│   ├── fetch_real_gold_data.py
│   └── setup.sh
│
├── archives/                   # 归档旧配置（可选删除）
│   ├── core_config/
│   ├── skills/
│   └── subagents/
│
├── README.md                   # 项目主文档
├── USER_PROMPT_EXAMPLE.md     # 使用示例
└── start-gold-agent.sh        # 启动脚本
```

### 方案B：保留备份结构

```
Announcement/
├── .claude/                    # 当前使用的配置
├── docs/                       # 文档
├── scripts/                    # 脚本
├── backup/                     # 备份旧配置
│   ├── core_config/
│   ├── skills/
│   └── subagents/
├── README.md
├── USER_PROMPT_EXAMPLE.md
└── start-gold-agent.sh
```

---

## 🗂️ 文件分类

### 保留在根目录（3个文件）
- ✅ `README.md` - 项目主文档
- ✅ `USER_PROMPT_EXAMPLE.md` - 使用示例（重要参考）
- ✅ `start-gold-agent.sh` - 启动脚本

### 移动到 docs/（5个文件）
- 📝 `CAPABILITY_COMPARISON.md` → `docs/CAPABILITY.md`
- 📝 `DIRECTORY_STRUCTURE_VERIFICATION.md` → `docs/DIRECTORY_STRUCTURE.md`
- 📝 `UPDATE_LOG.md` → `docs/UPDATE_LOG.md`
- 📝 `REAL_DATA_2026.md` → `docs/DATA_SOURCES.md`
- 📝 `CHANGELOG.md` → 保留或合并到 `docs/CHANGELOG.md`

### 归档或删除
- 🗑️ `core_config/` → 删除（已复制到 `.claude/prompts/`）
- 🗑️ `skills/` → 删除（已复制到 `.claude/skills/`）
- 🗑️ `subagents/` → 删除（已复制到 `.claude/agents/`）

或者改为：
- 📦 `core_config/` → `archives/core_config/`
- 📦 `skills/` → `archives/skills/`
- 📦 `subagents/` → `archives/subagents/`

---

## 📄 docs/ 目录重组

### 新的 docs/ 结构

```
docs/
├── README.md                   # 文档索引
├── 01-QUICK_START.md          # 快速开始指南
├── 02-ARCHITECTURE.md         # 系统架构说明
├── 03-SKILLS.md               # Skills 详细说明
├── 04-DATA_SOURCES.md         # 数据源说明
├── 05-CAPABILITY.md           # 能力对比
├── 06-DIRECTORY_STRUCTURE.md  # 目录结构说明
├── CHANGELOG.md               # 变更日志
├── UPDATE_LOG.md              # 更新日志
└── archives/                  # 旧文档归档
    ├── ARCHITECTURE_OVERVIEW.md
    ├── CLAUDE_CODE_FEATURES.md
    ├── FILE_MANIFEST.md
    ├── QUICK_REFERENCE.md
    ├── QUICK_REFERENCE_CLAUDE.md
    └── USAGE_GUIDE.md
```

---

## ✅ 推荐操作步骤

### 步骤1：整理根目录文档
```bash
# 移动文档到 docs/
mv CAPABILITY_COMPARISON.md docs/05-CAPABILITY.md
mv DIRECTORY_STRUCTURE_VERIFICATION.md docs/06-DIRECTORY_STRUCTURE.md
mv UPDATE_LOG.md docs/UPDATE_LOG.md
mv REAL_DATA_2026.md docs/04-DATA_SOURCES.md

# 合并 CHANGELOG.md 到 docs/ 或删除重复
```

### 步骤2：归档旧文档
```bash
# 创建归档目录
mkdir -p docs/archives

# 移动旧文档
mv docs/ARCHITECTURE_OVERVIEW.md docs/archives/
mv docs/CLAUDE_CODE_FEATURES.md docs/archives/
mv docs/FILE_MANIFEST.md docs/archives/
mv docs/QUICK_REFERENCE.md docs/archives/
mv docs/QUICK_REFERENCE_CLAUDE.md docs/archives/
mv docs/USAGE_GUIDE.md docs/archives/
mv docs/gold_market_analysis_2026.md docs/archives/
```

### 步骤3：处理重复配置目录
```bash
# 选项A：直接删除（推荐）
rm -rf core_config/
rm -rf skills/
rm -rf subagents/

# 选项B：归档备份
mkdir -p archives/
mv core_config/ archives/
mv skills/ archives/
mv subagents/ archives/
```

### 步骤4：创建文档索引
```bash
# 创建 docs/README.md
cat > docs/README.md << 'EOF'
# 黄金分析 Agent 文档

## 📖 文档导航

### 快速开始
- [快速开始指南](01-QUICK_START.md) - 5分钟上手
- [使用示例](../USER_PROMPT_EXAMPLE.md) - 完整任务示例

### 系统说明
- [系统架构](02-ARCHITECTURE.md) - 整体架构设计
- [Skills 详解](03-SKILLS.md) - 3个专业 Skills 说明
- [数据源说明](04-DATA_SOURCES.md) - 公开数据源列表

### 功能说明
- [能力对比](05-CAPABILITY.md) - 更新前后对比
- [目录结构](06-DIRECTORY_STRUCTURE.md) - 项目目录说明

### 更新记录
- [更新日志](UPDATE_LOG.md) - 详细更新记录
- [变更日志](CHANGELOG.md) - 版本变更历史

### 归档文档
- [归档文档](archives/) - 旧版本文档
EOF
```

---

## 🎯 最终目录结构

```
Announcement/
├── .claude/                              ✅ Claude Code 配置
│   ├── prompts/
│   ├── skills/
│   ├── agents/
│   ├── config/
│   ├── settings.json
│   └── mcp.json
│
├── docs/                                 ✅ 所有文档
│   ├── README.md                         # 文档索引
│   ├── 01-QUICK_START.md
│   ├── 02-ARCHITECTURE.md
│   ├── 03-SKILLS.md
│   ├── 04-DATA_SOURCES.md
│   ├── 05-CAPABILITY.md
│   ├── 06-DIRECTORY_STRUCTURE.md
│   ├── CHANGELOG.md
│   ├── UPDATE_LOG.md
│   └── archives/                         # 旧文档归档
│
├── scripts/                              ✅ 脚本
│   ├── fetch_real_gold_data.py
│   └── setup.sh
│
├── README.md                             ✅ 项目主文档
├── USER_PROMPT_EXAMPLE.md               ✅ 使用示例
└── start-gold-agent.sh                  ✅ 启动脚本
```

**删除的目录**：
- ❌ `core_config/` - 已迁移到 `.claude/prompts/`
- ❌ `skills/` - 已迁移到 `.claude/skills/`
- ❌ `subagents/` - 已迁移到 `.claude/agents/`

---

## 📊 整理收益

### 清理前
- 📁 7个顶层目录
- 📝 8个根目录文档
- 🔄 3组重复配置文件

### 清理后
- 📁 3个顶层目录（.claude, docs, scripts）
- 📝 3个根目录文档（README, USER_PROMPT, start script）
- 🔄 0个重复文件
- ✅ 文档结构清晰，易于导航
- ✅ 配置集中在 `.claude/`，符合标准

---

## ❓ 你的选择

请告诉我你想采用哪种方案：

**选项1**：直接删除旧配置目录（`core_config/`, `skills/`, `subagents/`）
**选项2**：归档到 `archives/` 目录保留备份
**选项3**：保持现状，仅整理文档

我推荐**选项1**（直接删除），因为：
- ✅ 旧配置已完整复制到 `.claude/`
- ✅ 减少混淆，避免错误引用
- ✅ 项目更简洁清晰
