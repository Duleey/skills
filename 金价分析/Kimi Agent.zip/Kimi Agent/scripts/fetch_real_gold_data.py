#!/usr/bin/env python3
"""
真实黄金市场数据获取脚本
支持多个数据源，自动选择可用的API
"""

import json
import sys
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

def fetch_data(url, headers=None):
    """通用数据获取函数"""
    try:
        if headers:
            req = Request(url, headers=headers)
        else:
            req = Request(url)

        with urlopen(req, timeout=10) as response:
            data = response.read().decode('utf-8')
            return json.loads(data) if data else None
    except (URLError, HTTPError, json.JSONDecodeError) as e:
        return None

def get_gold_price_from_metals_api():
    """从 Metals-API 获取数据（免费）"""
    print("尝试从 Metals-API 获取数据...", file=sys.stderr)
    # 这需要免费API key: https://metals-api.com/
    # 替换 YOUR_API_KEY
    url = "https://metals-api.com/api/latest?access_key=YOUR_API_KEY&base=USD&symbols=XAU"
    data = fetch_data(url)

    if data and 'rates' in data and 'XAU' in data['rates']:
        # XAU 是每美元多少盎司，需要转换
        price = 1 / data['rates']['XAU']
        return {
            'source': 'Metals-API',
            'price': round(price, 2),
            'currency': 'USD',
            'unit': 'per ounce',
            'timestamp': data.get('timestamp'),
            'success': True
        }
    return None

def get_gold_price_from_forex():
    """从 Forex API 获取数据"""
    print("尝试从 Forex API 获取数据...", file=sys.stderr)
    url = "https://api.exchangerate.host/latest?base=XAU&symbols=USD"
    data = fetch_data(url)

    if data and 'rates' in data and 'USD' in data['rates']:
        price = data['rates']['USD']
        return {
            'source': 'ExchangeRate.host',
            'price': round(price, 2),
            'currency': 'USD',
            'unit': 'per ounce',
            'date': data.get('date'),
            'success': True
        }
    return None

def get_gold_price_from_coinbase():
    """从 Coinbase 获取黄金相关价格（参考）"""
    print("尝试从 Coinbase 获取参考数据...", file=sys.stderr)
    url = "https://api.coinbase.com/v2/exchange-rates?currency=XAU"
    data = fetch_data(url)

    if data and 'data' in data and 'rates' in data['data']:
        rates = data['data']['rates']
        if 'USD' in rates:
            price = float(rates['USD'])
            return {
                'source': 'Coinbase (Reference)',
                'price': round(price, 2),
                'currency': 'USD',
                'unit': 'per ounce',
                'success': True,
                'note': '参考价格，非官方金价'
            }
    return None

def get_gold_price_from_polygon():
    """从 Polygon.io 获取数据（需要免费API key）"""
    print("尝试从 Polygon.io 获取数据...", file=sys.stderr)
    # 免费API key: https://polygon.io/
    url = "https://api.polygon.io/v2/aggs/ticker/C:XAUUSD/prev?apiKey=YOUR_API_KEY"
    data = fetch_data(url)

    if data and 'results' in data and len(data['results']) > 0:
        result = data['results'][0]
        return {
            'source': 'Polygon.io',
            'price': round(result['c'], 2),  # close price
            'currency': 'USD',
            'unit': 'per ounce',
            'volume': result.get('v'),
            'open': result.get('o'),
            'high': result.get('h'),
            'low': result.get('l'),
            'timestamp': result.get('t'),
            'success': True
        }
    return None

def get_fallback_data():
    """备用方案：提供如何手动获取数据的说明"""
    return {
        'source': 'Manual Instructions',
        'success': False,
        'message': '无法自动获取数据，请手动查询以下网站：',
        'recommended_sources': [
            {
                'name': 'Kitco',
                'url': 'https://www.kitco.com/charts/livegold.html',
                'note': '业界标准，实时金价'
            },
            {
                'name': 'BullionVault',
                'url': 'https://www.bullionvault.com/gold-price-chart.do',
                'note': '实时金价图表'
            },
            {
                'name': 'GoldPrice.org',
                'url': 'https://goldprice.org/',
                'note': '多币种金价'
            },
            {
                'name': 'World Gold Council',
                'url': 'https://www.gold.org/goldhub/data/gold-prices',
                'note': '官方金价数据'
            },
            {
                'name': 'LBMA',
                'url': 'https://www.lbma.org.uk/prices-and-data/precious-metal-prices',
                'note': '伦敦金银市场协会官方定盘价'
            }
        ],
        'instructions': [
            '1. 访问上述任一网站',
            '2. 查看当前金价（USD per ounce）',
            '3. 记录价格、日期和时间',
            '4. 将数据填入配置文件中'
        ]
    }

def main():
    """主函数：尝试所有数据源"""
    print("=" * 60, file=sys.stderr)
    print("黄金市场真实数据获取工具", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", file=sys.stderr)
    print("", file=sys.stderr)

    # 按优先级尝试各个数据源
    data_sources = [
        get_gold_price_from_forex,
        get_gold_price_from_polygon,
        get_gold_price_from_metals_api,
        get_gold_price_from_coinbase,
    ]

    results = []
    for source_func in data_sources:
        result = source_func()
        if result and result.get('success'):
            results.append(result)
            print(f"✓ {result['source']}: ${result['price']}/盎司", file=sys.stderr)
        else:
            print(f"✗ {source_func.__name__} 获取失败", file=sys.stderr)
        print("", file=sys.stderr)

    # 输出结果
    if results:
        print("=" * 60, file=sys.stderr)
        print(f"成功获取 {len(results)} 个数据源", file=sys.stderr)
        print("=" * 60, file=sys.stderr)

        output = {
            'success': True,
            'query_time': datetime.now().isoformat(),
            'data_sources': results,
            'average_price': round(sum(r['price'] for r in results) / len(results), 2)
        }
    else:
        print("=" * 60, file=sys.stderr)
        print("⚠ 所有自动数据源均不可用", file=sys.stderr)
        print("=" * 60, file=sys.stderr)
        output = get_fallback_data()

    # 输出JSON到stdout
    print(json.dumps(output, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
