#!/bin/bash
# Gold Analysis Agent - Setup Script
# 黄金分析Agent - 一键安装脚本

set -e  # Exit on error

echo "================================================"
echo "  Gold Analysis Agent - Setup Wizard"
echo "  黄金分析Agent - 配置向导"
echo "================================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if running in correct directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo -e "${BLUE}[1/8] Checking system requirements...${NC}"

# Check Python
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    echo -e "${GREEN}✓ Python 3 found: $PYTHON_VERSION${NC}"
else
    echo -e "${RED}✗ Python 3 not found. Please install Python 3.8+${NC}"
    exit 1
fi

# Check pip
if command -v pip3 &> /dev/null; then
    echo -e "${GREEN}✓ pip3 found${NC}"
else
    echo -e "${YELLOW}⚠ pip3 not found, attempting to install...${NC}"
    python3 -m ensurepip --upgrade
fi

echo ""
echo -e "${BLUE}[2/8] Creating directory structure...${NC}"

# Create directories
mkdir -p config
mkdir -p skills
mkdir -p subagents
mkdir -p data/{cache,raw,processed}
mkdir -p output/{reports,archive}
mkdir -p logs

echo -e "${GREEN}✓ Directories created${NC}"

echo ""
echo -e "${BLUE}[3/8] Checking for configuration files...${NC}"

# Check if config files exist
REQUIRED_FILES=(
    "gold_analysis_agent_system_prompt.md"
    "skill_financial_data_fetcher.md"
    "skill_geopolitical_analyst.md"
    "skill_financial_report_generator.md"
    "subagent_financial_intelligence.md"
)

MISSING_FILES=()
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓ Found: $file${NC}"
    else
        echo -e "${RED}✗ Missing: $file${NC}"
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -ne 0 ]; then
    echo ""
    echo -e "${YELLOW}Warning: Missing ${#MISSING_FILES[@]} configuration file(s)${NC}"
    echo "Please ensure all configuration files are in the current directory."
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo ""
echo -e "${BLUE}[4/8] Copying configuration files...${NC}"

# Copy config files to appropriate directories
if [ -f "gold_analysis_agent_system_prompt.md" ]; then
    cp gold_analysis_agent_system_prompt.md config/agent_system_prompt.md
    echo -e "${GREEN}✓ Main agent config copied${NC}"
fi

if [ -f "skill_financial_data_fetcher.md" ]; then
    cp skill_financial_data_fetcher.md skills/
    echo -e "${GREEN}✓ Skill 1 copied${NC}"
fi

if [ -f "skill_geopolitical_analyst.md" ]; then
    cp skill_geopolitical_analyst.md skills/
    echo -e "${GREEN}✓ Skill 2 copied${NC}"
fi

if [ -f "skill_financial_report_generator.md" ]; then
    cp skill_financial_report_generator.md skills/
    echo -e "${GREEN}✓ Skill 3 copied${NC}"
fi

if [ -f "subagent_financial_intelligence.md" ]; then
    cp subagent_financial_intelligence.md subagents/
    echo -e "${GREEN}✓ Sub-agent config copied${NC}"
fi

echo ""
echo -e "${BLUE}[5/8] Setting up Python environment...${NC}"

# Ask if user wants to create virtual environment
read -p "Create Python virtual environment? (recommended) (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
    echo "Activating virtual environment..."
    source venv/bin/activate
    echo -e "${GREEN}✓ Virtual environment activated${NC}"
fi

echo ""
echo -e "${BLUE}[6/8] Installing Python dependencies...${NC}"

# Create requirements.txt
cat > requirements.txt << 'EOF'
pandas>=1.5.0
numpy>=1.23.0
yfinance>=0.2.0
requests>=2.28.0
matplotlib>=3.6.0
statsmodels>=0.14.0
scipy>=1.9.0
EOF

echo "Installing packages (this may take a few minutes)..."
pip3 install -q -r requirements.txt

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Python dependencies installed${NC}"
else
    echo -e "${YELLOW}⚠ Some packages failed to install. You may need to install them manually.${NC}"
fi

echo ""
echo -e "${BLUE}[7/8] Configuring environment variables...${NC}"

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    cat > .env << 'EOF'
# API Keys (optional - leave empty to use free data sources)
FRED_API_KEY=""
ALPHA_VANTAGE_KEY=""

# Configuration
DEFAULT_ANALYSIS_PERIOD="1y"
OUTPUT_FORMAT="html"
LANGUAGE="zh-en"
DEBUG_MODE="false"

# Paths
DATA_PATH="data/"
OUTPUT_PATH="output/"
CACHE_PATH="data/cache/"
LOG_PATH="logs/"

# Performance
MAX_CONCURRENT_AGENTS=4
TASK_TIMEOUT=120
ENABLE_CACHE=true
CACHE_TTL=3600
EOF
    echo -e "${GREEN}✓ .env file created${NC}"

    echo ""
    echo -e "${YELLOW}Optional: Configure API keys for better data access${NC}"
    read -p "Do you want to configure API keys now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo ""
        echo "FRED API Key (free from https://fred.stlouisfed.org/)"
        read -p "Enter FRED API Key (or press Enter to skip): " FRED_KEY
        if [ ! -z "$FRED_KEY" ]; then
            sed -i.bak "s/FRED_API_KEY=\"\"/FRED_API_KEY=\"$FRED_KEY\"/" .env
            echo -e "${GREEN}✓ FRED API Key configured${NC}"
        fi

        echo ""
        echo "Alpha Vantage API Key (free from https://www.alphavantage.co/support/#api-key)"
        read -p "Enter Alpha Vantage API Key (or press Enter to skip): " AV_KEY
        if [ ! -z "$AV_KEY" ]; then
            sed -i.bak "s/ALPHA_VANTAGE_KEY=\"\"/ALPHA_VANTAGE_KEY=\"$AV_KEY\"/" .env
            echo -e "${GREEN}✓ Alpha Vantage API Key configured${NC}"
        fi

        # Remove backup file
        rm -f .env.bak
    fi
else
    echo -e "${YELLOW}⚠ .env file already exists, skipping${NC}"
fi

echo ""
echo -e "${BLUE}[8/8] Creating helper scripts...${NC}"

# Create start script
cat > start_agent.sh << 'EOF'
#!/bin/bash
# Start Gold Analysis Agent

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Activate virtual environment if exists
if [ -d venv ]; then
    source venv/bin/activate
fi

echo "================================================"
echo "  Gold Analysis Agent - Starting"
echo "================================================"
echo ""
echo "System Prompt: config/agent_system_prompt.md"
echo "Skills: $(ls -1 skills/ | wc -l) registered"
echo "Sub-agents: $(ls -1 subagents/ | wc -l) custom"
echo ""
echo "To use the agent, load the system prompt in Claude Code:"
echo '  "请扮演黄金市场分析Agent，系统提示词在 config/agent_system_prompt.md"'
echo ""
echo "Quick test command:"
echo '  "今天金价多少？"'
echo ""
echo "Press Ctrl+C to exit"
echo ""

# Keep script running
tail -f /dev/null
EOF

chmod +x start_agent.sh

# Create test script
cat > test_setup.sh << 'EOF'
#!/bin/bash
# Test Gold Analysis Agent Setup

echo "Testing setup..."
echo ""

# Test 1: Check directories
echo "[Test 1] Checking directories..."
DIRS=("config" "skills" "subagents" "data" "output")
for dir in "${DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo "✓ $dir"
    else
        echo "✗ $dir (missing)"
    fi
done
echo ""

# Test 2: Check config files
echo "[Test 2] Checking configuration files..."
if [ -f "config/agent_system_prompt.md" ]; then
    echo "✓ Main agent config"
else
    echo "✗ Main agent config (missing)"
fi

SKILL_COUNT=$(ls -1 skills/*.md 2>/dev/null | wc -l)
echo "✓ Skills: $SKILL_COUNT/3 found"

if [ -f "subagents/financial_intelligence.md" ]; then
    echo "✓ Custom sub-agent config"
else
    echo "✗ Custom sub-agent config (missing)"
fi
echo ""

# Test 3: Check Python environment
echo "[Test 3] Checking Python environment..."
if command -v python3 &> /dev/null; then
    echo "✓ Python 3: $(python3 --version)"
else
    echo "✗ Python 3 not found"
fi

# Test Python packages
PACKAGES=("pandas" "numpy" "yfinance" "requests")
for pkg in "${PACKAGES[@]}"; do
    if python3 -c "import $pkg" 2>/dev/null; then
        echo "✓ $pkg installed"
    else
        echo "✗ $pkg not installed"
    fi
done
echo ""

# Test 4: Check environment variables
echo "[Test 4] Checking environment variables..."
if [ -f ".env" ]; then
    echo "✓ .env file exists"
    if grep -q "FRED_API_KEY=\"\"" .env; then
        echo "⚠ FRED_API_KEY not configured (optional)"
    else
        echo "✓ FRED_API_KEY configured"
    fi
else
    echo "✗ .env file missing"
fi
echo ""

echo "Setup test complete!"
EOF

chmod +x test_setup.sh

# Create cleanup script
cat > cleanup.sh << 'EOF'
#!/bin/bash
# Cleanup Gold Analysis Agent data

echo "Gold Analysis Agent - Cleanup Utility"
echo ""

read -p "Clear cache? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf data/cache/*
    echo "✓ Cache cleared"
fi

read -p "Archive old reports? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    mkdir -p output/archive
    mv output/*.html output/archive/ 2>/dev/null
    mv output/*.pdf output/archive/ 2>/dev/null
    echo "✓ Reports archived"
fi

read -p "Clear logs? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf logs/*.log
    echo "✓ Logs cleared"
fi

echo ""
echo "Cleanup complete!"
EOF

chmod +x cleanup.sh

echo -e "${GREEN}✓ Helper scripts created${NC}"

echo ""
echo "================================================"
echo -e "${GREEN}  Setup Complete! 🎉${NC}"
echo "================================================"
echo ""
echo "📁 Project structure:"
echo "   ├── config/          - Agent configuration"
echo "   ├── skills/          - Skill definitions"
echo "   ├── subagents/       - Sub-agent configs"
echo "   ├── data/            - Data storage"
echo "   ├── output/          - Generated reports"
echo "   └── logs/            - System logs"
echo ""
echo "🔧 Helper scripts:"
echo "   ./start_agent.sh     - Start the agent"
echo "   ./test_setup.sh      - Test configuration"
echo "   ./cleanup.sh         - Clean cache and logs"
echo ""
echo "📚 Next steps:"
echo "   1. Run ./test_setup.sh to verify installation"
echo "   2. Start Claude Code CLI"
echo "   3. Load the system prompt:"
echo "      \"请扮演黄金市场分析Agent，系统提示词在 config/agent_system_prompt.md\""
echo "   4. Try a quick test:"
echo "      \"今天金价多少？\""
echo ""
echo "📖 Documentation:"
echo "   - USAGE_GUIDE.md       - Complete usage guide"
echo "   - QUICK_REFERENCE.md   - Quick reference card"
echo "   - ARCHITECTURE_OVERVIEW.md - System architecture"
echo ""

# Run test automatically
echo "Running setup test..."
echo ""
./test_setup.sh

echo ""
echo -e "${GREEN}Setup wizard finished successfully!${NC}"
echo ""
