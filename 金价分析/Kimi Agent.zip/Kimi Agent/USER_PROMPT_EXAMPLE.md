# 黄金市场分析任务 - User Prompt 示例

## 🎯 完整任务指令

```
请分析2025年1月至2026年1月期间的黄金市场走势，并生成完整的HTML分析报告。

## 任务要求

### 1. 数据收集（必须使用真实数据）

**第一步：立即获取当前金价**
```bash
python3 scripts/fetch_real_gold_data.py
```
这会返回当前实时金价作为基准点。

**第二步：获取历史数据（仅使用公开数据，无需API Key）**

**策略1 - 公开Web数据（优先）：**

使用 WebSearch + WebFetch 组合获取数据：

```bash
# 1. 搜索权威金融网站的历史数据
WebSearch("gold price historical data 2025 2026 Kitco")
WebSearch("LBMA gold price fixing 2025 2026")
WebSearch("gold price chart January 2025 to January 2026")
WebSearch("World Gold Council gold price data 2025")

# 2. 抓取以下公开网站的数据
WebFetch("https://www.kitco.com/charts/historicalgold.html")
WebFetch("https://www.gold.org/goldhub/data/gold-prices")
WebFetch("https://www.lbma.org.uk/prices-and-data/precious-metal-prices")
WebFetch("https://goldprice.org/gold-price-history.html")
WebFetch("https://www.investing.com/commodities/gold-historical-data")
```

**策略2 - 免费API（无需密钥）：**
- ✅ Coinbase API: `https://api.coinbase.com/v2/prices/XAU-USD/spot` （当前价格）
- ✅ Yahoo Finance 数据（通过Web抓取）: GC=F (黄金期货)
- ✅ CoinGecko API: 黄金代币化资产参考数据

**策略3 - 新闻和报告搜索：**
- 搜索 "gold price January 29 2026 crash" 获取当天新闻
- 搜索 World Gold Council 季度报告
- 搜索各大投行的黄金市场研究报告（公开部分）
- 搜索美联储、IMF 的公开数据发布

**必须获取的数据清单（全部使用公开数据）**：
1. ✅ 2025年1月-2026年1月的黄金价格（通过Kitco/GoldPrice.org/Investing.com）
2. ✅ 2026年1月29日当天的价格波动数据（通过新闻搜索和公开金融网站）
3. ✅ 美联储2025-2026年利率决议（通过WebSearch搜索新闻和美联储官网）
4. ✅ 主要央行黄金储备数据（通过搜索IMF/World Gold Council公开报告）
5. ✅ 美元指数DXY走势（通过Investing.com或Yahoo Finance网页数据）
6. ✅ 通胀数据CPI（通过搜索美国劳工统计局BLS官网公开数据）
7. ✅ 黄金ETF持仓（通过WebSearch搜索GLD/IAU的公开持仓报告）
8. ✅ 重大地缘政治事件（通过WebSearch搜索2025-2026年国际新闻）

**数据获取策略**：
- ✅ 优先使用 WebSearch + WebFetch 获取权威金融网站的公开数据
- ✅ 对于无法获取的精确数据，使用新闻报道中的数据点
- ✅ 如果找不到详细日数据，使用周数据或月数据
- ✅ 明确标注每个数据的来源和获取时间
- ✅ 对于缺失的数据，明确说明"数据不可得"，绝对不要虚构任何数据

### 2. 分析内容

#### 过去一年黄金持续上涨的原因分析：
- 宏观经济因素（通胀、利率政策、美元走势）
- 央行购金潮的影响（搜索各国央行购金新闻）
- 地缘政治风险（中东局势、俄乌冲突延续、中美关系等）
- 投资需求变化（ETF流入/流出数据）
- 供需基本面分析（矿产供应、需求变化）

#### 2026年1月29日黄金大跌分析：
- 跌幅具体数据（开盘价、最低价、收盘价、跌幅百分比）
- 触发因素识别（搜索1月29日发布的经济数据、政策新闻）
- 成交量分析（如果有数据）
- 市场情绪变化
- 与其他资产类别的联动关系

#### 技术分析（使用真实价格数据计算）：
- 价格趋势分析（识别支撑位、阻力位）
- 技术指标计算：
  - RSI (相对强弱指数)
  - MACD (移动平均收敛散度)
  - 布林带 (Bollinger Bands)
  - 移动平均线 (MA50, MA200)
- 图表形态识别
- 关键价格水平

#### 未来一年预测（2026年2月-2027年1月）：
- 基于基本面的情景分析：
  - 基准情景（最可能）
  - 乐观情景（牛市）
  - 悲观情景（熊市）
- 关键影响因素前瞻
- 价格目标区间预测（给出合理的范围）
- 风险因素识别
- 投资建议

### 3. 设计与输出要求

#### 🎨 设计要求（重要！）

**使用 shadcn/ui 组件风格**：
- 参考 https://ui.shadcn.com/ 的设计系统
- 采用现代、简洁、专业的UI设计
- 使用卡片式布局 (Card components)
- 柔和阴影和边框效果
- 响应式设计

**配色方案**（shadcn/ui 深色主题）：
```css
/* 主色调 - shadcn zinc 深色主题 */
--primary: #FAFAFA;          /* 主要强调色 Zinc 50 */
--primary-foreground: #18181B; /* 主色前景 */

/* 背景色 - 深色主题 */
--background: #09090B;       /* 最深背景 Zinc 950 */
--foreground: #FAFAFA;       /* 前景文字 Zinc 50 */

--card: #18181B;             /* 卡片背景 Zinc 900 */
--card-foreground: #FAFAFA;  /* 卡片文字 */

--popover: #18181B;          /* 弹出层背景 */
--popover-foreground: #FAFAFA;

/* 文字层级 */
--muted: #27272A;            /* 静音背景 Zinc 800 */
--muted-foreground: #A1A1AA; /* 静音文字 Zinc 400 */

--accent: #27272A;           /* 强调背景 Zinc 800 */
--accent-foreground: #FAFAFA;

/* 边框 */
--border: #27272A;           /* 边框颜色 Zinc 800 */
--input: #27272A;            /* 输入框边框 */
--ring: #D4D4D8;             /* 焦点环 Zinc 300 */

/* 数据可视化专用颜色 */
--chart-green: #10B981;      /* 上涨 Emerald 500 */
--chart-red: #EF4444;        /* 下跌 Red 500 */
--chart-blue: #3B82F6;       /* 蓝色 Blue 500 */
--chart-cyan: #06B6D4;       /* 青色 Cyan 500 */
--chart-purple: #8B5CF6;     /* 紫色 Violet 500 */
--chart-orange: #F97316;     /* 橙色 Orange 500 */
--chart-yellow: #EAB308;     /* 黄色 Yellow 500 */

/* 语义化颜色 */
--destructive: #EF4444;      /* 危险 Red 500 */
--destructive-foreground: #FAFAFA;

--success: #10B981;          /* 成功 Emerald 500 */
--warning: #F97316;          /* 警告 Orange 500 */
--info: #3B82F6;             /* 信息 Blue 500 */

/* 渐变色（用于图表和装饰） */
--gradient-1: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%); /* 蓝紫 */
--gradient-2: linear-gradient(135deg, #10B981 0%, #059669 100%); /* 绿色 */
--gradient-3: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); /* 红色 */
--gradient-4: linear-gradient(135deg, #06B6D4 0%, #0891B2 100%); /* 青色 */
```

**Typography（shadcn/ui 字体系统）**：
```css
/* 使用 shadcn 推荐的字体栈 */
font-family: 'Geist', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;

/* 中文优化 */
font-family: 'Geist', 'Inter', 'PingFang SC', 'Noto Sans SC', 'Microsoft YaHei', sans-serif;

/* 字体大小 (Tailwind scale) */
--font-size-xs: 0.75rem;    /* 12px */
--font-size-sm: 0.875rem;   /* 14px */
--font-size-base: 1rem;     /* 16px */
--font-size-lg: 1.125rem;   /* 18px */
--font-size-xl: 1.25rem;    /* 20px */
--font-size-2xl: 1.5rem;    /* 24px */
--font-size-3xl: 1.875rem;  /* 30px */
--font-size-4xl: 2.25rem;   /* 36px */
```

**布局组件要求（shadcn/ui 风格）**：
1. **Hero Section**：
   - 大标题使用 font-size-4xl，font-weight-bold
   - 关键指标卡片使用 shadcn Card 组件样式
   - 简洁的边框和阴影，不使用渐变背景
   - 微妙的悬停效果

2. **Stats Cards**：
   - 使用 shadcn Card 组件风格
   - 圆角：rounded-lg (0.5rem)
   - 边框：1px solid var(--border)
   - 阴影：shadow-sm
   - Hover 效果：轻微上移 + shadow-md
   - 显示变化趋势（使用绿色/红色文字和箭头）

3. **Chart Section**：
   - 使用 Chart.js 配置为深色主题
   - 图表配色使用 chart-* 变量
   - 背景透明或使用 var(--card)
   - 网格线颜色：rgba(255,255,255,0.1)
   - Tooltip 背景：var(--popover)

4. **Timeline Component**：
   - 垂直时间线，左侧圆点标记
   - 连接线：1px solid var(--border)
   - 事件卡片使用 Card 样式
   - 不同类型事件用不同的圆点颜色标记

5. **Data Tables**：
   - 表头：font-weight-medium, color: var(--muted-foreground)
   - 表格行：border-bottom: 1px solid var(--border)
   - Hover：background: var(--muted)
   - 斑马纹可选（不强制）
   - 响应式：移动端横向滚动

6. **Prediction Cards**：
   - 三个场景并排（Grid 或 Flex 布局）
   - 使用 Card 组件
   - 顶部彩色条标识（绿色/灰色/红色）
   - 价格目标使用大号文字突出显示
   - 概率使用 Badge 组件展示

#### 报告结构：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>黄金市场深度分析报告 2025-2026</title>

    <!-- 字体 -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <!-- 自定义样式 -->
    <style>
        /* 使用 shadcn/ui 配色方案 */
        :root {
            --background: #09090B;
            --foreground: #FAFAFA;
            --card: #18181B;
            --card-foreground: #FAFAFA;
            --border: #27272A;
            --muted: #27272A;
            --muted-foreground: #A1A1AA;
            --chart-green: #10B981;
            --chart-red: #EF4444;
            --chart-blue: #3B82F6;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: var(--background);
            color: var(--foreground);
            line-height: 1.6;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }

        /* shadcn/ui 风格的简洁设计 */
    </style>
</head>
<body>
    <!-- 1. Hero Section -->
    <header class="hero">
        <h1>黄金市场深度分析报告</h1>
        <p class="subtitle">2025年1月 - 2026年1月</p>
        <div class="key-metrics">
            <div class="metric-card">
                <span class="label">当前金价</span>
                <span class="value">$5,296.83</span>
                <span class="change negative">-2.3%</span>
            </div>
            <!-- 更多关键指标 -->
        </div>
    </header>

    <!-- 2. 执行摘要 -->
    <section class="executive-summary">
        <div class="container">
            <h2>执行摘要</h2>
            <div class="key-findings">
                <!-- 3-5个要点 -->
            </div>
        </div>
    </section>

    <!-- 3. 市场回顾 -->
    <section class="market-review">
        <h2>市场回顾</h2>
        <div class="chart-container">
            <canvas id="priceChart"></canvas>
        </div>
        <div class="timeline">
            <!-- 关键事件时间线 -->
        </div>
    </section>

    <!-- 4. 1月29日大跌分析 -->
    <section class="crash-analysis">
        <h2>2026年1月29日暴跌深度分析</h2>
        <!-- 详细分析内容 -->
    </section>

    <!-- 5. 驱动因素分析 -->
    <section class="drivers-analysis">
        <h2>黄金上涨驱动因素分析</h2>
        <div class="drivers-grid">
            <!-- 4个主要驱动因素卡片 -->
        </div>
    </section>

    <!-- 6. 技术分析 -->
    <section class="technical-analysis">
        <h2>技术分析</h2>
        <div class="indicators">
            <!-- RSI, MACD 图表 -->
        </div>
    </section>

    <!-- 7. 未来展望 -->
    <section class="outlook">
        <h2>未来一年展望与预测</h2>
        <div class="scenarios">
            <!-- 三种情景卡片 -->
        </div>
    </section>

    <!-- 8. 投资建议 -->
    <section class="recommendations">
        <h2>投资建议</h2>
        <!-- 建议列表 -->
    </section>

    <!-- 9. 数据来源与免责声明 -->
    <footer>
        <div class="data-sources">
            <h3>数据来源</h3>
            <!-- 列出所有数据源和获取时间 -->
        </div>
        <div class="disclaimer">
            <h3>免责声明</h3>
            <p>本报告仅供参考，不构成投资建议...</p>
        </div>
    </footer>

    <script>
        // Chart.js 配置和数据
        // 使用真实数据生成图表
    </script>
</body>
</html>
```

#### 技术实现要求：

**CSS 特效（shadcn/ui 风格）**：
```css
/* 平滑过渡 */
transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);

/* 卡片样式 */
.card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 0.5rem;
    padding: 1.5rem;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
}

/* Hover 效果（微妙） */
.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    border-color: var(--ring);
}

/* 按钮样式 */
.button {
    background: var(--primary);
    color: var(--primary-foreground);
    border-radius: 0.375rem;
    padding: 0.5rem 1rem;
    font-weight: 500;
    transition: opacity 0.2s;
}

.button:hover {
    opacity: 0.9;
}

/* Badge 样式 */
.badge {
    display: inline-flex;
    align-items: center;
    border-radius: 9999px;
    padding: 0.125rem 0.625rem;
    font-size: 0.75rem;
    font-weight: 600;
    background: var(--accent);
    color: var(--accent-foreground);
}

/* 不使用强烈的渐变或发光效果 */
/* 保持简洁专业的视觉风格 */
```

**JavaScript 交互**：
- 图表交互（缩放、悬停显示数据点）
- 滚动动画（元素进入视口时淡入）
- 数据切换（不同时间范围）
- 打印功能（优化打印样式）

### 4. 数据真实性要求（严格执行）

**执行流程**：

```
1️⃣ 运行 Python 脚本获取当前金价
   ↓
2️⃣ 使用 WebSearch 搜索历史数据
   搜索词：
   - "gold price 2025 historical data"
   - "LBMA gold price 2025"
   - "Kitco gold chart 2025-2026"
   ↓
3️⃣ 使用 WebSearch 搜索新闻和宏观数据
   搜索词：
   - "gold crash January 29 2026"
   - "federal reserve interest rate 2025"
   - "central bank gold reserves 2025"
   ↓
4️⃣ 使用 WebFetch 抓取公开金融网站数据
   目标网站：
   - https://www.kitco.com/charts/historicalgold.html
   - https://www.gold.org/goldhub/data
   - https://www.investing.com/commodities/gold-historical-data
   ↓
5️⃣ 整合所有数据，标注来源和获取时间
   ↓
6️⃣ 使用真实数据计算技术指标（RSI、MACD、MA）
   ↓
7️⃣ 生成 HTML 报告（shadcn/ui 风格）
```

**验证清单**：
- [ ] 每个价格数据点都有来源标注
- [ ] 新闻事件都有日期和可验证来源
- [ ] 图表数据与文本描述一致
- [ ] 没有虚构的数据或事件
- [ ] 预测明确标注为"预测"而非事实
- [ ] 所有外部链接都可访问

### 5. 工作流程（详细步骤）

**步骤 1：数据获取（使用公开数据源）**
```bash
# 1.1 获取当前金价
python3 scripts/fetch_real_gold_data.py

# 1.2 使用 WebSearch 搜索历史数据
WebSearch("gold price historical data 2025 2026 Kitco")
WebSearch("LBMA gold price fixing 2025 2026 monthly data")
WebSearch("gold price chart January 2025 to January 2026")

# 1.3 使用 WebFetch 抓取公开金融网站数据
WebFetch("https://www.kitco.com/charts/historicalgold.html")
WebFetch("https://www.gold.org/goldhub/data/gold-prices")
WebFetch("https://goldprice.org/gold-price-history.html")
WebFetch("https://www.investing.com/commodities/gold-historical-data")
```

**步骤 2：新闻搜索（公开新闻源）**
```bash
# 搜索2026年1月29日黄金暴跌相关新闻
WebSearch("gold price crash January 29 2026")
WebSearch("gold market January 29 2026 news reasons")
WebSearch("why did gold drop January 29 2026")

# 搜索2025年央行购金数据
WebSearch("central bank gold purchases 2025 World Gold Council")
WebSearch("IMF gold reserves 2025 data")
WebSearch("China India central bank gold buying 2025")
```

**步骤 3：宏观经济数据搜索**
```bash
# 搜索宏观数据（全部通过公开网站）
WebSearch("US inflation rate 2025 CPI data BLS")
WebSearch("Federal Reserve interest rate decisions 2025 2026")
WebSearch("US dollar index DXY 2025-2026 chart")
WebSearch("gold ETF holdings GLD IAU 2025 2026")
```

**步骤 4：技术分析（使用获取的真实数据计算）**
```bash
# 使用获取到的历史价格数据，手动计算技术指标：
# - RSI (相对强弱指数)
# - MACD (移动平均收敛散度)
# - Bollinger Bands (布林带)
# - MA50, MA200 (移动平均线)

# 可以使用 Python pandas/numpy 进行计算，或使用在线图表工具的数据
```

**步骤 5：地缘政治分析**
```bash
# 搜索2025-2026年重大国际事件
WebSearch("major geopolitical events 2025 2026 Middle East")
WebSearch("US China relations 2025 2026 trade")
WebSearch("Russia Ukraine 2025 2026 developments")
WebSearch("Israel Palestine conflict 2025 2026")
```

**步骤 6：生成报告**
```bash
# 整合所有收集的数据
# 使用 Write 工具生成 HTML 文件
Write("gold_market_analysis_2026.html", <complete_html_content>)

# 生成配套的数据文件
Write("data/gold_prices_2025_2026.json", <price_data>)
Write("data/analysis_results.json", <analysis_data>)
```

**步骤 7：验证与优化**
- ✅ 检查所有数据来源标注
- ✅ 确认所有数据都来自公开可验证的源
- ✅ 测试图表交互功能
- ✅ 验证响应式设计
- ✅ 检查拼写和格式

## 预期输出文件

1. **主报告**：`gold_market_analysis_2026.html`
   - 完整的分析报告
   - 包含所有图表和数据
   - 美观的现代设计
   - 完全自包含（所有资源内联）

2. **数据文件**：
   - `data/gold_prices_2025_2026.json` - 原始价格数据
   - `data/technical_indicators.json` - 技术指标计算结果
   - `data/news_events.json` - 新闻事件列表
   - `data/macro_data.json` - 宏观经济数据

3. **日志文件**：
   - `logs/data_sources.txt` - 所有数据来源记录
   - `logs/api_calls.txt` - API调用日志

## 数据来源参考

**公开数据源（全部无需API Key）**：
- ✅ Coinbase API (无需Key): https://api.coinbase.com/v2/prices/XAU-USD/spot
- ✅ Kitco: https://www.kitco.com/charts/ (提供历史图表和数据)
- ✅ GoldPrice.org: https://goldprice.org/gold-price-history.html
- ✅ Investing.com: https://www.investing.com/commodities/gold-historical-data
- ✅ World Gold Council: https://www.gold.org/goldhub/data (官方报告和数据)
- ✅ LBMA: https://www.lbma.org.uk/prices-and-data (伦敦金银市场协会价格)
- ✅ Yahoo Finance: GC=F (黄金期货) - 通过网页抓取
- ✅ TradingView: 提供公开的图表和历史数据

**宏观经济数据（公开网站）**：
- ✅ 美国劳工统计局 BLS: https://www.bls.gov/ (CPI通胀数据)
- ✅ 美联储官网: https://www.federalreserve.gov/ (利率决议)
- ✅ IMF数据: 各国央行黄金储备（通过WebSearch搜索报告）
- ✅ Federal Reserve Economic Data (FRED): 部分数据可通过网页访问

**新闻来源**：
- Bloomberg, Reuters, Financial Times (通过WebSearch搜索)
- CNBC, MarketWatch, Seeking Alpha
- 各国央行官方网站新闻发布
- World Gold Council 官方报告

**数据获取策略**：
- ✅ 优先使用 WebSearch + WebFetch 组合获取公开网站数据
- ✅ 对于历史数据，从Kitco/Investing.com/GoldPrice.org 的HTML表格中提取
- ✅ 优先使用官方来源（央行、监管机构、交易所）
- ✅ 对于无法获取的数据，明确说明"数据不可得"而不是虚构
- ✅ 所有数据必须标注来源和获取时间

## 成功标准

✅ 报告包含真实的价格数据（至少月度数据）
✅ 所有数据都有明确的来源标注
✅ 设计美观专业，使用指定的配色方案
✅ 图表清晰可读，支持交互
✅ 分析逻辑清晰，结论有数据支撑
✅ HTML文件可以独立运行，无需额外依赖
✅ 响应式设计，支持各种屏幕尺寸
✅ 没有虚构的数据或事件

请开始执行任务，实时报告每个步骤的进度和结果！
```

---

## 🚀 快速启动命令

### 方式1：使用启动脚本（推荐）
```bash
./start-gold-agent.sh
# 启动后，复制粘贴上面用三个反引号包裹的完整任务指令
```

### 方式2：简化版启动
```bash
./start-gold-agent.sh
# 然后输入简化版命令（见下方）
```

---

## 📋 简化版 Prompt（快速版本）

```
任务：生成专业的黄金市场分析HTML报告（2025-2026）

数据获取步骤（全部使用公开数据，无需API Key）：
1. 运行：python3 scripts/fetch_real_gold_data.py（获取当前金价）
2. WebSearch搜索："gold price historical data 2025 2026 Kitco"
3. WebSearch搜索："gold crash January 29 2026 news reasons"
4. WebSearch搜索："Federal Reserve interest rate decisions 2025 2026"
5. WebSearch搜索："central bank gold purchases 2025 World Gold Council"
6. WebFetch抓取公开网站的历史数据：
   - https://www.kitco.com/charts/historicalgold.html
   - https://goldprice.org/gold-price-history.html
   - https://www.investing.com/commodities/gold-historical-data

分析要求：
1. 分析2025-2026年黄金上涨原因（央行购金、地缘政治、通胀）
2. 深度分析2026年1月29日的大跌（搜索真实新闻找原因）
3. 技术分析：计算RSI、MACD、MA（使用真实价格数据）
4. 预测未来一年：三种情景（乐观/基准/悲观）+ 价格目标区间

设计要求（重要！）：
- 参考 https://ui.shadcn.com/ 的设计系统
- 配色：shadcn/ui Zinc 深色主题（黑白灰配色）
  - 背景：#09090B（最深）, #18181B（卡片）, #27272A（边框）
  - 文字：#FAFAFA（主要）, #A1A1AA（次要）
  - 数据颜色：
    - 绿色（涨）：#10B981
    - 红色（跌）：#EF4444
    - 蓝色（信息）：#3B82F6
    - 青色：#06B6D4
    - 紫色：#8B5CF6
    - 橙色：#F97316
- 使用简洁的卡片式布局，微妙的阴影和边框
- 不使用强烈的渐变或发光效果
- Chart.js 图表（深色主题，多彩数据线）
- 现代字体：Inter 或 Geist
- 参考风格：shadcn/ui、Linear、GitHub 深色主题

输出：
- gold_market_analysis_2026.html（完整自包含）
- 所有数据标注来源和获取时间
- 响应式设计
- 明确标注所有数据来自公开可验证的源
- 无虚构数据

请按步骤执行，实时报告进度！
```

---

## 💡 使用提示

### Agent 执行流程：
1. **运行Python脚本** → 获取当前金价基准
2. **WebSearch** → 搜索历史数据和新闻
3. **WebFetch** → 抓取金融网站数据表格
4. **计算指标** → RSI、MACD等技术分析
5. **生成报告** → 使用指定设计风格的HTML

### 预计用时：
- 数据获取：10-15 分钟（多源搜索）
- 分析计算：10-15 分钟
- 报告生成：10-15 分钟
- **总计：30-45 分钟**

### 如何检查进度：
- Agent 会实时报告每个步骤
- 可以要求"先给我看看获取到的金价数据"
- 可以中途调整："多搜索一些央行购金的新闻"

### 设计预览：
报告会使用类似 React Bits 的现代风格：
- ✨ 深色主题 + 金色点缀
- 📊 漂亮的交互式图表
- 🎴 卡片式布局
- 🌊 平滑过渡动画
- 📱 完美的响应式设计
