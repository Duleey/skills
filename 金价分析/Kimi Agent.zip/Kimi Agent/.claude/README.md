# Claude Code 配置目录

这个目录包含所有 Claude Code Agent 的配置文件。

## 目录结构

```
.claude/
├── README.md                    # 本文件
├── settings.json                # Claude Code 设置
├── mcp.json                     # MCP 服务器配置
│
├── prompts/                     # 系统提示词
│   ├── system_prompt_cn.md     # 中文版系统提示词
│   └── system_prompt_en.md     # 英文版系统提示词
│
├── agents/                      # Sub-Agents 配置
│   ├── subagent_financial_intelligence.md
│   └── subagents_usage_strategy.md
│
└── skills/                      # 技能模块
    ├── README.md
    ├── skill_financial_data_fetcher.md
    ├── skill_geopolitical_analyst.md
    └── skill_financial_report_generator.md
```

## 配置文件说明

### settings.json
- 默认模型设置
- 系统提示词路径
- 允许的工具列表
- Agent 配置

### mcp.json
- MCP 服务器配置
- 文件系统访问权限

### prompts/
系统提示词文件，定义 Agent 的行为和能力：
- `system_prompt_cn.md` - 中文版（推荐用于中文分析）
- `system_prompt_en.md` - 英文版（English analysis）

### agents/
自定义 Sub-Agents 配置：
- `subagent_financial_intelligence.md` - 金融情报 Agent 定义
- `subagents_usage_strategy.md` - Sub-Agents 协作策略

### skills/
自定义技能命令，可通过 `/command` 或 `Skill()` 调用

## 使用方法

### 启动 Claude Code（中文版）
```bash
./start-gold-agent.sh
```

### 启动 Claude Code（英文版）
```bash
./start-gold-agent.sh --en
```

### 手动启动
```bash
claude --system-prompt .claude/prompts/system_prompt_cn.md \
       --mcp-config .claude/mcp.json \
       --model sonnet
```

## 更新配置

如果修改了配置文件，需要重启 Claude Code 使其生效。

## 备份

原始配置文件也保存在项目根目录：
- `/core_config/` - 系统提示词备份
- `/subagents/` - Sub-Agents 配置备份
- `/skills/` - Skills 定义备份
