# Gold Analysis Agent - Sub-Agents Usage Strategy

## 现有Sub-Agents使用方案

基于黄金市场分析的需求，推荐使用以下现有sub-agents：

### 1. **search-specialist** (搜索专家) - 核心必用
**使用场景**:
- 搜索实时和历史金价数据
- 查找央行政策声明和会议纪要
- 研究地缘政治事件和新闻
- 获取经济数据发布（CPI、PPI、就业数据）
- 寻找金融分析师报告和市场评论

**典型任务**:
```
任务1: "搜索2023-2024年LBMA黄金日收盘价数据"
任务2: "研究2024年1月29日黄金大跌的触发事件"
任务3: "查找美联储2023-2024年利率决议时间线"
任务4: "搜索World Gold Council关于央行购金的最新报告"
```

**为什么必需**:
- 专业搜索能力，能使用高级搜索技巧
- 多源验证和结果综合
- 信息质量过滤

---

### 2. **business-analyst** (商业分析师) - 核心必用
**使用场景**:
- 分析金价与经济指标的相关性
- 计算KPI（年化收益率、波动率、夏普比率）
- 分析ETF持仓变化趋势
- 评估央行购金对供需的影响
- 生成财务模型和预测

**典型任务**:
```
任务1: "分析黄金价格与美元指数(DXY)的负相关性，计算相关系数"
任务2: "评估2023年全球央行购金量对金价的影响"
任务3: "计算黄金相对于通胀调整后的实际回报率"
任务4: "分析SPDR Gold Trust持仓变化趋势"
```

**为什么必需**:
- 专业财务分析能力
- 数据驱动决策
- KPI和指标计算

---

## 🆕 建议创建的新Sub-Agent

### **financial-intelligence-agent** (金融情报代理)

#### 为什么需要新建

现有sub-agents存在以下缺口：
1. **search-specialist**: 擅长搜索，但不专精金融数据源和API
2. **business-analyst**: 擅长分析，但不熟悉金融数据获取流程
3. 缺少一个**专门懂金融数据架构**的agent，能够：
   - 直接调用金融API（Alpha Vantage、FRED API、Yahoo Finance API）
   - 理解金融数据格式（OHLCV、时间序列、经济指标）
   - 执行技术分析计算（移动平均、RSI、MACD）
   - 处理金融数据的特殊性（交易日历、时区、货币转换）

#### 能力定义

**专业领域**: 金融市场数据获取、技术分析、量化研究

**核心能力**:
1. **API集成**: 直接调用金融数据API
   - FRED (Federal Reserve Economic Data)
   - Alpha Vantage
   - Yahoo Finance
   - Quandl
   - World Gold Council API

2. **技术分析**: 计算技术指标
   - 移动平均线 (MA, EMA)
   - 相对强弱指数 (RSI)
   - 布林带 (Bollinger Bands)
   - MACD
   - 成交量分析

3. **数据处理**: 金融数据特化处理
   - 处理缺失交易日
   - 时区标准化
   - 货币换算
   - 数据对齐和重采样

4. **量化分析**: 统计和量化方法
   - 波动率计算 (historical, implied)
   - 相关性矩阵
   - 回归分析
   - 风险指标 (VaR, Sharpe Ratio)

**可用工具**:
- Bash: 执行API调用 (curl)、运行Python脚本
- Read/Write: 处理数据文件
- WebFetch: 获取金融网站数据
- WebSearch: 查找API文档和数据源

**工作流示例**:
```bash
# 1. 使用FRED API获取美元指数数据
curl "https://api.stlouisfed.org/fred/series/observations?series_id=DTWEXBGS&api_key=XXX&file_type=json" -o dxy_data.json

# 2. 使用Python计算技术指标
python3 << EOF
import pandas as pd
import json

# 读取金价数据
df = pd.read_csv('gold_prices.csv')
df['MA_50'] = df['Close'].rolling(window=50).mean()
df['MA_200'] = df['Close'].rolling(window=200).mean()

# 计算RSI
delta = df['Close'].diff()
gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
rs = gain / loss
df['RSI'] = 100 - (100 / (1 + rs))

df.to_csv('gold_technical_analysis.csv', index=False)
EOF

# 3. 计算相关性
python3 -c "
import pandas as pd
gold = pd.read_csv('gold_prices.csv', index_col='Date', parse_dates=True)
dxy = pd.read_json('dxy_data.json')
correlation = gold['Close'].corr(dxy['value'])
print(f'Gold-DXY Correlation: {correlation:.4f}')
"
```

**输出格式**:
```json
{
  "data_type": "technical_analysis",
  "asset": "Gold (XAU/USD)",
  "period": "2023-01-01 to 2024-01-30",
  "indicators": {
    "MA_50": 1985.42,
    "MA_200": 1942.18,
    "RSI_14": 62.35,
    "volatility_30d": 0.0124,
    "bollinger_upper": 2089.50,
    "bollinger_lower": 1881.34
  },
  "signals": {
    "trend": "bullish",
    "momentum": "neutral",
    "support_levels": [1920, 1880, 1850],
    "resistance_levels": [2050, 2080, 2150]
  },
  "api_sources": [
    "FRED: DXY data",
    "Yahoo Finance: Gold OHLCV",
    "Calculated: Technical indicators"
  ]
}
```

---

## Sub-Agents协作架构

```
┌─────────────────────────────────────────────┐
│     Gold Analysis Agent (Orchestrator)      │
│     - 任务分解和规划                         │
│     - 并行调度sub-agents                     │
│     - 结果整合和报告生成                     │
└─────────────────────────────────────────────┘
              ↓ ↓ ↓ ↓
    ┌─────────┴─┴─┴─┴─────────┐
    ↓         ↓   ↓           ↓
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ search-  │ │business- │ │financial-│ │general-  │
│specialist│ │analyst   │ │intel     │ │purpose   │
└──────────┘ └──────────┘ └──────────┘ └──────────┘
    ↓             ↓            ↓            ↓
【新闻事件】  【财务分析】 【技术分析】 【数据清洗】
【政策文件】  【相关性】   【API数据】   【格式转换】
【市场评论】  【KPI计算】  【量化指标】 【杂项任务】
```

---

## 典型工作流示例

### 场景: 分析黄金走势并预测

**Phase 1: 数据收集 (并行执行)**
```
Main Agent 启动:
├─ Task 1: search-specialist
│  └─ "搜索2023-2024黄金相关重大地缘政治事件"
│
├─ Task 2: financial-intelligence-agent
│  └─ "从FRED/Yahoo Finance获取金价、DXY、利率数据"
│
├─ Task 3: search-specialist
│  └─ "查找美联储、ECB、PBoC政策声明和购金报告"
│
└─ Task 4: business-analyst
   └─ "收集SPDR Gold Trust的ETF持仓历史数据"
```

**Phase 2: 技术分析 (串行执行)**
```
Main Agent → financial-intelligence-agent:
├─ "计算金价的50日/200日移动平均线"
├─ "计算RSI、MACD等技术指标"
├─ "识别支撑位和阻力位"
└─ "分析成交量和波动率变化"
```

**Phase 3: 相关性分析 (并行执行)**
```
Main Agent 启动:
├─ business-analyst: "金价 vs 美元指数相关性分析"
├─ business-analyst: "金价 vs 实际利率相关性分析"
└─ financial-intelligence-agent: "金价 vs 通胀预期回归分析"
```

**Phase 4: 事件影响评估**
```
Main Agent → search-specialist:
└─ "针对每个重大事件，搜索金价在事件前后的市场反应报道"

Main Agent → business-analyst:
└─ "量化评估每个事件对金价的影响幅度和持续时间"
```

**Phase 5: 预测建模**
```
Main Agent → financial-intelligence-agent:
└─ "基于历史数据和当前技术指标，生成未来12个月价格区间预测"

Main Agent → business-analyst:
└─ "构建牛市/基准/熊市三种情景的财务模型"
```

**Phase 6: 报告生成**
```
Main Agent 调用 Skills:
└─ financial-report-generator skill
   └─ 整合所有数据生成HTML报告
```

---

## Sub-Agents选择决策树

```
任务类型                              推荐Sub-Agent
├─ 需要搜索新闻/事件/政策?          → search-specialist
├─ 需要财务KPI/相关性分析?          → business-analyst
└─ 需要调用金融API/技术指标?        → financial-intelligence-agent
```

---

## 性能优化建议

### 1. 并行执行
尽可能并行启动独立的sub-agents：
```python
# ✅ 好的做法
Main Agent 同时发起:
- search-specialist (新闻搜索)
- financial-intelligence-agent (API数据获取)
- business-analyst (ETF数据收集)

# ❌ 不好的做法
Main Agent 串行执行每个任务
```

### 2. 任务粒度
- 每个sub-agent任务应该足够聚焦和具体
- 避免给sub-agent过于宽泛的任务
- 大任务应由Main Agent拆解后分配

### 3. 数据传递
- Sub-agents输出结构化数据（JSON/CSV）
- Main Agent负责数据整合和清洗
- 避免sub-agents之间直接依赖

---

## 总结

### 必用Sub-Agents (3个)
1. **search-specialist** - 信息搜索和研究
2. **business-analyst** - 财务分析和KPI
3. **financial-intelligence-agent** (自定义) - 金融数据和技术分析

### 协作原则
- Main Agent = 指挥官（任务规划、调度、整合）
- Sub-Agents = 专家团队（各司其职、并行工作）
- Skills = 工具库（数据获取、地缘分析、报告生成）

这样的架构确保了：
✅ 专业化分工
✅ 并行执行效率
✅ 结果质量和可信度
✅ 完整的端到端流程覆盖
