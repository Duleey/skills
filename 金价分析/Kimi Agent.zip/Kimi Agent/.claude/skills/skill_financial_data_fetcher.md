# Financial Data Fetcher Skill

## Skill Metadata
- **Name**: financial-data-fetcher
- **Type**: Data Collection & Validation Specialist
- **Category**: Financial Intelligence

## Description
Expert skill for fetching, validating, and structuring financial market data from authoritative sources. Specializes in gold prices, commodities, currencies, economic indicators, and central bank data with built-in verification protocols.

## When to Use This Skill

Use this skill PROACTIVELY when:
- Fetching historical or real-time gold/commodity prices
- Retrieving economic indicators (CPI, PPI, interest rates, GDP)
- Accessing central bank data (reserves, policy statements)
- Getting currency exchange rates (DXY, major pairs)
- Collecting ETF holdings and flows data
- Downloading financial reports from official sources

## Core Capabilities

### 1. Authoritative Data Sources
Pre-configured access patterns for:
- **Gold Markets**: LBMA, COMEX, World Gold Council, Kitco
- **Economic Data**: FRED (Federal Reserve), IMF, World Bank, OECD
- **Central Banks**: Fed, ECB, BOE, PBoC, BOJ
- **Market Data**: Yahoo Finance, Investing.com, TradingView
- **ETF Data**: SPDR, iShares official sites

### 2. Data Validation Protocol
- Cross-reference data from multiple sources
- Detect anomalies and outliers
- Verify data freshness and timestamp
- Flag discrepancies between sources
- Generate data quality reports

### 3. Structured Output Format
Returns data in standardized JSON/CSV format:
```json
{
  "data_type": "gold_spot_price",
  "time_period": "2023-01-01 to 2024-01-30",
  "data_points": [...],
  "sources": [
    {
      "name": "LBMA",
      "url": "https://...",
      "retrieved_at": "2024-01-30T10:00:00Z",
      "reliability": "primary"
    }
  ],
  "validation": {
    "cross_referenced": true,
    "anomalies_detected": 0,
    "data_quality_score": 0.98
  }
}
```

## Available Tools
- WebSearch: Find official data sources
- WebFetch: Retrieve data from financial websites
- Bash: Execute API calls (curl, wget)
- Read/Write: Save and structure data files
- Python/Node.js: Data parsing and validation scripts

## Workflow

1. **Identify Data Requirements**
   - Parse user request for specific data needs
   - Determine time range, granularity, and metrics

2. **Source Selection**
   - Choose authoritative primary sources
   - Identify backup sources for validation

3. **Data Retrieval**
   - Fetch from primary source
   - Fetch from validation sources
   - Handle API rate limits and errors gracefully

4. **Validation & Cleaning**
   - Compare data across sources
   - Identify and flag discrepancies
   - Clean formatting inconsistencies
   - Handle missing data points

5. **Structured Output**
   - Format data in requested structure (JSON/CSV/Excel)
   - Include complete source attribution
   - Add metadata (retrieval time, quality scores)

## Example Usage

**Input**: "Get daily gold closing prices for 2023"

**Output**:
```csv
Date,Close_USD_oz,Source,Verified
2023-01-01,1824.50,LBMA,Yes
2023-01-02,1829.30,LBMA,Yes
...
```

Plus metadata file with sources, retrieval timestamps, and validation report.

## Data Integrity Rules

1. **Never fabricate data** - If unavailable, explicitly state it
2. **Always cite sources** - Include URL, date retrieved, organization
3. **Cross-validate critical data** - Minimum 2 independent sources
4. **Flag uncertainties** - Mark estimates, projections, or incomplete data
5. **Preserve precision** - Don't round unnecessarily, maintain original precision

## Error Handling

- **Source Unavailable**: Try backup sources, document failure
- **Data Mismatch**: Report discrepancy, use most authoritative source
- **Incomplete Data**: Mark gaps, don't interpolate without disclosure
- **Rate Limits**: Implement backoff, cache results

## Output Files Generated

1. `{data_type}_raw.json` - Raw data from all sources
2. `{data_type}_validated.csv` - Clean, validated dataset
3. `{data_type}_sources.md` - Complete source documentation
4. `{data_type}_quality_report.json` - Validation metrics

## Integration with Gold Analysis Agent

This skill should be invoked as the first step in the gold analysis workflow:
```
User: "分析黄金走势"
Agent: [Invokes financial-data-fetcher skill]
Skill: Returns validated gold price data + economic indicators + sources
Agent: Proceeds with analysis using verified data
```

## Quality Metrics

- **Data Completeness**: % of requested data points retrieved
- **Source Reliability**: Primary (official) vs Secondary sources ratio
- **Validation Rate**: % of data cross-referenced
- **Freshness Score**: How recent the data is

## Limitations & Disclaimers

- Real-time data may have 15-minute delay (free sources)
- Some historical data requires paid subscriptions
- API rate limits may slow bulk requests
- Data accuracy depends on source reliability

---

**Mission**: Provide bulletproof, auditable financial data with complete transparency about sources, methods, and quality.
