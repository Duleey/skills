# Claude Code Skills

这个目录包含自定义 Claude Code Skills（技能命令）。

## 可用的 Skills

### 1. skill_financial_data_fetcher
**命令**: `/fetch-gold-data` (可配置)
**功能**: 从多个权威数据源获取实时黄金价格数据

### 2. skill_geopolitical_analyst
**命令**: `/analyze-geopolitics` (可配置)
**功能**: 分析地缘政治事件对黄金市场的影响

### 3. skill_financial_report_generator
**命令**: `/generate-report` (可配置)
**功能**: 生成 HTML 格式的黄金市场分析报告

## 使用方法

在 Claude Code 对话中直接调用：
\`\`\`
/fetch-gold-data
/analyze-geopolitics "美联储加息决议"
/generate-report
\`\`\`

或者通过 Skill() 函数调用：
\`\`\`
Skill("financial-data-fetcher")
\`\`\`

## 目录结构

\`\`\`
.claude/skills/
├── README.md (本文件)
├── skill_financial_data_fetcher.md
├── skill_geopolitical_analyst.md
└── skill_financial_report_generator.md
\`\`\`

## 注意事项

- Skills 必须放在 `.claude/skills/` 目录下才能被 Claude Code 识别
- 原始 skills 定义也保存在项目根目录的 `/skills/` 文件夹中作为备份
