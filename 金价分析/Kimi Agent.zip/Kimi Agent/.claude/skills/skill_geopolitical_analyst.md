# Geopolitical Analyst Skill

## Skill Metadata
- **Name**: geopolitical-analyst
- **Type**: Geopolitical Intelligence & Market Impact Specialist
- **Category**: Strategic Analysis

## Description
Expert skill for researching geopolitical events, analyzing their market impacts, and establishing causal relationships with commodity prices (especially gold). Specializes in conflict zones, central bank policies, trade tensions, and systemic financial risks.

## When to Use This Skill

Use this skill PROACTIVELY when:
- Analyzing causes of major price movements in gold/commodities
- Researching historical geopolitical events and market reactions
- Assessing current geopolitical risks affecting markets
- Building event timelines correlated with price data
- Forecasting future scenarios based on geopolitical trends
- Evaluating safe-haven demand drivers

## Core Capabilities

### 1. Event Research & Documentation
- Track conflicts, wars, and military tensions
- Monitor central bank policy changes and statements
- Identify banking crises and financial system stress
- Document trade disputes and sanctions
- Analyze political instability and regime changes
- Follow currency crises and sovereign debt issues

### 2. Market Impact Analysis
Establish correlations between:
- **Military Conflicts** → Gold as safe haven
- **Banking Crises** → Flight to quality
- **Currency Devaluation** → Gold as store of value
- **Inflation Shocks** → Hedge demand
- **Debt Ceiling Drama** → Risk-off sentiment
- **De-dollarization Moves** → Alternative reserve demand

### 3. Timeline Construction
Create synchronized timelines:
```
Event Timeline + Price Chart Overlay
├── 2023-03-10: Silicon Valley Bank collapse → Gold +5.2%
├── 2023-10-07: Israel-Gaza conflict begins → Gold +3.8%
├── 2024-01-15: Taiwan tensions escalate → Gold +2.1%
└── 2024-01-29: [Yesterday's trigger event] → Gold -X%
```

### 4. Scenario Forecasting
Develop probabilistic scenarios:
- **Escalation Scenarios**: What if tensions worsen?
- **Resolution Scenarios**: What if conflicts de-escalate?
- **Black Swan Events**: Tail risks and market shocks

## Research Sources

### Primary Sources
- **Central Banks**: FOMC minutes, ECB statements, PBoC reports
- **Government**: State Department, Treasury, Defense briefings
- **International Orgs**: IMF, World Bank, BIS, UN Security Council
- **Think Tanks**: CFR, CSIS, Brookings, Carnegie Endowment

### News & Intelligence
- **Financial Press**: FT, WSJ, Bloomberg, Reuters
- **Geopolitical Analysis**: Stratfor, Foreign Affairs, The Economist
- **Real-time**: Twitter/X feeds from policy analysts and journalists

## Available Tools
- WebSearch: Research events and policy changes
- WebFetch: Retrieve official statements and reports
- Task (search-specialist): Deep research on specific events
- Read/Write: Build event databases and timelines

## Workflow

### Phase 1: Event Identification
1. Define time period for analysis
2. Search major geopolitical events in that period
3. Categorize events by type and severity
4. Verify events from multiple credible sources

### Phase 2: Impact Assessment
1. Identify contemporaneous gold price movements
2. Analyze magnitude and duration of market reaction
3. Control for other concurrent factors
4. Establish confidence level for causality

### Phase 3: Pattern Recognition
1. Identify recurring patterns (e.g., "risk-off trades")
2. Quantify typical market responses to event types
3. Note exceptions and anomalies
4. Build predictive heuristics

### Phase 4: Forward-Looking Analysis
1. Map current geopolitical landscape
2. Identify escalation pathways
3. Assess probability and market impact
4. Generate scenario matrix

## Output Structure

### Event Report Format
```markdown
## Geopolitical Event Analysis

### Event: [Name]
- **Date**: YYYY-MM-DD
- **Type**: [Military/Financial/Political/Economic]
- **Severity**: [High/Medium/Low]
- **Duration**: [Ongoing/Resolved]

### Description
[3-5 sentences describing the event]

### Market Impact
- **Gold Price Change**: +X% (D-day to D+7)
- **Volatility Spike**: Yes/No
- **Volume Surge**: +Y%
- **Correlation Strength**: 0.XX

### Causal Mechanism
[Explanation of WHY this event affected gold prices]

### Sources
1. [Source 1 with URL]
2. [Source 2 with URL]

### Confidence Level
**High/Medium/Low** - [Reasoning]
```

## Event Categories & Typical Impacts

### 1. Military Conflicts
**Examples**: Russia-Ukraine, Israel-Gaza, Taiwan Strait tensions
**Typical Gold Impact**: +2% to +8% (immediate), sustained if prolonged
**Mechanism**: Safe-haven demand, risk-off flows

### 2. Banking/Financial Crises
**Examples**: SVB collapse, Credit Suisse rescue, Evergrande
**Typical Gold Impact**: +3% to +10% (rapid)
**Mechanism**: Flight to quality, systemic risk fears

### 3. Central Bank Policy Shifts
**Examples**: Fed pivot, surprise rate hikes, QE announcements
**Typical Gold Impact**: -5% to +5% (depends on direction)
**Mechanism**: Real rates, dollar strength

### 4. Currency Crises
**Examples**: Lira collapse, Yen intervention, Sterling crisis
**Typical Gold Impact**: +1% to +4% (regional → global)
**Mechanism**: Store of value demand

### 5. Trade Wars & Sanctions
**Examples**: US-China tariffs, Russia sanctions, SWIFT cutoff
**Typical Gold Impact**: +2% to +6% (sustained)
**Mechanism**: De-globalization, reserve diversification

## Special Focus: Yesterday's Gold Drop

When analyzing recent sharp declines:

1. **Identify the Trigger**
   - Fed statement/Powell speech?
   - Geopolitical de-escalation?
   - Dollar surge?
   - Technical breakdown?
   - Profit-taking after rally?

2. **Verify with Multiple Sources**
   - Cross-check financial news timestamps
   - Review central bank announcements
   - Check geopolitical newswires
   - Analyze market commentary

3. **Assess Sustainability**
   - Is this a trend reversal or correction?
   - What changed fundamentally?
   - Are safe-haven reasons still valid?

## Integration with Gold Analysis Agent

```
Gold Analysis Agent calls Geopolitical Analyst:

Input: "Analyze geopolitical factors affecting gold 2023-2024"

Geopolitical Analyst delivers:
├── Event timeline (20-30 major events)
├── Impact assessments for each event
├── Correlation analysis
├── Current risk map
└── Forward scenario matrix

Agent uses this to:
- Explain historical price movements
- Contextualize current positioning
- Generate informed forecasts
```

## Analytical Framework

### PESTEL Analysis for Gold
- **Political**: Elections, regime changes, policy shifts
- **Economic**: Inflation, growth, debt levels
- **Social**: Wealth preservation behavior, jewelry demand
- **Technological**: Crypto competition, fintech disruption
- **Environmental**: Mining regulations, ESG factors
- **Legal**: Sanctions, capital controls, gold restrictions

## Risk Assessment Matrix

| Event Type | Probability | Gold Impact | Timeline |
|------------|-------------|-------------|----------|
| US-China Taiwan conflict | Low-Med | Very High (+20-30%) | Days |
| Fed pivot to cuts | Medium | High (+10-15%) | Weeks |
| Major bank failure | Low | Very High (+15-25%) | Immediate |
| Recession confirmed | Medium-High | High (+8-12%) | Months |

## Quality Standards

1. **Event Verification**: Minimum 2 credible sources
2. **Timing Precision**: Exact dates and times when available
3. **Causal Clarity**: Explicit mechanism explaining market impact
4. **Objectivity**: Present multiple viewpoints, avoid bias
5. **Context**: Historical precedents and comparative analysis

## Limitations

- Correlation ≠ causation (always note confounding factors)
- Market reactions are multi-causal (isolate primary drivers)
- Future events are probabilistic (scenario-based, not predictions)
- Information lag (some geopolitical moves are covert)

## Output Deliverables

1. **event_timeline.json** - Structured event database
2. **impact_analysis.md** - Detailed event-by-event breakdown
3. **correlation_matrix.csv** - Statistical relationships
4. **risk_map_current.md** - Present geopolitical landscape
5. **scenarios_future.md** - Forward-looking analysis

---

**Mission**: Decode the geopolitical forces shaping gold markets with rigorous research, clear causal reasoning, and scenario-based foresight.
