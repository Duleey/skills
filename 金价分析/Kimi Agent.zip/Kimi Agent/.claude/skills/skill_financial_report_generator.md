# Financial Report Generator Skill

## Skill Metadata
- **Name**: financial-report-generator
- **Type**: Professional Financial Report & Visualization Specialist
- **Category**: Report Generation & Data Visualization

## Description
Expert skill for generating institutional-grade financial analysis reports with interactive charts, tables, and professional styling. Specializes in gold market reports, commodity analysis, and economic research documents with bilingual (EN/CN) support.

## When to Use This Skill

Use this skill PROACTIVELY when:
- Generating comprehensive market analysis reports
- Creating investor presentations or research documents
- Visualizing complex financial data and correlations
- Producing HTML/PDF reports with charts and tables
- Building interactive dashboards for data exploration
- Exporting analysis results to professional formats

## Core Capabilities

### 1. Report Types
- **Market Analysis Reports**: Comprehensive trend analysis with forecasts
- **Event Impact Reports**: Specific events and market reactions
- **Portfolio Reports**: Asset performance and recommendations
- **Economic Outlooks**: Macro analysis and scenario planning
- **Technical Analysis**: Chart patterns and indicators
- **Research Notes**: Focused topic deep-dives

### 2. Visualization Library
Pre-built chart types:
- **Line Charts**: Price trends over time
- **Candlestick Charts**: OHLC data with technical indicators
- **Correlation Heatmaps**: Multi-asset relationships
- **Scatter Plots**: Regression and relationship analysis
- **Bar Charts**: Comparative analysis (countries, periods)
- **Area Charts**: Cumulative flows (ETF holdings)
- **Tables**: Sortable, filterable data grids
- **Timeline Infographics**: Event chronology

### 3. Technology Stack
- **HTML5/CSS3**: Responsive, print-friendly layouts
- **Chart.js / D3.js**: Interactive JavaScript charts
- **Plotly**: Advanced statistical visualizations
- **DataTables**: Interactive table functionality
- **Export Options**: PDF (via print CSS), Excel, CSV

## Available Tools
- Write: Create HTML report files
- Bash: Generate charts using Python (matplotlib, plotly) or Node.js
- Read: Load data files for visualization
- Edit: Refine report sections

## Report Structure Template

### Gold Market Analysis Report

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>黄金市场分析报告 | Gold Market Analysis Report</title>

    <!-- Chart.js for visualizations -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"></script>

    <style>
        /* Professional Financial Styling */
        :root {
            --primary-blue: #1e3c72;
            --accent-gold: #d4af37;
            --text-dark: #2c3e50;
            --bg-light: #f8f9fa;
            --border-color: #dee2e6;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC',
                         'Microsoft YaHei', Arial, sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
            background: var(--bg-light);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Styles */
        .report-header {
            background: linear-gradient(135deg, var(--primary-blue) 0%, #2a5298 100%);
            color: white;
            padding: 50px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .report-header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .report-header .subtitle {
            font-size: 1.2em;
            opacity: 0.9;
            margin-bottom: 20px;
        }

        .report-meta {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            font-size: 0.95em;
        }

        .report-meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Section Styles */
        .section {
            background: white;
            padding: 40px;
            margin-bottom: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .section-header {
            border-left: 4px solid var(--accent-gold);
            padding-left: 20px;
            margin-bottom: 30px;
        }

        .section-header h2 {
            font-size: 1.8em;
            color: var(--primary-blue);
            margin-bottom: 5px;
        }

        .section-header .subtitle {
            color: #6c757d;
            font-size: 0.95em;
        }

        /* Executive Summary */
        .executive-summary {
            background: linear-gradient(to right, #fff8e1, #ffffff);
            border-left: 5px solid var(--accent-gold);
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 8px;
        }

        .key-findings {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .finding-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border-left: 3px solid var(--primary-blue);
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .finding-card h4 {
            color: var(--primary-blue);
            margin-bottom: 10px;
        }

        .finding-card .metric {
            font-size: 2em;
            font-weight: bold;
            color: var(--accent-gold);
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            height: 500px;
            margin: 30px 0;
            padding: 20px;
            background: #fafafa;
            border-radius: 8px;
            border: 1px solid var(--border-color);
        }

        .chart-container canvas {
            max-height: 450px;
        }

        .chart-title {
            text-align: center;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 15px;
            font-size: 1.1em;
        }

        /* Data Table */
        .data-table-wrapper {
            overflow-x: auto;
            margin: 20px 0;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95em;
        }

        .data-table thead {
            background: var(--primary-blue);
            color: white;
        }

        .data-table th,
        .data-table td {
            padding: 14px;
            text-align: left;
            border: 1px solid var(--border-color);
        }

        .data-table tbody tr:nth-child(even) {
            background: #f8f9fa;
        }

        .data-table tbody tr:hover {
            background: #e9ecef;
        }

        .data-table .number {
            text-align: right;
            font-family: 'Monaco', 'Courier New', monospace;
        }

        .positive {
            color: #28a745;
            font-weight: 600;
        }

        .negative {
            color: #dc3545;
            font-weight: 600;
        }

        /* Highlight Boxes */
        .highlight-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }

        .highlight-box.info {
            background: #d1ecf1;
            border-left-color: #17a2b8;
        }

        .highlight-box.success {
            background: #d4edda;
            border-left-color: #28a745;
        }

        .highlight-box.warning {
            background: #fff3cd;
            border-left-color: #ffc107;
        }

        .highlight-box.danger {
            background: #f8d7da;
            border-left-color: #dc3545;
        }

        /* Timeline */
        .timeline {
            position: relative;
            padding-left: 40px;
            margin: 30px 0;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: var(--border-color);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 30px;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -34px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--accent-gold);
            border: 2px solid white;
            box-shadow: 0 0 0 2px var(--accent-gold);
        }

        .timeline-date {
            font-weight: 600;
            color: var(--primary-blue);
            margin-bottom: 5px;
        }

        .timeline-content {
            background: white;
            padding: 15px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
        }

        /* Forecast Cards */
        .forecast-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .forecast-card {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            padding: 25px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .forecast-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .forecast-card.bullish {
            border-color: #28a745;
        }

        .forecast-card.bearish {
            border-color: #dc3545;
        }

        .forecast-card.neutral {
            border-color: #ffc107;
        }

        .forecast-card h3 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }

        .forecast-card .probability {
            font-size: 2em;
            font-weight: bold;
            color: var(--accent-gold);
            margin: 10px 0;
        }

        .forecast-card .target {
            font-size: 1.5em;
            font-weight: 600;
            margin: 10px 0;
        }

        /* Source Citations */
        .sources {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            margin-top: 40px;
        }

        .sources h3 {
            color: var(--primary-blue);
            margin-bottom: 15px;
        }

        .source-list {
            list-style: none;
            counter-reset: source-counter;
        }

        .source-list li {
            counter-increment: source-counter;
            margin-bottom: 12px;
            padding-left: 30px;
            position: relative;
        }

        .source-list li::before {
            content: "[" counter(source-counter) "]";
            position: absolute;
            left: 0;
            color: var(--primary-blue);
            font-weight: 600;
        }

        .source-list a {
            color: #0066cc;
            text-decoration: none;
        }

        .source-list a:hover {
            text-decoration: underline;
        }

        .source-meta {
            font-size: 0.85em;
            color: #6c757d;
            margin-top: 3px;
        }

        /* Risk Warning */
        .risk-warning {
            background: #f8d7da;
            border: 2px solid #dc3545;
            border-radius: 8px;
            padding: 25px;
            margin: 30px 0;
        }

        .risk-warning h3 {
            color: #dc3545;
            margin-bottom: 15px;
        }

        /* Footer */
        .report-footer {
            background: var(--text-dark);
            color: white;
            padding: 30px;
            border-radius: 8px;
            margin-top: 40px;
            text-align: center;
        }

        /* Print Styles */
        @media print {
            body {
                background: white;
            }
            .section {
                page-break-inside: avoid;
                box-shadow: none;
            }
            .chart-container {
                page-break-inside: avoid;
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .report-header {
                padding: 30px 20px;
            }
            .section {
                padding: 25px 20px;
            }
            .chart-container {
                height: 350px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Report Header -->
        <header class="report-header">
            <h1>
                <span>🏆</span>
                黄金市场深度分析报告
            </h1>
            <div class="subtitle">Gold Market In-Depth Analysis Report</div>
            <div class="report-meta">
                <div class="report-meta-item">
                    <strong>报告日期 Report Date:</strong> {{REPORT_DATE}}
                </div>
                <div class="report-meta-item">
                    <strong>分析周期 Period:</strong> {{ANALYSIS_PERIOD}}
                </div>
                <div class="report-meta-item">
                    <strong>分析师 Analyst:</strong> Claude Gold Intelligence Agent
                </div>
            </div>
        </header>

        <!-- Executive Summary -->
        <section class="section">
            <div class="executive-summary">
                <h2>📋 执行摘要 | Executive Summary</h2>
                <p>{{EXECUTIVE_SUMMARY_CN}}</p>
                <p><em>{{EXECUTIVE_SUMMARY_EN}}</em></p>

                <div class="key-findings">
                    <div class="finding-card">
                        <h4>年度涨幅 YoY Change</h4>
                        <div class="metric {{POSITIVE_OR_NEGATIVE}}">{{YOY_CHANGE}}</div>
                    </div>
                    <div class="finding-card">
                        <h4>当前价格 Current Price</h4>
                        <div class="metric">{{CURRENT_PRICE}}</div>
                    </div>
                    <div class="finding-card">
                        <h4>12月预测 12M Forecast</h4>
                        <div class="metric">{{FORECAST_PRICE}}</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Historical Price Analysis -->
        <section class="section">
            <div class="section-header">
                <h2>📈 历史价格分析 | Historical Price Analysis</h2>
                <div class="subtitle">{{PERIOD}} Gold Spot Price Performance</div>
            </div>

            <div class="chart-container">
                <div class="chart-title">黄金现货价格走势图 | Gold Spot Price Trend (USD/oz)</div>
                <canvas id="priceChart"></canvas>
            </div>

            <div class="data-table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>时间 Period</th>
                            <th class="number">开盘 Open</th>
                            <th class="number">最高 High</th>
                            <th class="number">最低 Low</th>
                            <th class="number">收盘 Close</th>
                            <th class="number">涨跌幅 Change</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{PRICE_DATA_ROWS}}
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Geopolitical Events -->
        <section class="section">
            <div class="section-header">
                <h2>🌍 地缘政治事件时间线 | Geopolitical Timeline</h2>
                <div class="subtitle">Major Events and Market Impact</div>
            </div>

            <div class="timeline">
                {{TIMELINE_ITEMS}}
            </div>
        </section>

        <!-- Correlation Analysis -->
        <section class="section">
            <div class="section-header">
                <h2>🔗 相关性分析 | Correlation Analysis</h2>
                <div class="subtitle">Gold vs. Key Economic Indicators</div>
            </div>

            <div class="chart-container">
                <div class="chart-title">黄金与美元指数关系 | Gold vs. DXY</div>
                <canvas id="correlationChart"></canvas>
            </div>

            <div class="highlight-box info">
                <strong>关键发现 Key Finding:</strong> {{CORRELATION_INSIGHT}}
            </div>
        </section>

        <!-- Yesterday's Drop Analysis -->
        <section class="section">
            <div class="section-header">
                <h2>📉 昨日大跌分析 | Yesterday's Sharp Decline Analysis</h2>
                <div class="subtitle">{{YESTERDAY_DATE}} - Detailed Breakdown</div>
            </div>

            <div class="highlight-box danger">
                <h3>价格变动 Price Movement</h3>
                <p><strong>跌幅 Decline:</strong> <span class="negative">{{DROP_PERCENTAGE}}</span></p>
                <p><strong>价格 Price:</strong> ${{START_PRICE}} → ${{END_PRICE}}</p>
            </div>

            <h3>触发因素 Trigger Factors</h3>
            {{TRIGGER_FACTORS_LIST}}

            <h3>市场反应 Market Reaction</h3>
            {{MARKET_REACTION_ANALYSIS}}
        </section>

        <!-- Future Outlook -->
        <section class="section">
            <div class="section-header">
                <h2>🔮 未来展望 | 12-Month Outlook</h2>
                <div class="subtitle">Scenario-Based Forecasts</div>
            </div>

            <div class="forecast-grid">
                <div class="forecast-card bullish">
                    <h3>🐂 牛市情景 Bull Case</h3>
                    <div class="probability">{{BULL_PROBABILITY}}</div>
                    <div class="target">目标价: ${{BULL_TARGET}}</div>
                    <p>{{BULL_SCENARIO_DESC}}</p>
                </div>

                <div class="forecast-card neutral">
                    <h3>📊 基准情景 Base Case</h3>
                    <div class="probability">{{BASE_PROBABILITY}}</div>
                    <div class="target">目标价: ${{BASE_TARGET}}</div>
                    <p>{{BASE_SCENARIO_DESC}}</p>
                </div>

                <div class="forecast-card bearish">
                    <h3>🐻 熊市情景 Bear Case</h3>
                    <div class="probability">{{BEAR_PROBABILITY}}</div>
                    <div class="target">目标价: ${{BEAR_TARGET}}</div>
                    <p>{{BEAR_SCENARIO_DESC}}</p>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-title">预测区间 | Forecast Range</div>
                <canvas id="forecastChart"></canvas>
            </div>
        </section>

        <!-- Risk Warning -->
        <section class="risk-warning">
            <h3>⚠️ 风险提示 | Risk Disclaimer</h3>
            <p>本报告仅供参考,不构成投资建议。黄金价格受多种因素影响,具有较高波动性。投资者应根据自身风险承受能力谨慎决策。过往表现不代表未来收益。</p>
            <p><em>This report is for reference only and does not constitute investment advice. Gold prices are influenced by multiple factors and exhibit high volatility. Investors should make prudent decisions based on their own risk tolerance. Past performance does not guarantee future returns.</em></p>
        </section>

        <!-- Data Sources -->
        <div class="sources">
            <h3>📚 数据来源 | Data Sources</h3>
            <ul class="source-list">
                {{SOURCE_LIST_ITEMS}}
            </ul>
        </div>

        <!-- Footer -->
        <footer class="report-footer">
            <p><strong>Generated by Claude Gold Intelligence Agent</strong></p>
            <p>Powered by Anthropic Claude | Report Date: {{GENERATION_TIMESTAMP}}</p>
        </footer>
    </div>

    <!-- Chart Scripts -->
    <script>
        // Price Chart
        const priceCtx = document.getElementById('priceChart').getContext('2d');
        const priceChart = new Chart(priceCtx, {
            type: 'line',
            data: {
                labels: {{PRICE_LABELS}},
                datasets: [{
                    label: 'Gold Spot Price (USD/oz)',
                    data: {{PRICE_DATA}},
                    borderColor: '#d4af37',
                    backgroundColor: 'rgba(212, 175, 55, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'month'
                        }
                    },
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });

        // Correlation Chart
        const corrCtx = document.getElementById('correlationChart').getContext('2d');
        const correlationChart = new Chart(corrCtx, {
            type: 'scatter',
            data: {
                datasets: [{
                    label: 'Gold vs DXY',
                    data: {{CORRELATION_DATA}},
                    backgroundColor: 'rgba(30, 60, 114, 0.6)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'DXY Index'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Gold Price (USD/oz)'
                        }
                    }
                }
            }
        });

        // Forecast Chart
        const forecastCtx = document.getElementById('forecastChart').getContext('2d');
        const forecastChart = new Chart(forecastCtx, {
            type: 'line',
            data: {
                labels: {{FORECAST_LABELS}},
                datasets: [
                    {
                        label: 'Bull Case',
                        data: {{BULL_FORECAST_DATA}},
                        borderColor: '#28a745',
                        borderDash: [5, 5],
                        fill: false
                    },
                    {
                        label: 'Base Case',
                        data: {{BASE_FORECAST_DATA}},
                        borderColor: '#ffc107',
                        borderWidth: 3,
                        fill: false
                    },
                    {
                        label: 'Bear Case',
                        data: {{BEAR_FORECAST_DATA}},
                        borderColor: '#dc3545',
                        borderDash: [5, 5],
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
```

## Workflow

### Step 1: Data Preparation
- Receive structured data from financial-data-fetcher
- Receive event timeline from geopolitical-analyst
- Receive analysis insights from business-analyst

### Step 2: Template Selection
- Choose appropriate report template
- Configure bilingual sections (CN/EN)
- Set styling theme (professional/modern/classic)

### Step 3: Content Generation
- Populate executive summary with key findings
- Insert data tables with proper formatting
- Generate chart configurations with real data
- Build event timeline with impact annotations

### Step 4: Visualization
- Create Chart.js configurations for:
  - Historical price line charts
  - Correlation scatter plots
  - Forecast range projections
  - Comparative bar charts
- Embed interactive features (tooltips, zoom, filters)

### Step 5: Source Attribution
- List all data sources with URLs
- Add retrieval timestamps
- Include methodology notes
- Append data quality metrics

### Step 6: Export Options
- Primary: HTML (self-contained, interactive)
- PDF: Print-optimized CSS (@media print)
- Data export: CSV/Excel for raw data

## Quality Standards

1. **Visual Hierarchy**: Clear section structure, consistent styling
2. **Bilingual Support**: Chinese primary, English secondary
3. **Data Integrity**: All numbers traceable to sources
4. **Accessibility**: Readable fonts, sufficient contrast
5. **Responsiveness**: Mobile, tablet, desktop layouts
6. **Print-Friendly**: Page breaks, simplified styling for PDF

## Chart Configuration Standards

### Color Palette
- Gold: `#d4af37` (primary asset)
- Blue: `#1e3c72` (headings, professional tone)
- Green: `#28a745` (positive movements, bull case)
- Red: `#dc3545` (negative movements, bear case)
- Yellow: `#ffc107` (warnings, neutral scenarios)

### Data Formatting
- Prices: `$X,XXX.XX` (USD, 2 decimals)
- Percentages: `+/-XX.X%` (1 decimal, with sign)
- Dates: `YYYY-MM-DD` (ISO format) or `Jan 30, 2024` (readable)
- Large numbers: `2.5M` (abbreviated with suffix)

## Output Files

1. **gold_analysis_report.html** - Main interactive report
2. **gold_analysis_report.pdf** - Print-optimized version (via browser print)
3. **data_appendix.csv** - Raw data export
4. **chart_data.json** - Chart configurations for reuse

## Integration Example

```javascript
// Agent calls this skill with structured data
const reportData = {
    reportDate: '2024-01-30',
    analysisPeriod: '2023-01-01 to 2024-01-30',
    priceData: [...],
    geopoliticalEvents: [...],
    correlationData: {...},
    forecastScenarios: {...},
    sources: [...]
};

// Skill generates HTML report
generateFinancialReport(reportData, {
    template: 'gold_market_analysis',
    language: 'bilingual-zh-en',
    chartLibrary: 'chartjs',
    exportFormats: ['html', 'pdf']
});
```

## Customization Options

- **Templates**: Gold/Commodities/Forex/Equities
- **Languages**: EN, CN, bilingual, or custom
- **Chart Libraries**: Chart.js (default), D3.js (advanced), Plotly (statistical)
- **Styling**: Professional/Modern/Minimal themes
- **Interactivity**: Static/Interactive/Dashboard modes

## Performance Optimization

- Lazy load charts (render on viewport)
- Compress embedded images
- Minify CSS/JS for production
- Use CDN for libraries (Chart.js, etc.)
- Optimize for 1MB target file size

---

**Mission**: Transform complex financial data into compelling, professional, and actionable reports that stakeholders can trust and act upon.
