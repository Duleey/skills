# 🏆 黄金市场分析 Agent

> **基于公开数据的专业金融分析系统 · 无需 API Key**

[![版本](https://img.shields.io/badge/version-v3.2.0-blue.svg)](docs/UPDATE_LOG.md)
[![数据源](https://img.shields.io/badge/data-public%20only-green.svg)](docs/04-DATA_SOURCES.md)
[![API Key](https://img.shields.io/badge/API_Key-not%20required-brightgreen.svg)](docs/04-DATA_SOURCES.md)

---

## ⚡ 快速开始

### 方式 1: 使用启动脚本（推荐）⭐

```bash
# 交互式模式
./start-gold-agent.sh

# 直接执行任务
./start-gold-agent.sh "获取当前金价并分析走势"

# 使用英文版
./start-gold-agent.sh --en "Analyze current gold market"

# 查看所有选项
./start-gold-agent.sh --help
```

### 方式 2: 直接使用 Claude Code

Claude Code 会自动加载 `.claude/settings.json` 配置：

```bash
# 进入项目目录
cd /path/to/Announcement

# 启动 Claude Code（自动加载配置）
claude

# 输入任务
💬 "获取当前金价并分析市场走势"
```

---

## 🎯 核心特性

### ✅ 无需 API Key
- **所有数据来自公开网站**，无需注册和密钥
- WebSearch + WebFetch 组合获取实时数据
- Coinbase API（无需密钥）
- 金融新闻网站爬取（Kitco、GoldPrice.org、Investing.com）

### ✅ 3个专业 Skills
- **financial-data-fetcher** - 数据获取与验证专家
- **geopolitical-analyst** - 地缘政治分析专家
- **financial-report-generator** - 专业报告生成器（shadcn/ui 设计）

### ✅ 多维度分析
- 技术分析（RSI、MACD、布林带）
- 基本面分析（地缘政治、经济事件）
- 情景预测（三种可能走势）
- 风险评估（止损建议）

### ✅ 现代化设计
- shadcn/ui Zinc 暗色主题
- 响应式卡片布局
- Chart.js 数据可视化
- 双语支持（中文/English）

---

## 📁 项目结构

```
Announcement/
├── .claude/                              # Claude Code 配置（核心）
│   ├── prompts/                          # 系统提示词
│   │   ├── system_prompt_cn.md           # ⭐ 中文提示词
│   │   └── system_prompt_en.md           # ⭐ 英文提示词
│   ├── skills/                           # 3个专业 Skills
│   │   ├── skill_financial_data_fetcher.md
│   │   ├── skill_geopolitical_analyst.md
│   │   └── skill_financial_report_generator.md
│   ├── agents/                           # Sub-agents 配置
│   ├── config/                           # 其他配置
│   ├── settings.json                     # ⭐ 主配置文件
│   └── mcp.json                          # MCP 配置
│
├── docs/                                 # 📚 所有文档
│   ├── README.md                         # 文档导航索引
│   ├── 04-DATA_SOURCES.md                # 数据源说明
│   ├── 05-CAPABILITY.md                  # 能力对比
│   ├── 06-DIRECTORY_STRUCTURE.md         # 目录结构
│   ├── UPDATE_LOG.md                     # 更新日志
│   └── archives/                         # 旧文档归档
│
├── scripts/                              # 🛠️ 工具脚本
│   ├── fetch_real_gold_data.py           # 数据获取脚本
│   └── setup.sh                          # 环境设置
│
├── README.md                             # 本文件
├── USER_PROMPT_EXAMPLE.md                # ⭐ 使用示例
└── start-gold-agent.sh                   # ⭐ 启动脚本
```

> 💡 **重要**：所有配置文件都在 `.claude/` 目录下，符合 Claude Code 标准。

---

## 🚀 使用流程

### Agent 自动执行流程

```
用户请求 → Agent 分析
    ↓
1. 使用 WebSearch 搜索最新金价数据
    ↓
2. 使用 WebFetch 从 Kitco/GoldPrice.org 获取数据
    ↓
3. 使用 financial-data-fetcher skill 验证和结构化数据
    ↓
4. 使用 geopolitical-analyst skill 分析市场事件
    ↓
5. 技术分析 + 基本面分析
    ↓
6. 使用 financial-report-generator skill 生成 HTML 报告
    ↓
7. 输出报告（含数据来源和时间戳）
```

### 如果数据获取失败

Agent 会：
1. 尝试多个公开数据源（Kitco、GoldPrice.org、Investing.com）
2. 明确告知哪些数据源不可用
3. 提供官方网站链接供手动查询
4. **绝不编造数字**

---

## 📊 公开数据来源（无需 API Key）

### 价格数据
- **Kitco**: https://www.kitco.com/charts/livegold.html
- **GoldPrice.org**: https://goldprice.org/
- **Investing.com**: https://www.investing.com/commodities/gold
- **Coinbase API**: 无需密钥的公开接口

### 市场数据
- **LBMA**: https://www.lbma.org.uk/prices-and-data/precious-metal-prices
- **World Gold Council**: https://www.gold.org/goldhub/data/gold-prices
- **BullionVault**: https://www.bullionvault.com/gold-price-chart.do

### 新闻与分析
- **WebSearch**: 实时金融新闻搜索
- **Reuters, Bloomberg, CNBC**: 通过 WebFetch 获取
- **Trading Economics**: 经济指标和数据

> 📖 详细数据源说明：[docs/04-DATA_SOURCES.md](docs/04-DATA_SOURCES.md)

---

## 💡 使用示例

完整的使用示例请查看：**[USER_PROMPT_EXAMPLE.md](USER_PROMPT_EXAMPLE.md)** ⭐

### 示例1：获取当前金价
```
用户: "当前金价是多少？"

Agent:
[使用 WebSearch 搜索最新金价]
[使用 WebFetch 从 Kitco 获取数据]

输出:
根据实时查询（2026-01-30 15:23 UTC）：
- 金价: $2,845.30 USD/盎司
- 数据源: Kitco.com
- 查询时间: 2026-01-30T15:23:17Z

您可以访问 https://www.kitco.com/charts/livegold.html 验证此数据。
```

### 示例2：深度市场分析
```
用户: "分析2026年1月29日的金价暴跌事件"

Agent:
[使用 financial-data-fetcher skill 获取历史数据]
[使用 geopolitical-analyst skill 分析地缘事件]
[计算技术指标：RSI, MACD, 布林带]
[使用 financial-report-generator skill 生成报告]

输出:
## 黄金市场深度分析报告
### 2026年1月29日价格波动分析

📊 **数据来源**:
- 金价数据: Kitco.com (2025-01 至 2026-01)
- 新闻事件: Reuters, Bloomberg (WebSearch + WebFetch)
- 查询时间: 2026-01-30 15:30 UTC

📈 **技术分析**: [基于真实数据计算]
- RSI(14): 45.2 (中性区域)
- MACD: 负值，下跌趋势
- 布林带: 价格触及下轨

🌍 **地缘分析**: [基于实际新闻]
- 事件1: ...
- 事件2: ...

[完整 HTML 报告，shadcn/ui Zinc 主题]
```

---

## ⚠️ 重要原则

### Agent 绝对禁止
- ❌ 编造任何价格数字
- ❌ 假设"当前金价是$X"
- ❌ 虚构市场事件
- ❌ 编造技术指标

### Agent 必须遵守
- ✅ 每次分析前先获取真实数据
- ✅ 标注所有数据的来源和时间
- ✅ 无法获取数据时明确告知
- ✅ 提供可验证的信息

---

## 📚 文档说明

| 文档 | 用途 |
|------|------|
| **核心文档** | |
| [USER_PROMPT_EXAMPLE.md](USER_PROMPT_EXAMPLE.md) | ⭐ 完整使用示例（推荐阅读）|
| [start-gold-agent.sh](start-gold-agent.sh) | ⭐ 一键启动脚本 |
| [.claude/settings.json](.claude/settings.json) | ⭐ 主配置文件 |
| **系统提示词** | |
| [.claude/prompts/system_prompt_cn.md](.claude/prompts/system_prompt_cn.md) | Agent 系统提示词（中文）|
| [.claude/prompts/system_prompt_en.md](.claude/prompts/system_prompt_en.md) | Agent 系统提示词（英文）|
| **详细文档** | |
| [docs/README.md](docs/README.md) | 📚 文档导航索引 |
| [docs/04-DATA_SOURCES.md](docs/04-DATA_SOURCES.md) | 数据源详细说明 |
| [docs/05-CAPABILITY.md](docs/05-CAPABILITY.md) | 更新前后能力对比 |
| [docs/06-DIRECTORY_STRUCTURE.md](docs/06-DIRECTORY_STRUCTURE.md) | 目录结构验证 |
| [docs/UPDATE_LOG.md](docs/UPDATE_LOG.md) | 📝 详细更新日志 |

---

## 🔧 Skills 说明

本系统包含 3 个专业 Skills（位于 `.claude/skills/`）：

### 1. financial-data-fetcher（数据获取专家）
- **功能**: 从权威公开源获取、验证、结构化金融数据
- **数据源**: Kitco, GoldPrice.org, Investing.com, Coinbase API
- **输出**: JSON/CSV 格式的结构化数据

### 2. geopolitical-analyst（地缘分析专家）
- **功能**: 地缘政治事件研究、市场影响评估、情景预测
- **方法**: 事件时间线、影响评估矩阵、多情景分析
- **输出**: 详细的地缘分析报告

### 3. financial-report-generator（报告生成器）
- **功能**: 专业 HTML 报告生成、数据可视化
- **设计**: shadcn/ui Zinc 暗色主题、响应式布局
- **特色**: Chart.js 图表、双语支持（中文/English）

---

## ⚖️ 免责声明

- 本系统提供市场分析工具，**不构成投资建议**
- 所有数据来自第三方API和公开网站
- 预测基于模型和历史数据，**不保证准确性**
- 黄金投资有风险，请**咨询专业财务顾问**

---

## 📞 需要帮助？

1. **快速开始**：查看 [USER_PROMPT_EXAMPLE.md](USER_PROMPT_EXAMPLE.md)
2. **文档导航**：查看 [docs/README.md](docs/README.md)
3. **数据源说明**：查看 [docs/04-DATA_SOURCES.md](docs/04-DATA_SOURCES.md)
4. **更新日志**：查看 [docs/UPDATE_LOG.md](docs/UPDATE_LOG.md)

---

<div align="center">

**数据真实 · 分析客观 · 无需密钥**

版本: v3.2.0-public-data-only

最后更新: 2026-01-30

</div>
