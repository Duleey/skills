#!/bin/bash

##############################################################################
# Claude Code 黄金分析 Agent 启动脚本
#
# 功能：
# - 加载系统提示词
# - 配置环境变量
# - 启动 Claude Code Agent
#
# 使用方法：
#   ./start-gold-agent.sh                    # 交互式模式
#   ./start-gold-agent.sh "分析当前金价"      # 直接执行命令
#   ./start-gold-agent.sh --en               # 使用英文提示词
##############################################################################

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$SCRIPT_DIR"

# 默认配置
LANGUAGE="zh"
MODEL="sonnet"
SYSTEM_PROMPT_PATH="$PROJECT_ROOT/.claude/prompts/system_prompt_cn.md"

##############################################################################
# 辅助函数
##############################################################################

print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}   🏆 Claude Code 黄金市场分析 Agent${NC}"
    echo -e "${BLUE}   版本: v3.1.0-real-data-with-subagents${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
}

print_info() {
    echo -e "${GREEN}ℹ${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✖${NC} $1"
}

check_requirements() {
    print_info "检查运行环境..."

    # 检查 claude 命令
    if ! command -v claude &> /dev/null; then
        print_error "Claude Code 未安装"
        echo "请访问: https://claude.ai/download 安装 Claude Code"
        exit 1
    fi

    # 检查 Python
    if ! command -v python3 &> /dev/null; then
        print_warning "Python3 未安装，部分功能可能不可用"
    fi

    # 检查系统提示词文件
    if [ ! -f "$SYSTEM_PROMPT_PATH" ]; then
        print_error "系统提示词文件不存在: $SYSTEM_PROMPT_PATH"
        exit 1
    fi

    print_info "✓ 环境检查通过"
}

load_env_file() {
    local env_file="$PROJECT_ROOT/.env"

    if [ -f "$env_file" ]; then
        print_info "加载环境变量从: $env_file"
        export $(cat "$env_file" | grep -v '^#' | xargs)
    else
        print_warning "未找到 .env 文件，API keys 可能未配置"
        print_info "可创建 .env 文件并添加:"
        echo "  FRED_API_KEY=your_key"
        echo "  ALPHA_VANTAGE_KEY=your_key"
    fi
}

print_config() {
    echo ""
    print_info "当前配置:"
    echo "  - 语言: $([ "$LANGUAGE" == "zh" ] && echo "中文" || echo "English")"
    echo "  - 模型: $MODEL"
    echo "  - 提示词: $(basename $SYSTEM_PROMPT_PATH)"
    echo "  - 项目目录: $PROJECT_ROOT"
    echo ""
}

show_help() {
    cat << EOF
使用方法:
  $0 [选项] [提示]

选项:
  --en              使用英文系统提示词
  --zh              使用中文系统提示词（默认）
  --model <model>   指定模型 (sonnet/opus/haiku)
  --print           非交互模式（打印输出后退出）
  --json            JSON 格式输出（需配合 --print）
  --help            显示此帮助信息

示例:
  # 交互式模式（默认）
  $0

  # 直接执行任务
  $0 "获取当前金价并分析走势"

  # 使用英文提示词
  $0 --en "Analyze current gold market"

  # 使用 Opus 模型进行复杂分析
  $0 --model opus "预测未来12个月金价走势"

  # 非交互模式，JSON 输出
  $0 --print --json "获取当前金价"

环境变量:
  FRED_API_KEY           - Federal Reserve Economic Data API Key
  ALPHA_VANTAGE_KEY      - Alpha Vantage API Key

配置文件:
  .env                   - 环境变量配置
  .claude/settings.json  - Claude Code 设置
  .claude/mcp.json       - MCP 服务器配置

更多信息:
  - 文档: docs/CLAUDE_CODE_FEATURES.md
  - 快速参考: docs/QUICK_REFERENCE_CLAUDE.md
  - 系统提示词: .claude/prompts/system_prompt_cn.md

EOF
}

##############################################################################
# 参数解析
##############################################################################

PRINT_MODE=false
OUTPUT_FORMAT="text"
USER_PROMPT=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --en)
            LANGUAGE="en"
            SYSTEM_PROMPT_PATH="$PROJECT_ROOT/.claude/prompts/system_prompt_en.md"
            shift
            ;;
        --zh)
            LANGUAGE="zh"
            SYSTEM_PROMPT_PATH="$PROJECT_ROOT/.claude/prompts/system_prompt_cn.md"
            shift
            ;;
        --model)
            MODEL="$2"
            shift 2
            ;;
        --print)
            PRINT_MODE=true
            shift
            ;;
        --json)
            OUTPUT_FORMAT="json"
            shift
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        *)
            USER_PROMPT="$1"
            shift
            ;;
    esac
done

##############################################################################
# 主程序
##############################################################################

main() {
    print_header
    check_requirements
    load_env_file
    print_config

    # 构建 claude 命令
    CLAUDE_CMD="claude"

    # 添加系统提示词
    CLAUDE_CMD="$CLAUDE_CMD --system-prompt \"$(cat "$SYSTEM_PROMPT_PATH")\""

    # 添加模型选项
    CLAUDE_CMD="$CLAUDE_CMD --model $MODEL"

    # 添加工作目录
    CLAUDE_CMD="$CLAUDE_CMD --add-dir \"$PROJECT_ROOT\""

    # 允许的工具
    CLAUDE_CMD="$CLAUDE_CMD --allowed-tools \"Bash(python3:*) Bash(curl:*) Read Write Edit Glob Grep WebSearch WebFetch Task\""

    # MCP 配置（如果存在）
    if [ -f "$PROJECT_ROOT/.claude/mcp.json" ]; then
        CLAUDE_CMD="$CLAUDE_CMD --mcp-config \"$PROJECT_ROOT/.claude/mcp.json\""
    fi

    # 非交互模式
    if [ "$PRINT_MODE" = true ]; then
        CLAUDE_CMD="$CLAUDE_CMD --print"
        if [ "$OUTPUT_FORMAT" = "json" ]; then
            CLAUDE_CMD="$CLAUDE_CMD --output-format json"
        fi
    fi

    # 添加用户提示
    if [ -n "$USER_PROMPT" ]; then
        CLAUDE_CMD="$CLAUDE_CMD \"$USER_PROMPT\""
    fi

    # 显示启动信息
    if [ "$PRINT_MODE" = false ]; then
        print_info "启动 Claude Code Agent..."
        echo ""
        echo -e "${GREEN}提示：${NC}"
        echo "  - 输入 'exit' 或按 Ctrl+D 退出"
        echo "  - 使用 Task() 调用子代理"
        echo "  - 数据脚本: python3 scripts/fetch_real_gold_data.py"
        echo ""
    fi

    # 执行命令
    eval $CLAUDE_CMD
}

# 运行主程序
main
