---
description: Restate requirements, assess risks, and create step-by-step implementation plan. WAIT for user CONFIRM before touching any code.
---

# Plan Command

创建实施计划，在写代码之前明确需求和步骤。

## 工作流程

1. **重述需求** — 用清晰的语言确认要做什么
2. **识别风险** — 列出潜在问题和阻塞点
3. **拆分步骤** — 按阶段分解任务
4. **等待确认** — 必须获得用户批准后才能执行

## 适用场景

- 开发新策略或因子
- 策略优化和参数搜索
- 多文件重构
- 需求不明确时

## 示例

```
User: /plan 优化小市值_lee策略

Agent:
# 优化计划：小市值_lee策略

## 需求确认
- 在现有 lee 策略基础上寻找更优参数组合
- 目标：提升收益回撤比，同时保持持仓体验

## 实施阶段

### Phase 0: 可优化性诊断（5-8组）
- 跑极端参数对比，评估5个维度的可优化性评分
- 得分<4 → 建议跳过

### Phase 1: 快速参数扫描（20-30组，训练集 2016-2023）
- 维度1：select_num [3, 5, 8, 10]
- 维度2：过滤阈值调整
- 维度3：权重调整
- 使用 `选股+回测.py` 快速路径
- **评估**：运行 enhanced_evaluate + compare_strategies，对比原版基线，标注每个指标方向（↑/↓）

### Phase 2: 深度优化（如 Phase 1 改善>10%）
- 先全量日期算一次因子（2014-至今）
- 训练集搜索 + 验证集Mini验证
- 每维度完成后检查过拟合
- **评估**：运行 enhanced_evaluate + compare_strategies，对比 Phase 1 最优结果

### Phase 3: 长周期验证（2014-至今）
- 对比原版 vs 优化版
- 确认无过拟合
- **评估**：运行 enhanced_evaluate + compare_strategies，输出完整4张对比表 + 硬性否决条件检查 + 采纳/回滚决策

## 风险
- 过拟合风险：参数搜索空间大时需严格控制
- 因子缓存：需确保全量日期覆盖所有子集

## 复杂度：MEDIUM

**等待确认**：按此计划执行？
```

## 重要规则

- **不提供时间估算**
- 必须等用户确认后才能开始执行
- 量化相关计划必须包含数据分割方案（训练集/验证集）
- **每个 Phase 必须包含「评估步骤」**：运行 `enhanced_evaluate()` + `compare_strategies()` 横向对比核心指标，标注方向（↑越高越好/↓越低越好），立即判定改善/恶化
- **不能等所有 Phase 跑完才评估**，必须边做边评估、及时止损
