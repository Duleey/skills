---
description: 防止回测中的未来函数（look-ahead bias），这是量化策略开发中最危险的错误
globs: ["config库/**", "docs/策略研究/**", "*.py"]
---

# 未来函数防范规则

## 核心原则

**择时因子的数据时间 ≤ rebalance_time**

违反此原则意味着使用了未来数据做交易决策，导致回测结果虚高（可能高估50%以上），
在实盘中无法复现。

## rebalance_time 与 timing factor_list 的时间关系

### 日内定时换仓（如 `'0935-0935'`、`'0950-0950'`）

格式：`'SELL_TIME-BUY_TIME'`

规则：timing.factor_list 中每个因子的第5个参数（分钟时间）必须 ≤ BUY_TIME

```python
# ✅ 正确：rebalance=0945, 择时因子用 0945 和 0935（都 ≤ 0945）
"rebalance_time": "0945-0945",
"timing": {
    "factor_list": [
        ("开盘至今涨幅", False, None, 1, "0945"),
        ("隔夜涨跌幅", False, None, 1, "0935"),
    ],
}

# ❌ 错误：rebalance=0935, 但择时用了 0950 数据（15分钟未来数据）
"rebalance_time": "0935-0935",
"timing": {
    "factor_list": [
        ("开盘至今涨幅", False, None, 1, "0950"),  # 未来函数！
    ],
}
```

### 隔日换仓（`'close-open'`）

择时因子可以使用任意盘中时间，因为选股在 T-1 日完成，交易在 T 日执行。
这种模式**天然不会产生未来函数**（只要因子不使用 T 日数据）。

### 开盘换仓（`'open'`）

与 `'close-open'` 类似，在开盘价执行，择时信号基于前一日数据。

## 检查清单（每次创建/修改策略必须执行）

1. 找到 `rebalance_time` 的值
2. 找到 `timing.factor_list` 中所有因子的时间参数（第5个元素）
3. 确认：**每个择时因子的时间 ≤ rebalance_time 的买入时间**
4. 如果 `rebalance_time='close-open'`，跳过此检查

## 修复方法

如果发现未来函数，将择时因子的时间参数调整为 ≤ rebalance_time：

```python
# 修复前（错误）
"rebalance_time": "0935-0935",
"factor_list": [("开盘至今涨幅", False, None, 1, "0950")]  # 0950 > 0935

# 修复后（正确）
"rebalance_time": "0935-0935",
"factor_list": [("开盘至今涨幅", False, None, 1, "0935")]  # 0935 == 0935 ✅
```

## 历史教训

- lee策略优化中此错误导致回测比值从真实1.93虚高到2.98（+54%虚假收益）
- 年化收益从真实39.48%虚高到52.34%（+13pp虚假收益）
- 这个错误非常隐蔽：回测照常运行，不会报错，只有数据异常好才可能被发现

## 参数搜索中的特殊注意

当搜索 `rebalance_time` 参数时，择时因子的时间应**动态匹配**：

```python
for params in dict_itertools(batch):
    rb_time = params["rebalance_time"].split("-")[0]  # 提取买卖时间
    timing_factor_list = [
        ("开盘至今涨幅", False, None, 1, rb_time),  # 动态匹配
        ("隔夜涨跌幅", False, None, 1, "0935"),      # 固定早盘数据，总是安全的
    ]
```
