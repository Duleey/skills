# Claude Code 配置包

更新时间: 2026-02-14

## 使用方法

1. 将此配置包复制到项目根目录：
   ```bash
   cp -r .claude /path/to/your/project/
   ```
2. 根据项目需要编辑 `.claude/settings.json` 中的工具权限
3. 创建项目专属的 `CLAUDE.md`（项目说明文件）

## 配置总览

| 类别 | 数量 | 说明 |
|------|------|------|
| Commands | 15 | 斜杠命令，包括因子研究、策略分析、参数优化等 |
| Rules | 19 | 编码规范、流程规则、量化专用规则 |
| Skills | 9 | 技能模块，包含 Python 开发、因子设计等 |

## 通用配置（适用于任何 Python 项目）

### Rules（编码规范）

- `rules/coding-style.md` — Python 编码风格规范
- `rules/framework-protection.md` — 框架保护规则（禁止修改核心代码）
- `rules/git-workflow.md` — Git 工作流规范
- `rules/hooks.md` — Python Hooks 配置
- `rules/patterns.md` — Python 设计模式
- `rules/performance.md` — 性能优化指南
- `rules/security.md` — 安全最佳实践
- `rules/testing.md` — 测试规范（pytest）
- `rules/long-running-commands.md` — 长时间命令执行规则
- `rules/smoke-test.md` — Smoke Test 预验证规则

### Commands（斜杠命令）

- `commands/checkpoint.md` — 保存检查点
- `commands/learn.md` — 提取可复用模式
- `commands/plan.md` — 实施计划（需用户确认）
- `commands/python-review.md` — Python 代码审查
- `commands/tdd.md` — 测试驱动开发
- `commands/update-docs.md` — 更新文档

### Skills（技能模块）

- `skills/coding-standards/` — 通用编码标准（Python/TS/JS）
- `skills/continuous-learning/` — 自动学习会话模式
- `skills/python-patterns/` — Python 惯用语和最佳实践
- `skills/python-testing/` — Python 测试策略（pytest/TDD）
- `skills/security-review/` — 安全审查技能
- `skills/strategic-compact/` — 上下文压缩建议
- `skills/tdd-workflow/` — TDD 工作流
- `skills/verification-loop/` — 验证循环模式

## 量化专用配置（适用于量化交易项目）

### Rules

- `rules/agents.md` — Agent 编排（量化策略研究体系）
- `rules/backtest-optimization.md` — 回测加速策略（三层分离原理）
- `rules/experiment-logging.md` — 实验记录与成果持久化
- `rules/factor-library.md` — 因子库使用规则
- `rules/future-function-prevention.md` — 未来函数防范
- `rules/param-search-optimization.md` — 参数搜索提速（粗→细两阶段）
- `rules/strategy-evaluation.md` — 策略评估指南
- `rules/strategy-config-reference.md` — 策略配置参考
- `rules/strategy-optimization-constraints.md` — 策略优化约束
- `rules/timing-strategy.md` — 择时策略选择指南

### Commands

- `commands/factor-research.md` — 因子研究与开发
- `commands/market-regime.md` — 市场状态分析
- `commands/portfolio-review.md` — 多策略组合评审
- `commands/quant-debug.md` — 量化问题诊断
- `commands/signal-design.md` — 择时信号设计
- `commands/strategy-analyze.md` — 策略深度分析
- `commands/strategy-optimize.md` — 策略优化执行
- `commands/strategy-deep-review.md` — 策略深度复盘

### Skills

- `skills/xbx-factors-modify/` — 邢不行量化因子设计规范

## 更新日志

### 2026-02-14
- 细化 `settings.json` 权限，提高安全性
- 为所有技能添加 `config.json` 配置
- 调整 `coding-standards` 技能描述
- 为 `backtest-optimization.md` 添加参数搜索耗时估算
- 为 `long-running-commands.md` 添加 nohup 后台执行完整示例
- 为 `experiment-logging.md` 添加实验记录完整模板

### 2026-02-10
- 初始版本导出
