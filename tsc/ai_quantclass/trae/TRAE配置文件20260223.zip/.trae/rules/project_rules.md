# 项目规则（TRAE）

## 项目目标

A 股量化回测/选股：编写因子/策略/信号/配置，运行回测产出结果。

## 强制约束（必须遵守）

1. 禁止未来函数（前视偏差）  
   - 规则： [future-function-prevention.md](./future-function-prevention.md)
2. 禁止修改框架主干（除非用户明确确认）  
   - 规则： [framework-protection.md](./framework-protection.md)
3. 长任务先冒烟测试（预计 >10 分钟必须先跑 1–3 分钟验证）  
   - 规则： [smoke-test.md](./smoke-test.md) / [long-running-commands.md](./long-running-commands.md)
4. 除法安全（防止除零异常）  
   - 规则： [safe-math.md](./safe-math.md)

## 质量基线（默认执行）

- Python：PEP 8 + 类型标注；工具 black/ruff： [coding-style.md](./coding-style.md)
- 测试：pytest： [testing.md](./testing.md)
- 密钥：仅环境变量： [security.md](./security.md)

## 命令白名单与限制

- 默认只使用以下几类命令，除非用户明确要求且经过风险说明：
  - Python 运行相关：`python *.py`、`python -m *`
  - 代码格式与静态检查：`black`、`ruff check`、`ruff format`
  - Git 操作：`git status/diff/log/add/commit/push/pull/branch/checkout`
  - 包管理：`pip install`（仅安装项目需要的依赖）、`pip list`
  - 文件查看与统计：`cat`、`ls`、`find`、`head`、`tail`、`wc`、`grep`
  - 目录/文件管理：`mkdir [-p]`、`cp [-r]`、`mv`
- 禁止执行具有破坏性或高风险的命令，例如：
  - `rm -rf`、`sudo`、系统级服务管理、磁盘/网络配置等
  - 任意不在上述白名单中的命令（除非用户明确同意）


## 任务模板（按需引用）

- plan： [plan.md](../commands/plan.md)
- quant-debug： [quant-debug.md](../commands/quant-debug.md)
- factor-research： [factor-research.md](../commands/factor-research.md)
- strategy-analyze / strategy-optimize： [strategy-analyze.md](../commands/strategy-analyze.md) / [strategy-optimize.md](../commands/strategy-optimize.md)

## 框架与数据规范（TRAE 内部）

- 框架技术规范：[`framework-technical-spec.md`](./framework-technical-spec.md)
- 底层数据结构规范：[`data-structure-spec.md`](./data-structure-spec.md)
