# A股量化投资框架技术规范（TRAE 版）

> 本文件完整迁移自项目根目录的 `A股量化投资框架技术规范.md`，作为 TRAE 内部的官方参考。

## 1. 项目定位 [TAG:ProjectScope]
**系统类型**：分步批处理（Step1-4）+ 向量化计算 + 多进程加速的 A 股选股/回测框架  
**核心目标**：实现「整理数据 → 计算因子 → 条件选股 → 模拟交易（资金曲线）」全流程自动化  
**项目特点（与代码一致）**：
- 入口支持“分步跑”：通过 `config.py` 的 `running_mode = [1,2,3,4]` 控制执行步骤（见 [回测主程序.py](../../回测主程序.py)）
- 因子通过“按名字动态加载”机制接入：`因子库/` 与 `截面因子库/`（见 [factor_hub.py](../../core/utils/factor_hub.py)）
- 策略通过“按名字动态加载”机制接入：`策略库/`（见 [strategy_hub.py](../../core/utils/strategy_hub.py)）
- 择时/临时调仓信号通过“按名字动态加载”机制接入：`信号库/`（见 [signal_hub.py](../../core/utils/signal_hub.py)）

---

## 2. 系统架构 [TAG:Architecture]

### 2.1 层级结构

```markdown
./
├── config.py                   # 主配置入口 [TAG:MainConfig]
├── config库/                   # 配置模板库（只读参考）
├── 回测主程序.py                # 统一入口（支持分步执行）
├── program/                    # 原子步骤脚本 [TAG:AtomicSteps]
│   ├── step1_整理数据.py
│   ├── step2_计算因子.py
│   ├── step3_选股.py
│   └── step4_实盘模拟.py
├── core/                       # 核心引擎（尽量不直接改）[TAG:CoreEngine]
│   ├── model/                  # 配置模型（解析/校验/序列化）
│   ├── utils/                  # 基础设施（日志、路径、注册/查找）
│   ├── backtest.py             # 标准全流程编排 [TAG:BackTest]
│   ├── data_center.py          # 数据准备与预处理 [TAG:DataCenter]
│   ├── select_stock.py         # 因子计算/选股/结果聚合 [TAG:SelectStock]
│   └── equity.py               # 模拟交易/资金曲线/绩效评估 [TAG:Equity]
├── 因子库/                     # 时序因子（按文件名映射）[TAG:FactorLib]
├── 截面因子库/                 # 截面因子（按文件名映射）[TAG:CrossSectionLib]
├── 信号库/                     # 择时与临时调仓信号（按文件名映射）[TAG:SignalLib]
├── 策略库/                     # 策略扩展点（可选）[TAG:StrategyLib]
├── tools/                      # 各类工具脚本（分析、报告收集等）[TAG:Tools]
└── data/                       # 默认输出与缓存根目录（也可在config里改）[TAG:DataOutput]
    ├── 回测结果/<backtest_name>/  # 回测结果存档
    ├── 运行缓存/<backtest_name>/  # 中间产物缓存（可清理/可复用）
    └── 实盘信息/                 # 模拟实盘状态/信号缓存
```

### 2.2 数据流定义 [TAG:DataFlow]

原始数据（数据中心路径 `data_center_path`） → 分步缓存（`data/运行缓存/`） → 结果存档（`data/回测结果/`）

```markdown
↓ [STEP 1] core/data_center.py::prepare_data(conf)
  - 逐股读取日线数据（GBK），合并指数、复权、涨跌停等字段
  - 生成并保存运行缓存：
    - 股票预处理数据.pkl
    - 全部股票行情pivot.pkl（含 open/close/preclose/dieting 以及需要的分钟字段）

↓ [STEP 2] core/select_stock.py::calculate_factors(conf)
  - 读取 STEP1 的“股票预处理数据”
  - 根据 conf.factor_params_dict 动态加载因子文件并计算（因子库/截面因子库）
  - 因子结果写入运行缓存（常见如 all_factors_kline.pkl、factor_*.pkl 等）

↓ [STEP 3] core/select_stock.py::select_stocks(conf)
  - 读取运行缓存里的因子面板数据
  - 前置过滤 → 复合因子计算 →（可选）择时/临时调仓信号 → 选股 → 后置过滤
  - 输出单策略选股结果：data/回测结果/<backtest_name>/选股结果#x.xxx.pkl
  - 聚合输出：data/回测结果/<backtest_name>/选股结果.csv / 最新选股结果.csv 等

↓ [STEP 4] core/equity.py::simulate_performance(conf)
  - 读取选股结果与行情pivot
  - 在 stay_real 约束下模拟交易并产出资金曲线/绩效指标/可视化
```

---

## 3. 配置契约（Config Schema） [TAG:ConfigSchema]

### 3.1 全局配置（config.py 顶层变量）

| 配置项 | 类型 | 必填 | 示例/默认 | 说明 | 约束/备注 |
|---|---|---:|---|---|---|
| `backtest_name` | str | 是 | `"初创优选选股策略"` | 回测实例标识 | 决定输出文件夹名 |
| `start_date` | str | 是 | `"2016-01-01"` | 回测起始日 | `YYYY-MM-DD` |
| `end_date` | str \| None | 否 | `None` | 回测结束日 | `None` 表示用到最新数据 |
| `data_center_path` | str \| Path | 是 | `"/path/to/stock_data"` | 数据中心根路径 | 不存在会直接退出 |
| `runtime_data_path` | Path | 否 | `get_folder_path("data")` | 输出根目录 | 默认就是项目下 `data/` |
| `running_mode` | list[int] \| int | 否 | `[1,2,3,4]` | 分步执行控制 | 1-4 对应 STEP1-4 |
| `stay_real` | bool | 否 | `True` | 更贴近真实交易的约束 | 停牌/涨跌停/ST/退市等处理会更严格 |
| `performance_mode` | str | 否 | `"BAL"` | 性能档位 | `"ECO" \| "BAL" \| "MAX"`，会影响 `n_jobs` 与 `factor_col_limit` |
| `excluded_boards` | list[str] | 否 | `["cyb","kcb","bj"]` | 板块过滤 | 统一作用于所有策略 |
| `days_listed` | int | 否 | `250` | 上市至今交易天数门槛 | 用于通用后置过滤 |
| `total_cap_usage` | float | 否 | `1.0` | 整体资金使用率 | 0.5 表示只用一半资金模拟 |
| `initial_cash` | float | 否 | `100_0000` | 初始资金 | |
| `c_rate` / `t_rate` | float | 否 | `1.2/10000` / `1/1000` | 手续费/印花税 | |
| `strategy_list` | list[dict] | 是 | `[...]` | 策略配置列表 | 见 3.2 |

### 3.2 策略配置 Schema（strategy_list 元素）

每个策略字典的常见字段如下（以实际代码为准，允许部分字段缺省）：

```python
{
    "name": str,                    # 策略名（会被编号成 "#0.xxx" 参与输出文件名）
    "hold_period": str,             # 持仓周期："5D" / "W" / "M" 等
    "offset_list": list[int],       # 分批进场组，如 [0,1,2,3,4]
    "select_num": int | float,      # 选股数量；0.x 表示选取前 x% 股票
    "cap_weight": float,            # 多策略组合资金权重（会做归一化）
    "rebalance_time": str,          # "close-open" / "open" / "close" / "0955-0955" 等
    "factor_list": list[tuple],     # 选股因子（见 3.3）
    "filter_list": list[tuple],     # 前置过滤（见 3.4）
    "filter_list_post": list[tuple],# 后置过滤（同 3.4）
    "cross_sections": list[dict],   # 截面因子（见 3.5，可选）
    "timing": dict | None,          # 择时信号配置（见 3.6，可选）
    "override": dict | None,        # 临时调仓信号配置（见 3.6，可选）
    "scalein_targets": list[float]  # 分批进场目标仓位（可选，缺省会按 offset 自动生成）
}
```

### 3.3 因子配置格式 [TAG:FactorConfig]

`factor_list` 中每个元组格式：

```python
(name: str, is_sort_asc: bool, param, args, minutes)
```

- `name`：对应 `因子库/{name}.py`（或 `截面因子库/{name}.py`）的文件名（不含 `.py`）
- `is_sort_asc`：True 表示从小到大排序；False 表示从大到小
- `param`：因子参数，支持 `None / str / int / float / bool / tuple / list / dict`
  - list 会被自动转成 tuple；dict 会被转成可哈希结构（用于缓存与列名拼接）
- `args`：
  - 默认模式：表示“权重”，会在策略内做归一化后参与复合因子计算
  - 自定义策略模式（策略文件实现了 `calc_select_factor` 时）：`args` 不做归一化，可当作自定义函数的额外参数
- `minutes`（可选，第 5 个元素）：分钟级别因子取值点，如 `"0945"` 或 `("0945","0930")`

示例（来自 `config.py` / `策略库`）：
```python
("市值", True, "", 1)
("相对指数超额收益", True, [20, "sh932000"], 1)
("开盘至今涨幅", False, None, 60, "0945")
```

### 3.4 过滤条件格式 [TAG:FilterConfig]

`filter_list` / `filter_list_post` 中每个元组格式：

``` python
(name: str, param, method?: str, is_sort_asc?: bool)
```

- `method`（可选）：形如 `"<how>:<range>"`，其中：
  - `how` ∈ `rank`（名次）/ `pct`（百分位）/ `val`（数值本身）
  - `range` 支持 `> >= < <= == !=`，例如：`"val:<1"`、`"pct:<=0.05"`、`"rank:<=100"`
- `is_sort_asc`（可选）：当 `how` 是 `rank/pct` 时，决定排序方向（缺省 True）

示例（来自 `config.py`）：
```python
("企业生命周期", ["初创"], "val:==1")
("一级风险标签", 20, "val:<1")
("国九条因子", ["All","默认"], "val:!=1")
```

### 3.5 截面因子配置（cross_sections）[TAG:CrossSectionConfig]

`cross_sections` 为 `list[dict]`，核心字段：
```python
{
  "name": str,                 # 截面因子名（对应 截面因子库/{name}.py）
  "is_sort_asc": bool,
  "factor_list": list[tuple],  # 该截面因子依赖的“时序因子列表”（格式同 3.3，但 args 作为参数不做权重归一化）
  "params": any,               # 可选：截面因子参数
  "args": float|int,           # 可选：截面因子权重（会归一化）
  "minutes": str|list[str],    # 可选：分钟点
  "method": "rank:..."|"pct:..."|"val:...",  # 可选：截面过滤方法
  "alias_name": str            # 可选：列名过长时的别名后缀
}
```

### 3.6 择时/临时调仓信号配置（timing / override）[TAG:SignalConfig]

两者格式类似（区别：timing 要求信号库实现 `signal`；override 要求实现 `signal_override`）：
```python
{
  "name": str,                # 信号名（对应 信号库/{name}.py）
  "limit": float|int,         # 参与信号计算的股票范围：<1 表示百分位；>=1 表示前 N 名；<=0 表示全市场
  "factor_list": list[tuple], # 信号所需的因子列表（支持分钟点）
  "params": any               # 信号参数（自由定义，信号文件里自己解析）
}
```

------

## 4. 核心模块接口定义 [TAG:ModuleAPI]

### 4.1 data_center.py [TAG:DataCenterAPI]

**职责**：读取数据中心的日线/分钟/外部数据，做复权、涨跌停、与指数合并，并缓存“运行缓存”。

**关键函数**：

``` python
def prepare_data(conf: BacktestConfig, boost: bool = True):
    """STEP1：逐股读取与预处理，保存运行缓存。"""

def prepare_data_by_stock(conf: BacktestConfig, stock_file_path: str|Path, index_data: pd.DataFrame) -> pd.DataFrame:
    """单只股票的预处理：复权、涨跌停、合并指数、生成下日状态等。"""
```

### 4.2 select_stock.py [TAG:SelectStockAPI]

**职责**：因子计算（STEP2）、截面因子计算、选股（STEP3）与结果聚合。

**关键约束**：

- 因子文件计算不得改变行数（框架会做长度校验）
- 分步运行依赖缓存：STEP2/3 会读取 STEP1 的缓存文件
- 分钟级因子/换仓点会触发额外分钟数据加载（5m/15m）

```python
def calculate_factors(conf: BacktestConfig, boost: bool = True):
    """STEP2：按 conf.factor_params_dict 动态加载因子并计算。"""

def calc_cross_sections(conf: BacktestConfig):
    """截面因子计算（依赖已计算好的时序因子列）。"""

def select_stocks(confs: BacktestConfig | list[BacktestConfig], boost=True):
    """STEP3：前置过滤 → 复合因子计算 → 择时/临时调仓 → 选股 → 后置过滤。"""

def concat_select_results(conf: BacktestConfig) -> pd.DataFrame:
    """聚合所有子策略选股结果，输出综合选股结果与最新选股结果。"""
```

### 4.3 equity.py [TAG:EquityAPI]

**职责**：根据选股结果模拟交易，计算资金曲线

**输入**：STEP3 生成的选股结果（pkl/csv）与 STEP1 的行情 pivot 缓存

**输出**：

- `资金曲线.csv`：每日总资产、持仓、现金、收益率
- `策略评价.csv`：年化收益、夏普比率、最大回撤、Calmar比率等

**交易约束**（当`stay_real=True`时生效）：

- 涨停：无法买入（开盘价=涨停价时跳过）
- 跌停：无法卖出（开盘价=跌停价时跳过）
- 停牌：保持上一期持仓，不参与调仓

------

## 5. 因子与信号注册机制 [TAG:Registration]

### 5.1 自动发现规则

- **时序因子**：`因子库/{factor_name}.py` 必须提供 `add_factor(df, param=None, **kwargs) -> pd.DataFrame`
- **截面因子**：`截面因子库/{factor_name}.py` 同样按 `add_factor` 接口接入（框架会标记 `is_cross=True`）
- **择时信号**：`信号库/{signal_name}.py` 必须提供 `signal(strategy, df_after_limit) -> pd.DataFrame`，返回列名为 `择时信号`
- **临时调仓信号**：`信号库/{signal_name}.py` 必须提供 `signal_override(strategy, df_after_limit) -> pd.DataFrame`，返回列名通常为 `目标仓位`
- **策略扩展（可选）**：`策略库/{strategy_name}.py` 可提供 `calc_select_factor(period_df, strategy)` 与/或 `filter_stock(period_df, strategy)`

### 5.2 开发规范

**新增因子步骤**：

1. 在`因子库/`新建 `{factor_name}.py`
2. 实现 `add_factor(df, param=None, **kwargs)`，必须读取 `kwargs["col_name"]` 并把结果写进 `df[col_name]`
3. 返回 `df[[col_name]]`（保持与输入行数一致）
4. 在 `config.py` 的 `factor_list` / `filter_list` / `cross_sections` / `timing.factor_list` 中引用该因子名

**关键禁止事项**：

- 禁止在因子计算中使用 `.shift(-n)`（未来函数）
- 禁止在因子计算里改变 DataFrame 行数（会触发长度校验报错）
- 禁止在`core/`目录下写策略逻辑（只能写基础设施）

------

## 6. 数据对齐与交易规则 [TAG:DataAlign]

### 6.1 时间对齐标准

- **主键字段**：本项目核心 DataFrame 以列 `交易日期`、`股票代码` 作为主键（不是 MultiIndex）
- **交易日与周期偏移**：数据中心根目录下的 `period_offset.csv` 会在启动时检查/下载，并用于周期偏移（BacktestConfig 初始化时处理）
- **换仓时间**：
  - `"close-open"`：隔日换仓（默认）
  - `"open"` / `"close"`：日内换仓（早盘/尾盘）
  - `"0955-0955"`：自定义分钟点换仓（会触发分钟数据准备）

### 6.2 复权与价格处理

- **默认规则**：STEP1 中会计算并使用 **后复权** 价格（见 `cal_fuquan_price(..., fuquan_type="后复权")`）
- **成交量**：使用原始成交量（不复权）
- **涨跌停标识**：在 STEP1 预处理阶段计算并写入相关字段（并生成下日状态列）

### 6.3 幸存者偏差处理 [TAG:SurvivorshipBias]

- 本框架读取“数据中心里的逐股历史文件”，是否包含退市股取决于你提供的数据中心内容
- 框架层面会生成 `下日_是否退市` 等字段并在后置过滤中使用（见 `StrategyConfig.filter_after_condition`）

------

## 7. 输出规范 [TAG:OutputSpec]

### 7.1 目录结构（以backtest_name="TestStrategy"为例）

``` markdown
data/回测结果/TestStrategy/
├── config.json              # 配置序列化（JSON格式）
├── config.pkl               # 配置对象（Python pickle）
├── config.py                # 配置代码快照（可复制复现）
├── 资金曲线.csv              # 日度资金曲线（具体列以实际输出为准）
├── 资金曲线.html             # 可视化图表（Bokeh/Plotly生成）
├── 策略评价.csv              # 绩效指标汇总（单行）
├── 选股结果.csv              # 全部历史选股记录
├── 最新选股结果.csv          # 最后一期选股（用于模拟实盘）
├── 选股结果#0.xxx.pkl         # 子策略明细（pickle）
├── 择时信号#0.xxx.csv          # 子策略择时信号（csv + 可选pkl）
└── ...（其他中间文件）
```

### 7.2 资金曲线 CSV Schema

资金曲线的列字段以 `core/equity.py` 实际输出为准；该文件会同时输出 csv/html，并配套生成 `策略评价.csv` 作为指标汇总。

------

## 8. 调试与开发模式 [TAG:DebugMode]

### 8.1 分步调试

通过修改`config.py`中的`running_mode`实现快速迭代：

- **数据问题**：`running_mode = [1]` → 检查`data/运行缓存/`中的清洗后数据
- **因子问题**：`running_mode = [1,2]` → 检查因子值分布和截面相关性
- **选股问题**：`running_mode = [1,2,3]` → 检查选股结果是否符合预期
- **绩效问题**：`running_mode = [4]` → 基于已有选股结果快速调整手续费/滑点

### 8.2 性能优化

- `performance_mode = "ECO"|"BAL"|"MAX"`：影响 `n_jobs` 与 `factor_col_limit`（见 [config.py](../../config.py)）
- **缓存机制**：STEP1-3 的结果会落盘缓存，便于只重跑某一步
- **内存管理**：因子计算按列分片（`factor_col_limit`）避免一次性生成过多列

------

## 9. 平台兼容性说明 [TAG:Compatibility]

- **音频提示**：`回测主程序.py`末尾使用 `afplay`（macOS）。在非 macOS 下通常只会命令失败但不影响主流程。
- **中文编码**：
  - 数据中心输入：股票/周期偏移等多处读取使用 `encoding="gbk"`
  - 结果输出：常用 `utf-8-sig` 便于 Excel 打开（见 `save_csv_safely`）

------

## 10. 代码范式（因子 / 策略 / config）[TAG:CodePatterns]

本节给出“能直接照着写”的最小范式，用于以后让 TRAE 自动生成/修改文件时不跑偏。

### 10.1 因子文件范式（`因子库/{因子名}.py`）[TAG:FactorPattern]

要点：
- 文件名就是因子名，配置里写的字符串必须与文件名一致（不含 `.py`）
- 必须实现 `add_factor`
- 必须使用 `kwargs["col_name"]` 作为输出列名
- 必须保证返回结果行数不变

```python
import pandas as pd

fin_cols = []     # 可选：声明需要的财务字段，框架会自动加载并合并
ov_cols = []      # 可选：声明需要的全息字段（会在STEP1读取时额外加载）
extra_data = {}   # 可选：声明需要的外部数据源（由 data_bridge / ext_data 提供）

def add_factor(df: pd.DataFrame, param=None, **kwargs) -> pd.DataFrame:
    col_name = kwargs["col_name"]
    # 1) 解析 param（你自己定义含义）
    # 2) 使用 df 现有列计算
    # 3) 写入 df[col_name]
    df[col_name] = df["收盘价"]  # 示例：请替换为你的逻辑
    return df[[col_name]]
```

### 10.2 策略文件范式（`策略库/{策略名}.py`）[TAG:StrategyPattern]

要点：
- 策略文件是“可选扩展点”。如果不写策略文件，框架会使用默认的“因子加权排名”逻辑
- 如果写了策略文件，常用两类函数：
  - `filter_stock(period_df, strategy)`：自定义前置过滤
  - `calc_select_factor(period_df, strategy)`：自定义复合因子计算（覆盖默认加权算法）

```python
import pandas as pd
from core.model.strategy_config import StrategyConfig

def filter_stock(period_df: pd.DataFrame, strategy: StrategyConfig) -> pd.DataFrame:
    # period_df 包含：K线字段 + 你配置的因子列 + 若干下日状态字段
    # 返回过滤后的 DataFrame（不建议改列名）
    return period_df

def calc_select_factor(period_df: pd.DataFrame, strategy: StrategyConfig) -> pd.DataFrame:
    # 自己决定复合因子列名：strategy.factor_name（默认是 "复合因子"）
    # 示例：用第一个因子做排名当作复合因子
    first_factor = strategy.factor_list[0].col_name
    period_df[strategy.factor_name] = period_df.groupby("交易日期")[first_factor].rank(
        ascending=strategy.factor_list[0].is_sort_asc, method="min"
    )
    return period_df
```

### 10.3 config.py 范式（最常改的部分）[TAG:ConfigPattern]

```python
start_date = "2016-01-01"
end_date = None
performance_mode = "BAL"   # "ECO" | "BAL" | "MAX"
running_mode = [1, 2, 3, 4]

backtest_name = "小市值选股策略"

strategy_list = [
    {
        "name": "小市值100",
        "hold_period": "W",
        "offset_list": [0, 1, 2, 3, 4],
        "select_num": 100,
        "cap_weight": 1,
        "rebalance_time":
            "open",
        "factor_list": [
            ("市值", True, "", 1),
        ],
        "filter_list": [
            # ("月份", [1], "val:!=1"),
        ],
        "timing": {
            "name": "定风波2择时带离场",
            "limit": 0.8,
            "factor_list": [
                ("开盘至今涨幅", False, None, 60, "0945"),
                ("隔夜涨跌幅", False, None, 60, "0930"),
            ],
            "params": (0.8, 1.1),
        },
    }
]
```

------

## 11. 数据分析工具扩展规范 [TAG:AnalysisTools]

目标：以后新增“数据分析工具”时，尽量不碰 `core/` 主流程，只在 `tools/` 下新增脚本，把回测产物当作输入，输出新的分析结果。

### 11.1 推荐放置位置与输入约定

- 推荐目录：`tools/自建tools/` 下，每个工具一个 `.py` 文件
- 工具输入优先从两处读取：
  - `data/回测结果/<backtest_name>/`：最终结果（资金曲线、策略评价、选股结果等）
  - `data/运行缓存/<backtest_name>/`：中间产物（因子面板、分钟pivot、临时信号等）
- 工具输出建议写入：
  - `data/分析结果/`（已存在）或 `data/回测结果/<backtest_name>/分析/`

### 11.2 工具脚本最小范式

```python
from pathlib import Path
import pandas as pd

def main():
    root = Path(__file__).resolve().parents[1]   # 指向项目根目录
    data_root = root / "data"
    result_root = data_root / "回测结果"

    # 例：扫描所有回测结果，汇总策略评价
    rows = []
    for folder in result_root.iterdir():
        if not folder.is_dir():
            continue
        report_path = folder / "策略评价.csv"
        if report_path.exists():
            df = pd.read_csv(report_path, encoding="utf-8-sig")
            df.insert(0, "backtest_name", folder.name)
            rows.append(df)

    out = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    out_dir = data_root / "分析结果"
    out_dir.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_dir / "策略评价汇总.csv", encoding="utf-8-sig", index=False)

if __name__ == "__main__":
    main()
```

### 11.3 设计原则（让工具可持续增长）

- 工具脚本不要修改 `core/` 的行为；需要改流程时，优先改 `config.py` 或新增 `策略库/因子库/信号库` 扩展
- 工具读取/写入尽量用 `utf-8-sig`，减少 Excel 打开乱码的概率
- 工具尽量做到“只读输入、纯新增输出”，避免污染回测缓存
