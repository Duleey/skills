---
name: xbx-factors-modify
description: 邢不行量化因子设计规范 - 用于在邢不行选股框架下创建和修改因子文件。当用户要求创建新因子、修改现有因子、调试因子代码或审查因子文件时触发。
---

# 邢不行量化因子设计规范

本 skill 用于指导在邢不行选股框架（select-stock-pro）下进行因子设计和修改，确保因子文件符合项目架构规范。

## 📁 因子库位置

- **主因子库**：`因子库/` — 当前使用的因子文件目录
- **扩展因子库**：`因子库(600+因子)/` — 更大的因子集合
 - **截面因子库**：`截面因子库/` — 截面因子
 - **因子模板**：`.trae/skills/xbx-factors-modify/factor_template.py` — 创建新因子的起点

## 📋 因子文件标准结构

每个因子文件必须包含以下核心部分，按顺序排列：

### 1. 文件头部（版权声明和导入）

```python
"""
邢不行｜策略分享会
股票量化策略框架𝓟𝓻𝓸

版权所有 ©️ 邢不行
微信: xbx1717

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import pandas as pd
import numpy as np  # 仅在需要时导入
```

**规范要点**：
- 必须保留完整的版权声明
- 使用三引号文档字符串格式
- 仅导入必要的库（`pandas` 必需，`numpy` 按需）

### 2. FA_INTRO 元数据字典（推荐）

```python
FA_INTRO = {
    '相关直播': [],
    '相关帖子': [],
    '因子说明': ''' 
     [因子名称]：[因子的详细技术说明]
     因子值越大：[含义解释]
     因子值越小：[含义解释]
    ''',
    '选股因子案例': ('[因子名]', True/False, [参数], 1),
    '过滤因子案例': ('[因子名]', [参数], 'val:>0', True),
}
```

**规范要点**：
- 新建因子推荐包含 FA_INTRO（旧因子可能没有，属正常情况）
- `相关直播` 和 `相关帖子`：保持为空列表 `[]`
- `因子说明`：必须包含三行：因子名称+计算逻辑、因子值越大含义、因子值越小含义
- `选股因子案例`：`(因子名, 排序方向True/False, 参数, 权重)`
- `过滤因子案例`：`(因子名, 参数, 条件表达式, 排序方向)`

### 3. fin_cols 财务因子列表

```python
fin_cols = []  # 财务因子列，配置后系统会自动加载对应的财务数据
```

**规范要点**：
- 不涉及财务数据时保持空列表
- 需要财务数据时添加字段名称，必须带 `@xbx` 后缀
- 示例：`fin_cols = ['R_revenue@xbx', 'R_np@xbx']`
- 字段前缀含义：`B_`=资产负债表，`R_`=利润表，`C_`=现金流量表

### 4. add_factor 核心计算函数

```python
def add_factor(df: pd.DataFrame, param=None, **kwargs) -> pd.DataFrame:
    """
    计算并将新的因子列添加到股票行情数据中。

    :param df: 包含单只股票的K线数据 DataFrame
    :param param: 因子计算参数
    :param kwargs: col_name(因子列名), fin_data(财务数据字典) 等
    :return: 包含单列因子值的 DataFrame，索引与输入 df 一致
    """
    col_name = kwargs['col_name']
    n = int(param) if param else 20

    # ========== 原始计算逻辑开始 ==========
    # [核心因子计算逻辑]
    # ========== 原始计算逻辑结束 ==========

    # 返回因子结果（两种等效写法）
    # 写法1（简洁，推荐简单因子使用）：
    df[col_name] = ...
    return df[[col_name]]

    # 写法2（显式创建 DataFrame，推荐复杂因子使用）：
    factor_df = pd.DataFrame({col_name: factor_col}, index=df.index)
    return factor_df
```

## 🔧 函数实现规范

### 参数处理
- **col_name**：必须从 `kwargs['col_name']` 获取，这是框架自动分配的因子列名
- **param**：根据需要进行类型转换（如 `int(param)`、`float(param)`）
- **参数默认值**：`n = int(param) if param else 20`
- **财务数据**：通过 `kwargs.get('fin_data', {})` 获取

### 数据列命名规范
- 使用 `df['收盘价_复权']` 作为价格数据（**因子计算最常用**）
- 临时计算列使用小写英文：`df['ma']`, `df['ema_short']`
- 最终因子列使用格式：`df[f'{因子名}_{参数}']` 或直接用 `df[col_name]`

### 返回值规范
- 必须返回包含**单列**的 DataFrame
- 列名使用 `col_name`（框架分配）
- 索引必须与输入 `df` 一致

### 中间列清理
- 使用 `del df['列名']` 删除临时计算列
- 确保不污染原始 df（除非直接用 `return df[[col_name]]`）

## 📊 可用数据字段

### 股票日线全息数据（df 主数据）

**基础行情**：
- `股票代码`, `股票名称`, `交易日期`
- `开盘价`, `最高价`, `最低价`, `收盘价`（未复权）
- `收盘价_复权`（后复权，**因子计算首选**）
- `前收盘价`, `成交量`, `成交额`, `涨跌幅`

**市值**：
- `流通市值`, `总市值`

**TTM财务指标**：
- `净利润TTM`, `现金流TTM`, `净资产`, `总资产`, `总负债`, `净利润(当季)`

**资金流向**（单位万元）：
- `散户资金买入额/卖出额`（5万以下）
- `中户资金买入额/卖出额`（5万~20万）
- `大户资金买入额/卖出额`（20万~100万）
- `机构资金买入额/卖出额`（≥100万）

**指数成分股标记**（"Y"或空）：
- `沪深300成分股`, `上证50成分股`, `中证500成分股`, `中证1000成分股`, `中证2000成分股`, `创业板指成分股`

**行业分类**：
- `新版申万一级行业名称`, `新版申万二级行业名称`, `新版申万三级行业名称`

**分钟级数据**：
- `09:35收盘价`, `09:45收盘价`, `09:55收盘价` 等

### 财务数据（通过 fin_cols 声明后从 kwargs['fin_data'] 获取）

**资产负债表**（`B_` 前缀）：
- `B_currency_fund@xbx`(货币资金), `B_account_receivable@xbx`(应收账款)
- `B_inventory@xbx`(存货), `B_fixed_asset@xbx`(固定资产)
- `B_goodwill@xbx`(商誉), `B_total_assets@xbx`(资产总计)
- `B_total_liab@xbx`(负债合计), `B_total_owner_equity@xbx`(所有者权益)
- `B_undstrbtd_profit@xbx`(未分配利润)

**利润表**（`R_` 前缀）：
- `R_revenue@xbx`(营业收入), `R_operating_cost@xbx`(营业成本)
- `R_sales_fee@xbx`(销售费用), `R_manage_fee@xbx`(管理费用)
- `R_rad_cost_sum@xbx`(研发费用), `R_financing_expenses@xbx`(财务费用)
- `R_op@xbx`(营业利润), `R_np@xbx`(净利润)
- `R_np_atoopc@xbx`(归母净利润), `R_basic_eps@xbx`(基本每股收益)

**现金流量表**（`C_` 前缀）：
- `C_ncf_from_oa@xbx`(经营活动现金流净额)
- `C_ncf_from_ia@xbx`(投资活动现金流净额)
- `C_ncf_from_fa@xbx`(筹资活动现金流净额)

### 筹码分布数据
- `5分位成本` ~ `95分位成本`（每5%一个分位）
- `加权平均成本`, `胜率`, `后复权价格`, `历史最低价`, `历史最高价`

## 📊 常用计算模式

### 模式 1：移动平均类
```python
df['ma'] = df['收盘价_复权'].rolling(n).mean()
df[col_name] = (df['收盘价_复权'] - df['ma']) / df['ma']
del df['ma']
return df[[col_name]]
```

### 模式 2：指数移动平均类
```python
df['ema'] = df['收盘价_复权'].ewm(span=n, adjust=False).mean()
df[col_name] = df['ema'] / df['收盘价_复权']
del df['ema']
return df[[col_name]]
```

### 模式 3：波动率类
```python
factor_col = df['涨跌幅'].rolling(n).std()
return pd.DataFrame({col_name: factor_col}, index=df.index)
```

### 模式 4：动量/RSI 类
```python
diff = df['收盘价_复权'].diff()
df['up'] = np.where(diff > 0, diff, 0)
df['down'] = np.where(diff < 0, abs(diff), 0)
df[col_name] = df['up'].rolling(n).sum() / (df['down'].rolling(n).sum() + 1e-8)
del df['up'], df['down']
return df[[col_name]]
```

### 模式 5：资金流类
```python
df['主力买入'] = df['大户资金买入额'] + df['机构资金买入额']
df['主力卖出'] = df['大户资金卖出额'] + df['机构资金卖出额']
df[col_name] = (df['主力买入'] - df['主力卖出']).rolling(n).sum()
del df['主力买入'], df['主力卖出']
return df[[col_name]]
```

### 模式 6：财务数据类
```python
fin_cols = ['R_revenue@xbx', 'R_np@xbx']

def add_factor(df, param=None, **kwargs):
    col_name = kwargs['col_name']
    fin_data = kwargs.get('fin_data', {})
    if '财务数据' in fin_data:
        fin_df = fin_data['财务数据']
        # 使用 fin_df['R_revenue@xbx'] 等字段计算
    return df[[col_name]]
```

## ⚠️ 重要注意事项

### 1. 避免除零错误
```python
result = numerator / (denominator + 1e-8)
```

### 2. NaN 值处理
- `rolling()` 可设置 `min_periods`：`df['ma'] = df['收盘价_复权'].rolling(n, min_periods=1).mean()`

### 3. 价格数据选择
- ✅ 推荐：`df['收盘价_复权']` — 避免分红/配股影响
- ⚠️ 谨慎：`df['收盘价']` — 仅特殊需求使用未复权价

### 4. 字段存在性检查
- 可选字段使用前先检查：`if '字段名' in df.columns:`

### 5. 因子列名（col_name）生成规则
框架通过 `get_col_name()` 自动生成因子列名：
- 无参数：`因子名` → `市值`
- 有参数：`因子名_param` → `成交额Mean_5`
- 列表参数：`因子名_(p1,p2)` → `指数相关性_(sh000300,20)`
- 带分钟（5元素）：`因子名_param_minute` → `分钟价格5m_10000_1450`
- 无参数带分钟：`因子名_minute` → `分钟价格5m_1450`

## ✅ 因子创建检查清单

- [ ] 包含完整的版权声明头部
- [ ] 导入了必要的库（pandas 必需）
- [ ] FA_INTRO 字典完整（新因子推荐）
- [ ] fin_cols 列表已声明（即使为空）
- [ ] `add_factor` 函数签名：`(df: pd.DataFrame, param=None, **kwargs)`
- [ ] 从 `kwargs['col_name']` 获取列名
- [ ] 参数 `param` 正确转换和使用
- [ ] 价格计算使用 `收盘价_复权`
- [ ] 除法分母有防零保护（`+ 1e-8`）
- [ ] 临时列已清理
- [ ] 返回值是包含单列的 DataFrame，索引与 df 一致

## 🎯 使用指南

 创建新因子时：
 1. 复制 `.trae/skills/xbx-factors-modify/factor_template.py` 到 `因子库/` 目录
2. 重命名文件为因子名称（如 `自定义动量.py`）
3. 填写 FA_INTRO 元数据
4. 在 `add_factor` 中实现计算逻辑
5. 过检查清单确认规范
6. 在 config 的 `factor_list` 或 `filter_list` 中引用该因子

## 📖 factor_list 与 filter_list 中的因子引用

### factor_list（选股因子）— 4元素或5元素
```python
# 4元素：(因子名, 排序方向, 参数, 权重/args)
("市值", True, None, 1)            # 市值从小到大
("指数相关性", False, ["sh000300", 20], 1)  # 与沪深300的20日相关性，从大到小

# 5元素：(因子名, 排序方向, 参数, 权重/args, 分钟时间)
("开盘至今涨幅", False, None, 1, "0945")  # 09:45时的涨幅
```

### filter_list（过滤因子）— 2~4元素
```python
# (因子名, 参数, 过滤规则, 排序方向)
('成交额Mean', 5, 'val:>=5000_0000', True)   # 保留5日均额>=5000万
('月份', [1, 4], 'val:!=1')                   # 排除1月和4月
('Ret', 20, 'pct:<=0.9', True)               # 保留涨幅排名前90%
('股票前缀过滤', ['bj', 'kcb'], 'val:!=1')    # 排除北交所和科创板

# 过滤方式：rank(排名), pct(排名百分比), val(数值)
# 比较运算符：>=, <=, ==, !=, >, <
# 注意：过滤选择的是保留的对象，不是被排除的对象
```

---

**版本**: 1.0
**创建日期**: 2026-02-08
**维护者**: select-stock-pro
