# Best Practices and Troubleshooting

## Element Targeting

### Refs Fail to Locate

When `snapshot` refs (e.g., `e15`) fail to locate an element:

1. **Take a fresh snapshot**: The page may have changed since the last snapshot.
   ```bash
   playwright-cli snapshot
   playwright-cli click e15
   ```

2. **Use CSS selectors as fallback**:
   ```bash
   playwright-cli click "#submit-button"
   playwright-cli click ".btn-primary"
   ```

3. **Use Playwright locators for robustness**:
   ```bash
   playwright-cli click "getByRole('button', { name: 'Submit' })"
   playwright-cli click "getByTestId('login-btn')"
   ```

4. **Inspect element attributes** to find stable identifiers:
   ```bash
   playwright-cli eval "el => el.id" e7
   playwright-cli eval "el => el.getAttribute('data-testid')" e7
   ```

See [element-attributes.md](element-attributes.md) for detailed inspection techniques.

### Avoid Race Conditions

- **After navigation**, always take a snapshot before interacting:
  ```bash
  playwright-cli goto https://example.com
  playwright-cli snapshot
  playwright-cli click e5
  ```

- **After click triggers navigation**, wait for the page to stabilize:
  ```bash
  playwright-cli click e3
  playwright-cli snapshot  # Ensures page is ready
  playwright-cli fill e5 "text"
  ```

- **For dynamic content**, use `eval` to check readiness:
  ```bash
  playwright-cli eval "() => document.querySelector('.loading') === null"
  ```

## Headed vs Headless

### When to Use `--headed`

| Scenario | Recommendation |
|----------|----------------|
| Debugging element visibility | Use `--headed` to see what's happening |
| Visual verification | Use `--headed` to observe behavior |
| CI/CD automation | Stay headless (default) for speed |
| Screenshots/video recording | `--headed` is often clearer |

```bash
# Debug mode - visible browser
playwright-cli open https://example.com --headed
playwright-cli snapshot
playwright-cli click e5
```

## Performance

### Reduce Token Usage

- Use `--raw` when piping output to other tools:
  ```bash
  playwright-cli --raw eval "document.title" | cat
  ```

- Use `--raw` when only the result matters:
  ```bash
  HREF=$(playwright-cli --raw eval "document.querySelector('a').href")
  ```

### Snapshot Depth Control

For large pages, limit snapshot depth to improve performance:
```bash
playwright-cli snapshot --depth=4
```

### Clean Up Resources

Always close browsers when done to free resources:
```bash
playwright-cli close
# Or close all sessions
playwright-cli close-all
```

## Security

- **Never commit state files** containing auth tokens to version control
- **Use in-memory sessions** (default) for sensitive operations
- **Delete persistent data** after use:
  ```bash
  playwright-cli -s=auth delete-data
  ```

## Common Errors

### "Browser not found"
Install browsers first:
```bash
npx playwright install
```

### "Element not found" after click
The page may have navigated. Take a fresh snapshot:
```bash
playwright-cli click e3
playwright-cli snapshot  # Refresh refs after navigation
```

### "Connection refused"
The browser daemon may have crashed. Kill and restart:
```bash
playwright-cli kill-all
playwright-cli open https://example.com
```

## Session Naming

Use semantic names for sessions to avoid confusion:
```bash
# Good
playwright-cli -s=github-auth open https://github.com
playwright-cli -s=docs-scrape open https://docs.example.com

# Avoid
playwright-cli -s=s1 open https://github.com
```
