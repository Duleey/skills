# Command Reference

Complete reference for all `playwright-cli` commands, organized by category.

## Core

| Command | Description |
|---------|-------------|
| `open [url]` | Open browser and optionally navigate to URL |
| `goto <url>` | Navigate to URL |
| `click <ref>` | Click element by ref |
| `dblclick <ref>` | Double-click element |
| `fill <ref> <text>` | Fill text into input |
| `type <text>` | Type text into focused element |
| `select <ref> <value>` | Select option from dropdown |
| `check <ref>` | Check checkbox/radio |
| `uncheck <ref>` | Uncheck checkbox |
| `hover <ref>` | Hover over element |
| `drag <start> <end>` | Drag element to another element |
| `upload <file>` | Upload file |
| `snapshot` | Capture page accessibility snapshot |
| `screenshot [ref]` | Take screenshot of page or element |
| `pdf` | Save page as PDF |
| `eval <func> [ref]` | Evaluate JavaScript on page or element |
| `resize <w> <h>` | Resize viewport |
| `dialog-accept [text]` | Accept dialog (optionally with prompt text) |
| `dialog-dismiss` | Dismiss dialog |

### Open Options

```bash
playwright-cli open --headed                    # Visible browser window
playwright-cli open --browser=firefox            # Use specific browser (chrome, firefox, webkit, msedge)
playwright-cli open --persistent                 # Persist profile to disk
playwright-cli open --profile=/path/to/profile   # Custom profile directory
playwright-cli open --config=file.json          # Load config file
```

## Navigation

```bash
playwright-cli go-back
playwright-cli go-forward
playwright-cli reload
```

## Keyboard & Mouse

```bash
playwright-cli press Enter
playwright-cli press ArrowDown
playwright-cli keydown Shift
playwright-cli keyup Shift
playwright-cli mousemove 150 300
playwright-cli mousedown [right]
playwright-cli mouseup [right]
playwright-cli mousewheel 0 100
```

## Tabs

```bash
playwright-cli tab-list
playwright-cli tab-new [url]
playwright-cli tab-select <idx>
playwright-cli tab-close [idx]
```

## Storage

### State
```bash
playwright-cli state-save [file]
playwright-cli state-load <file>
```

### Cookies
```bash
playwright-cli cookie-list [--domain]
playwright-cli cookie-get <name>
playwright-cli cookie-set <name> <value> [--domain] [--httpOnly] [--secure]
playwright-cli cookie-delete <name>
playwright-cli cookie-clear
```

### LocalStorage
```bash
playwright-cli localstorage-list
playwright-cli localstorage-get <key>
playwright-cli localstorage-set <key> <value>
playwright-cli localstorage-delete <key>
playwright-cli localstorage-clear
```

### SessionStorage
```bash
playwright-cli sessionstorage-list
playwright-cli sessionstorage-get <key>
playwright-cli sessionstorage-set <key> <value>
playwright-cli sessionstorage-delete <key>
playwright-cli sessionstorage-clear
```

## Network

```bash
playwright-cli network                        # View network activity
playwright-cli route <pattern> --status=404   # Block with status
playwright-cli route <pattern> --body='{}'    # Mock response body
playwright-cli route-list                     # List active routes
playwright-cli unroute [pattern]              # Remove route(s)
```

## DevTools

```bash
playwright-cli console [min-level]            # View console logs
playwright-cli run-code <code>                 # Execute Playwright code
playwright-cli run-code --filename=script.js  # Run code from file
playwright-cli show                            # Open Playwright Inspector
playwright-cli tracing-start                   # Start trace recording
playwright-cli tracing-stop                    # Stop trace recording
playwright-cli video-start [file]             # Start video recording
playwright-cli video-chapter <title>           # Add chapter marker
playwright-cli video-stop                      # Stop video recording
```

## Sessions

```bash
playwright-cli -s=<name> <cmd>                 # Run command in named session
playwright-cli list                            # List all sessions
playwright-cli close-all                       # Close all sessions
playwright-cli kill-all                        # Force kill all processes
playwright-cli delete-data                     # Delete session data
```

## Targeting Elements

### Refs (default)
Use refs from the snapshot:
```bash
playwright-cli snapshot
playwright-cli click e15
```

### CSS Selectors
```bash
playwright-cli click "#main > button.submit"
```

### Playwright Locators
```bash
playwright-cli click "getByRole('button', { name: 'Submit' })"
playwright-cli click "getByTestId('submit-button')"
```

## Raw Output

Use `--raw` to strip page status and snapshot sections, returning only the result value.

```bash
playwright-cli --raw eval "JSON.stringify(performance.timing)"
playwright-cli --raw snapshot > page.yml
TOKEN=$(playwright-cli --raw cookie-get session_id)
```

## Attach

```bash
playwright-cli attach --cdp=chrome              # Attach to Chrome
playwright-cli attach --cdp=msedge            # Attach to Edge
playwright-cli attach --cdp=http://localhost:9222  # Attach via CDP endpoint
playwright-cli attach --extension             # Attach via browser extension
```
