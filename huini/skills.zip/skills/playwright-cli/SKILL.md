---
name: playwright-cli
description: Automate browser interactions, test web pages, and work with Playwright tests via command-line. Use when (1) interacting with web pages programmatically (clicking, filling forms, navigating), (2) taking screenshots or capturing page state, (3) debugging or exploring web applications, (4) running or generating Playwright tests, (5) mocking network requests, (6) managing browser sessions and storage state (cookies, localStorage). Preferred for coding agents working with large codebases who need token-efficient browser automation.
---

# Browser Automation with playwright-cli

## Quick start

```bash
# Open a page and interact
playwright-cli open https://playwright.dev
playwright-cli snapshot
playwright-cli click e15
playwright-cli type "page.click"
playwright-cli press Enter
playwright-cli close
```

## Installation

```bash
# Install CLI globally
npm install -g @playwright/cli@latest

# Install browser binaries (required)
npx playwright install
```

If the global command is unavailable, use `npx playwright-cli` in all commands below.

## Core Concepts

### Snapshot & Refs

After each command, `playwright-cli` outputs a snapshot of the current page state with element refs (e.g., `e15`). Use these refs to interact with elements.

```bash
playwright-cli snapshot
playwright-cli click e15
```

### Raw Output

Use `--raw` to strip page metadata, returning only the result value. Ideal for piping or scripting.

```bash
playwright-cli --raw eval "document.title"
playwright-cli --raw snapshot > page.yml
```

### Sessions

Multiple isolated browser instances can run concurrently. Use `-s=<name>` to target a specific session.

```bash
playwright-cli -s=auth open https://app.example.com
playwright-cli -s=auth fill e1 "user@example.com"
playwright-cli -s=auth close
```

## Common Workflows

### Basic Interaction

```bash
playwright-cli open https://example.com
playwright-cli snapshot
playwright-cli fill e1 "user@example.com"
playwright-cli fill e2 "password123"
playwright-cli click e3
playwright-cli close
```

### State Persistence (Login Reuse)

```bash
# Login and save state
playwright-cli open https://app.example.com/login
playwright-cli fill e1 "user@example.com"
playwright-cli fill e2 "password123"
playwright-cli click e3
playwright-cli state-save auth.json

# Later, restore state and skip login
playwright-cli state-load auth.json
playwright-cli open https://app.example.com/dashboard
```

### Debugging with DevTools

```bash
playwright-cli open https://example.com --headed
playwright-cli click e4
playwright-cli console
playwright-cli network
playwright-cli close
```

## Command Overview

For the complete command reference, see [references/command-reference.md](references/command-reference.md).

Core categories: `open`, `goto`, `click`, `fill`, `type`, `snapshot`, `screenshot`, `eval`, `press`, `route`, `console`, `tracing-start`, `tracing-stop`, `video-start`, `video-stop`, `state-save`, `state-load`, `tab-*`, `dialog-*`.

## Specific Tasks

- **Command reference**: [references/command-reference.md](references/command-reference.md)
- **Running and debugging Playwright tests**: [references/playwright-tests.md](references/playwright-tests.md)
- **Request mocking and network interception**: [references/request-mocking.md](references/request-mocking.md)
- **Running custom Playwright code**: [references/running-code.md](references/running-code.md)
- **Browser session management**: [references/session-management.md](references/session-management.md)
- **Storage state (cookies, localStorage)**: [references/storage-state.md](references/storage-state.md)
- **Test generation from browser actions**: [references/test-generation.md](references/test-generation.md)
- **Tracing for debugging**: [references/tracing.md](references/tracing.md)
- **Video recording**: [references/video-recording.md](references/video-recording.md)
- **Inspecting element attributes**: [references/element-attributes.md](references/element-attributes.md)
- **Best practices and troubleshooting**: [references/best-practices.md](references/best-practices.md)
