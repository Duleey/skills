---
name: api-security-audit
description: 对Java Spring Boot API接口进行安全审计，检查是否存在未授权访问、越权访问、弱身份认证、传输/日志缺陷、敏感数据暴露等安全问题。当用户要求审查API接口安全性、检查接口安全漏洞、分析Controller层安全缺陷、或评估接口是否存在数据泄露风险时激活此技能。适用于Spring Boot后端项目的Controller、Service、Interceptor等代码的安全审查。
---

# API Security Audit

对 Java Spring Boot 项目的 API 接口进行安全审计，覆盖认证、授权、传输、日志、敏感数据五个维度。

## Audit Workflow

1. **定位目标接口**
   - 根据用户提供的接口路径，定位到对应的 Controller 文件
   - 追踪接口调用链路（Controller → Service → Mapper/Api）

2. **逐维度安全审查**
   按照下方「Five Security Dimensions」逐一检查

3. **输出审计报告**
   使用「Output Format」中的模板输出结果

## Five Security Dimensions

### 1. Authentication（身份认证）

检查接口是否存在弱身份认证或认证绕过：
- Controller/方法是否缺少 `@PreAuthorize` 或类似权限注解
- 网关层/拦截器是否对该路径做了放行（如 `excludePathPatterns`）
- 签名算法是否使用 MD5 等不安全哈希
- 签名是否覆盖请求体（Request Body）
- `timestamp` 是否有时效性校验（防重放）
- `nonce` 是否做唯一性校验

### 2. Authorization（权限控制 / 越权访问）

检查接口是否存在水平/垂直越权：
- 接口是否仅依赖 ID 查询，未校验当前用户与目标数据的关系
- 是否缺少 `openId`/`userId` 与业务数据的绑定校验
- 同类接口是否做了权限校验而该接口缺失
- 返回的数据是否超出当前用户应有权限的范围

### 3. Sensitive Data Exposure（敏感数据暴露）

检查接口返回的数据和日志中是否泄露敏感信息：
- 返回的 VO/DTO 是否包含身份证号、手机号、银行卡号、详细地址等
- 敏感字段是否做脱敏处理（掩码、哈希、移除）
- 日志中是否直接打印对象（`log.info("{}", obj)`）导致敏感信息泄露
- 异常堆栈是否返回给客户端（如 SQL 异常、内部路径）

### 4. Transport/Logging Defects（传输/日志缺陷）

检查接口在数据传输和日志记录中的问题：
- 跨服务调用（Feign/RPC）返回数据是否做空指针校验
- 请求参数是否做合法性校验（`@Validated` 是否生效）
- 入口层（Gateway/ThirdController）是否缺少请求/响应日志
- 日志是否记录完整上下文（请求参数、用户标识、耗时）
- 是否使用 HTTPS（代码层面通常看不出来，但可提醒）

### 5. Input Validation & Injection（输入校验与注入）

检查接口是否存在注入或其他输入相关缺陷：
- SQL 注入（如动态拼接 SQL）
- 反序列化漏洞
- 文件上传漏洞（路径遍历、任意文件上传）
- 参数是否做长度限制和格式校验

## Output Format

对每个发现的缺陷，输出以下结构：

```
### [风险等级] [问题类型] - [简要描述]

**文件**：`绝对路径`  
**位置**：第 X-Y 行

```java
// 问题代码片段
```

**问题说明**：
- 具体描述...

**修复建议**：
- 具体修复方案...
```

最后给出汇总表格：

| 风险等级 | 问题类型 | 简要描述 | 修复优先级 |
|---------|---------|---------|-----------|
| ... | ... | ... | ... |

## References

- **安全检查清单与详细检查项**：见 `references/security-checklist.md`
