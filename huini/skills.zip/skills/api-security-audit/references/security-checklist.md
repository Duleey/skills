# API 安全审计检查清单

## 1. Authentication（身份认证）

### 1.1 认证缺失检查
- [ ] Controller 类或方法是否缺少 `@PreAuthorize`、`@RequiresAuthentication` 等权限注解
- [ ] Spring Security 配置中是否对该路径做了 `permitAll()` 或 `.excludePathPatterns()`
- [ ] 接口是否位于 `/open/`、`/public/`、`/third/` 等开放路径下但缺少额外认证
- [ ] Feign 内部调用接口是否被外部暴露

### 1.2 签名算法检查
- [ ] 是否使用 MD5（已被破解，存在碰撞漏洞）
- [ ] 是否使用 SHA1（已不推荐用于安全场景）
- [ ] 是否使用 HMAC-SHA256 或更强的签名算法
- [ ] 签名密钥是否硬编码在代码中
- [ ] 签名是否覆盖请求体（Request Body）

### 1.3 重放攻击防护
- [ ] `timestamp` 是否有时效性校验（如 ±5 分钟）
- [ ] `nonce` 是否做唯一性校验（如 Redis 缓存已使用 nonce）
- [ ] 签名是否包含 `timestamp` 和 `nonce`

### 1.4 Token 安全
- [ ] JWT Token 是否设置合理过期时间
- [ ] Token 是否在客户端安全存储
- [ ] 是否使用 HTTPS 传输 Token

## 2. Authorization（权限控制 / 越权访问）

### 2.1 水平越权检查
- [ ] 接口是否仅依赖业务 ID（如 `yhbh`、`userId`、`orderId`）查询数据
- [ ] 是否校验当前用户与目标数据的关系（如 `openId` 绑定校验）
- [ ] 同类接口是否做了权限校验而该接口缺失
- [ ] 批量查询接口是否做范围限制（如只能查询自己的数据）

### 2.2 垂直越权检查
- [ ] 管理员接口是否校验了管理员角色
- [ ] 敏感操作（如删除、修改）是否校验了操作权限
- [ ] 接口返回的数据是否超出当前角色应有权限的范围

### 2.3 数据范围控制
- [ ] 列表查询是否限制了数据范围（如只能查自己的数据）
- [ ] 分页查询是否做最大值限制（防止一次性查询大量数据）

## 3. Sensitive Data Exposure（敏感数据暴露）

### 3.1 返回数据检查
- [ ] VO/DTO 是否包含身份证号、手机号、银行卡号、详细地址等敏感字段
- [ ] 敏感字段是否做脱敏处理（如身份证号保留前 3 后 4 位）
- [ ] 是否返回了内部系统信息（如数据库字段名、内部路径、堆栈信息）
- [ ] 错误响应中是否包含敏感信息（如 SQL 语句、内部异常）

### 3.2 日志安全
- [ ] 日志中是否直接打印对象（`log.info("{}", obj)`）
- [ ] 日志是否记录了密码、Token、身份证号等敏感信息
- [ ] 是否使用占位符 `{}` 而非字符串拼接（防止日志注入）

### 3.3 数据传输
- [ ] 是否使用 HTTPS（生产环境）
- [ ] 敏感参数是否在 URL 中传递（GET 请求）

## 4. Transport/Logging Defects（传输/日志缺陷）

### 4.1 空指针与数据完整性
- [ ] 跨服务调用（Feign/RPC）返回数据是否做空指针校验
- [ ] 是否对 `Result.getData()` 做非空判断
- [ ] 链式调用（如 `obj.getA().getB().getC()`）是否可能 NPE

### 4.2 参数校验
- [ ] 请求参数是否使用 `@Validated` 或 `@Valid`
- [ ] 是否做长度限制和格式校验
- [ ] 枚举值是否做合法性校验

### 4.3 日志完整性
- [ ] 入口层是否记录请求参数（注意脱敏）
- [ ] 是否记录操作人、操作时间、操作结果
- [ ] 异常发生时是否记录完整上下文（请求参数、异常信息、堆栈）

## 5. Input Validation & Injection（输入校验与注入）

### 5.1 SQL 注入
- [ ] 是否使用预编译语句（PreparedStatement）
- [ ] 是否存在动态拼接 SQL（`"SELECT * FROM " + tableName`）
- [ ] 是否使用 `${}` 拼接 SQL（MyBatis 中）

### 5.2 反序列化漏洞
- [ ] 是否接受不可信来源的反序列化数据
- [ ] 是否使用 `ObjectInputStream.readObject()` 处理外部输入

### 5.3 文件上传
- [ ] 是否限制文件类型（白名单）
- [ ] 是否限制文件大小
- [ ] 文件名是否做过滤（防止路径遍历 `../`）
- [ ] 上传文件是否存储在独立目录（非 Web 根目录）

### 5.4 XSS 与命令注入
- [ ] 是否对用户输入做过滤和转义
- [ ] 是否使用 `Runtime.exec()` 等执行外部命令

## 附录：常见缺陷修复示例

### 修复越权访问
```java
// 缺陷代码
@PostMapping("/getUser")
public UserVO getUser(@RequestBody UserDTO dto) {
    return userService.getUserById(dto.getUserId()); // 未校验当前用户是否有权查看
}

// 修复代码
@PostMapping("/getUser")
public UserVO getUser(@RequestBody UserDTO dto) {
    // 校验当前用户是否有权查看目标用户
    if (!currentUser.hasPermission(dto.getUserId())) {
        throw new AccessDeniedException("无权查看该用户");
    }
    return userService.getUserById(dto.getUserId());
}
```

### 修复敏感数据泄露
```java
// 缺陷代码
UserVO vo = userService.getUser(id);
return AjaxResult.success(vo); // 返回了完整的身份证号、手机号

// 修复代码
UserVO vo = userService.getUser(id);
vo.setIdCard(maskIdCard(vo.getIdCard())); // 身份证号脱敏
vo.setPhone(maskPhone(vo.getPhone()));     // 手机号脱敏
return AjaxResult.success(vo);

private String maskIdCard(String idCard) {
    if (StringUtils.isBlank(idCard) || idCard.length() != 18) return idCard;
    return idCard.substring(0, 3) + "************" + idCard.substring(15);
}

private String maskPhone(String phone) {
    if (StringUtils.isBlank(phone) || phone.length() != 11) return phone;
    return phone.substring(0, 3) + "****" + phone.substring(7);
}
```

### 修复空指针风险
```java
// 缺陷代码
SbWatermeterBaseEntity entity = waterApi.sbInfoByYhbh(yhbh).getData();
infoVO.setInstallAddress(entity.getInstallAddress()); // 可能 NPE

// 修复代码
SbWatermeterBaseEntity entity = waterApi.sbInfoByYhbh(yhbh).getData();
if (entity != null) {
    infoVO.setInstallAddress(entity.getInstallAddress());
}
```

### 修复日志缺陷
```java
// 缺陷代码
log.info("用户水表信息：{}", yhSbInfoVo); // 直接打印对象

// 修复代码
log.info("查询用户水表信息, yhbh={}, sbkj={}, waterTypeCount={}", 
    yhbh, 
    yhSbInfoVo != null ? yhSbInfoVo.getSbkj() : null,
    yhSbInfoVo != null && yhSbInfoVo.getWaterTypeList() != null ? yhSbInfoVo.getWaterTypeList().size() : 0
);
```
