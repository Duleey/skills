---
name: oracle-connector
description: Connect to and query the Huini Oracle database (106.14.143.128:1521/ORCL). Use when the user needs to execute SQL queries, inspect database schemas, retrieve data, or perform any database operations on the Oracle instance. Triggers on requests involving database queries, table lookups, data verification, schema exploration, or any Oracle DB interaction.
---

# Oracle Connector

## Overview

Provide direct SQL execution capabilities against the Huini Oracle database via a bundled Python script.

## Database Configuration

| Setting | Value |
|---------|-------|
| Driver | oracledb (Python) |
| Host | 106.14.143.128 |
| Port | 1521 |
| Service | ORCL |
| User | system |
| Password | HuiniOdb#518 |

## Workflow

### 1. Execute SQL Query

Run `scripts/query_oracle.py` with the SQL statement:

```bash
python scripts/query_oracle.py "SELECT * FROM your_table WHERE ROWNUM <= 10"
```

With bind parameters:

```bash
python scripts/query_oracle.py "SELECT * FROM users WHERE id = :id" --params '{"id": 1}'
```

The script auto-detects `SELECT`/`WITH` as queries; everything else is treated as DDL/DML and committed.

### 2. Inspect Schema

Query Oracle data dictionary views:

```sql
-- List all tables owned by current user
SELECT table_name FROM user_tables

-- List all tables in the database
SELECT owner, table_name FROM all_tables WHERE owner = 'YOUR_SCHEMA'

-- Describe a table's columns
SELECT column_name, data_type, data_length, nullable
FROM user_tab_columns
WHERE table_name = 'YOUR_TABLE_NAME'

-- List indexes
SELECT index_name, table_name FROM user_indexes WHERE table_name = 'YOUR_TABLE_NAME'
```

### 3. Handle Results

The script outputs JSON:

```json
{
  "success": true,
  "columns": ["ID", "NAME"],
  "row_count": 2,
  "data": [
    {"ID": 1, "NAME": "Alice"},
    {"ID": 2, "NAME": "Bob"}
  ]
}
```

On error:

```json
{
  "success": false,
  "error": "ORA-00942: table or view does not exist",
  "error_code": 942
}
```

## Important Notes

- **Always** upper-case table names when querying `user_tab_columns` or `all_tables` unless the table was created with quoted identifiers.
- Use `ROWNUM <= N` to limit large result sets.
- For date columns, results are returned as ISO 8601 strings.
- The script commits automatically for DDL/DML statements.
- Ensure `oracledb` Python package is installed: `pip install oracledb`
