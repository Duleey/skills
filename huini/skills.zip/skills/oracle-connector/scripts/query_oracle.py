#!/usr/bin/env python3
"""
Oracle 数据库查询脚本
支持执行 SQL 查询并返回结果

用法:
    python query_oracle.py "SELECT * FROM your_table WHERE ROWNUM <= 10"
    python query_oracle.py "SELECT * FROM your_table WHERE id = :id" --params '{"id": 1}'
"""

import json
import sys
import oracledb

# 数据库连接配置
DB_CONFIG = {
    "user": "system",
    "password": "HuiniOdb#518",
    "dsn": "106.14.143.128:1521/ORCL"
}


def execute_query(sql, params=None):
    """执行 SQL 查询并返回结果"""
    connection = None
    try:
        connection = oracledb.connect(**DB_CONFIG)
        cursor = connection.cursor()

        if params:
            cursor.execute(sql, params)
        else:
            cursor.execute(sql)

        # 获取列名
        columns = [col[0] for col in cursor.description] if cursor.description else []

        # 获取数据
        rows = cursor.fetchall()

        # 转换为字典列表
        results = []
        for row in rows:
            row_dict = {}
            for i, col in enumerate(columns):
                value = row[i]
                # 处理不可序列化的类型
                if hasattr(value, 'isoformat'):
                    row_dict[col] = value.isoformat()
                else:
                    row_dict[col] = value
            results.append(row_dict)

        return {
            "success": True,
            "columns": columns,
            "row_count": len(results),
            "data": results
        }

    except oracledb.Error as e:
        return {
            "success": False,
            "error": str(e),
            "error_code": e.args[0].code if hasattr(e.args[0], 'code') else None
        }
    finally:
        if connection:
            connection.close()


def execute_ddl(sql):
    """执行 DDL/DML 语句（无结果集返回）"""
    connection = None
    try:
        connection = oracledb.connect(**DB_CONFIG)
        cursor = connection.cursor()
        cursor.execute(sql)
        connection.commit()
        return {
            "success": True,
            "row_count": cursor.rowcount
        }
    except oracledb.Error as e:
        return {
            "success": False,
            "error": str(e),
            "error_code": e.args[0].code if hasattr(e.args[0], 'code') else None
        }
    finally:
        if connection:
            connection.close()


def main():
    if len(sys.argv) < 2:
        print("用法: python query_oracle.py <SQL语句> [--params '{\"key\": \"value\"}']")
        sys.exit(1)

    sql = sys.argv[1]
    params = None

    if "--params" in sys.argv:
        params_idx = sys.argv.index("--params")
        if params_idx + 1 < len(sys.argv):
            params = json.loads(sys.argv[params_idx + 1])

    # 判断是查询还是 DDL/DML
    sql_upper = sql.strip().upper()
    if sql_upper.startswith("SELECT") or sql_upper.startswith("WITH"):
        result = execute_query(sql, params)
    else:
        result = execute_ddl(sql)

    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
