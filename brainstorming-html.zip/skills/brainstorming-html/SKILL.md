---
name: brainstorming-html
description: "Use only when the user explicitly invokes /brainstorming-html or asks for HTML-format brainstorming. Refines an idea through one-question-at-a-time dialogue and writes the design as a single self-contained HTML file (not markdown)."
---

# Brainstorming Ideas Into HTML Designs

Help turn ideas into fully formed designs and specs through natural collaborative dialogue.

Start by understanding the current project context, then ask questions one at a time to refine the idea. Once you understand what you're building, present the design and get user approval. The final design artifact is a single self-contained HTML file rather than a markdown document.

<HARD-GATE>
Do NOT invoke any implementation skill, write any code, scaffold any project, or take any implementation action until you have presented a design and the user has approved it. This applies to EVERY project regardless of perceived simplicity.
</HARD-GATE>

## Anti-Pattern: "This Is Too Simple To Need A Design"

Every project goes through this process. A todo list, a single-function utility, a config change — all of them. "Simple" projects are where unexamined assumptions cause the most wasted work. The design can be short (a few sentences for truly simple projects), but you MUST present it and get approval.

## Checklist

You MUST create a task for each of these items and complete them in order:

1. **Explore project context** — check files, docs, recent commits
2. **Ask clarifying questions** — one at a time, understand purpose/constraints/success criteria
3. **Propose 2-3 approaches** — with trade-offs and your recommendation
4. **Present design** — in sections scaled to their complexity, get user approval after each section
5. **Write HTML design doc** — save to `docs/specs/YYYY-MM-DD-<topic>-design.html`
6. **Spec self-review** — quick inline check for placeholders, contradictions, ambiguity, scope (see below)
7. **User reviews HTML** — tell them the file path, ask if they want changes

## Process Flow

```
1. Explore project context
2. Ask clarifying questions
3. Propose 2-3 approaches
4. Present design sections
   ↳ approval declined → revise (back to 4)
5. Write HTML design doc
6. Spec self-review (fix inline)
7. Ask user to review the HTML
   ↳ changes requested → back to 5
   ↳ approved → done
```

**The terminal state is the user-approved HTML design doc.** This skill is self-contained and does not chain into any other skill or workflow.

## The Process

**Understanding the idea:**

- Check out the current project state first (files, docs, recent commits)
- Before asking detailed questions, assess scope: if the request describes multiple independent subsystems (e.g., "build a platform with chat, file storage, billing, and analytics"), flag this immediately. Don't spend questions refining details of a project that needs to be decomposed first.
- If the project is too large for a single spec, help the user decompose into sub-projects: what are the independent pieces, how do they relate, what order should they be built? Then brainstorm the first sub-project through the normal design flow.
- For appropriately-scoped projects, ask questions one at a time to refine the idea
- Prefer multiple choice questions when possible, but open-ended is fine too
- Only one question per message - if a topic needs more exploration, break it into multiple questions
- Focus on understanding: purpose, constraints, success criteria

**Exploring approaches:**

- Propose 2-3 different approaches with trade-offs
- Present options conversationally with your recommendation and reasoning
- Lead with your recommended option and explain why

**Presenting the design:**

- Once you believe you understand what you're building, present the design
- Scale each section to its complexity: a few sentences if straightforward, up to 200-300 words if nuanced
- Ask after each section whether it looks right so far
- Cover: architecture, components, data flow, error handling, testing
- Be ready to go back and clarify if something doesn't make sense

**Design for isolation and clarity:**

- Break the system into smaller units that each have one clear purpose, communicate through well-defined interfaces, and can be understood and tested independently
- For each unit, you should be able to answer: what does it do, how do you use it, and what does it depend on?
- Can someone understand what a unit does without reading its internals? Can you change the internals without breaking consumers? If not, the boundaries need work.
- Smaller, well-bounded units are also easier for you to work with - you reason better about code you can hold in context at once, and your edits are more reliable when files are focused. When a file grows large, that's often a signal that it's doing too much.

**Working in existing codebases:**

- Explore the current structure before proposing changes. Follow existing patterns.
- Where existing code has problems that affect the work (e.g., a file that's grown too large, unclear boundaries, tangled responsibilities), include targeted improvements as part of the design - the way a good developer improves code they're working in.
- Don't propose unrelated refactoring. Stay focused on what serves the current goal.

## Writing the HTML Design Doc

**Why HTML over markdown:** As specs grow, markdown becomes a restricting format — past a hundred lines or so it rarely gets read end-to-end. HTML can convey much richer information than markdown, and HTML documents are much easier to read; the chance of either the user or a future agent actually reading this spec is higher when it's in HTML.

**Constraint — the spec is also read by future agents:**

When this spec is later picked up for implementation or verification, the next Claude reads the raw HTML, not the rendered page. CSS that helps a human read the document — typography, spacing, mild colors, columns, responsive layout — is fine and welcome. What hurts is content encoded in ways an LLM can't easily parse from tokens:

- **Default for structure:** semantic HTML — `<table>`, `<section>`, `<dl>`, `<details>`, `<pre><code>` — styled with CSS for readability.
- **Default for diagrams:** ASCII / Unicode box-drawing inside `<pre>` blocks. Compact, parses cleanly both ways.
- **Default for UI mockups:** schematic HTML+CSS sketches at wireframe fidelity — real semantic elements arranged with CSS, not pixel-precise replicas.
- **Off by default:** SVG, CSS animations, JS interactivity. Concrete coordinates (`<path d="M120,15 L240,80…" />`) are pure noise once they hit an LLM context. Only enable these when the user explicitly asks.

Heuristic: if you find yourself writing pixel-level positions, you've dropped below the abstraction level the spec should live at — go back up.

**What HTML is good for here:**

The headline use case: **side-by-side comparison of the approaches considered.** Lay the 2–3 alternatives from step 3 (Propose approaches) out as a grid so they can be compared side by side. Label each with the tradeoff it's making, and visually highlight the chosen one. The spec then records the *decision*, not just the *result*.

Beyond that, conditional content — include only what applies to this design:

- **UI involved?** → make a mockup (schematic HTML+CSS, wireframe fidelity)
- **Data flowing between components?** → show data flow (ASCII/Unicode diagram in `<pre>`)
- **Key interfaces or data shapes?** → add code snippets you might want to review later (signatures and types, not full implementations)

Plus the standard sections: overview, decisions, constraints, open questions.

**Where to save:**

- Default path: `docs/specs/YYYY-MM-DD-<topic>-design.html`
- User preferences for spec location override this default

**Spec Self-Review:**
After writing the HTML spec, look at it with fresh eyes:

1. **Placeholder scan:** Any "TBD", "TODO", incomplete sections, or vague requirements? Fix them.
2. **Internal consistency:** Do any sections contradict each other? Does the architecture match the feature descriptions?
3. **Scope check:** Is this focused enough for a single implementation, or does it need decomposition?
4. **Ambiguity check:** Could any requirement be interpreted two different ways? If so, pick one and make it explicit.

Fix any issues inline. No need to re-review — just fix and move on.

**User Review Gate:**
After self-review, tell the user where the file is and ask if they want changes:

> "HTML spec written to `<path>`. Let me know if you want any changes."

If they request changes, update the HTML, re-run the self-review, and ask again. The skill ends only when the user has no more changes.

## Key Principles

- **One question at a time** - Don't overwhelm with multiple questions
- **Multiple choice preferred** - Easier to answer than open-ended when possible
- **YAGNI ruthlessly** - Remove unnecessary features from all designs
- **Explore alternatives** - Always propose 2-3 approaches before settling
- **Incremental validation** - Present design, get approval before moving on
- **Be flexible** - Go back and clarify when something doesn't make sense
- **HTML over Markdown** - The artifact is HTML, not markdown — for readability and richer structure
